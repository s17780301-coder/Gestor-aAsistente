package com.example.gestoriaasistente;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CustomerDbHelper extends SQLiteOpenHelper {
    public CustomerDbHelper(Context context) { super(context, "dentaljg.db", null, 2); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE pacientes (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, telefono TEXT NOT NULL, tratamiento TEXT DEFAULT '', total REAL NOT NULL, pagado REAL NOT NULL DEFAULT 0, quincenas INTEGER NOT NULL DEFAULT 1, pago_quincenal REAL NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE pagos (id INTEGER PRIMARY KEY AUTOINCREMENT, paciente_id INTEGER NOT NULL, monto REAL NOT NULL, fecha INTEGER NOT NULL, nota TEXT DEFAULT '')");
        db.execSQL("CREATE TABLE recordatorios (id INTEGER PRIMARY KEY AUTOINCREMENT, paciente_id INTEGER NOT NULL, nota TEXT NOT NULL, fecha INTEGER NOT NULL, hecho INTEGER NOT NULL DEFAULT 0)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE pacientes ADD COLUMN quincenas INTEGER NOT NULL DEFAULT 1");
            db.execSQL("ALTER TABLE pacientes ADD COLUMN pago_quincenal REAL NOT NULL DEFAULT 0");
            db.execSQL("CREATE TABLE IF NOT EXISTS recordatorios (id INTEGER PRIMARY KEY AUTOINCREMENT, paciente_id INTEGER NOT NULL, nota TEXT NOT NULL, fecha INTEGER NOT NULL, hecho INTEGER NOT NULL DEFAULT 0)");
        }
    }
    public long add(String nombre, String telefono, String tratamiento, double total, int quincenas, double pagoQuincenal) {
        ContentValues v = new ContentValues(); v.put("nombre", nombre); v.put("telefono", telefono); v.put("tratamiento", tratamiento); v.put("total", total); v.put("pagado", 0); v.put("quincenas", quincenas); v.put("pago_quincenal", pagoQuincenal);
        return getWritableDatabase().insert("pacientes", null, v);
    }
    public Cursor all() { return getReadableDatabase().rawQuery("SELECT id,nombre,telefono,tratamiento,total,pagado,MAX(total-pagado,0) saldo,quincenas,pago_quincenal FROM pacientes ORDER BY nombre COLLATE NOCASE", null); }
    public Cursor one(long id) { return getReadableDatabase().rawQuery("SELECT id,nombre,telefono,tratamiento,total,pagado,MAX(total-pagado,0) saldo,quincenas,pago_quincenal FROM pacientes WHERE id=?", new String[]{String.valueOf(id)}); }
    public void delete(long id) { getWritableDatabase().delete("recordatorios", "paciente_id=?", new String[]{String.valueOf(id)}); getWritableDatabase().delete("pagos", "paciente_id=?", new String[]{String.valueOf(id)}); getWritableDatabase().delete("pacientes", "id=?", new String[]{String.valueOf(id)}); }
    public boolean payment(long id, double amount, String note) {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { ContentValues p=new ContentValues(); p.put("paciente_id",id); p.put("monto",amount); p.put("fecha",System.currentTimeMillis()); p.put("nota",note); db.insertOrThrow("pagos",null,p);
            db.execSQL("UPDATE pacientes SET pagado=MIN(total,pagado+?) WHERE id=?",new Object[]{amount,id}); db.setTransactionSuccessful(); return true;
        } catch(Exception e) { return false; } finally { db.endTransaction(); }
    }
    public long addReminder(long patientId, String note, long date) { ContentValues v=new ContentValues();v.put("paciente_id",patientId);v.put("nota",note);v.put("fecha",date);return getWritableDatabase().insert("recordatorios",null,v); }
    public Cursor reminders() { return getReadableDatabase().rawQuery("SELECT r.id,p.nombre,r.nota,r.fecha,r.hecho,r.paciente_id FROM recordatorios r JOIN pacientes p ON p.id=r.paciente_id WHERE r.hecho=0 ORDER BY r.fecha ASC",null); }
    public void completeReminder(long id) { ContentValues v=new ContentValues();v.put("hecho",1);getWritableDatabase().update("recordatorios",v,"id=?",new String[]{String.valueOf(id)}); }
    public double sumPaid() { Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(pagado),0) FROM pacientes",null); double n=0; if(c.moveToFirst()) n=c.getDouble(0); c.close(); return n; }
    public double sumPending() { Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(MAX(total-pagado,0)),0) FROM pacientes",null); double n=0; if(c.moveToFirst()) n=c.getDouble(0); c.close(); return n; }
    public int count() { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM pacientes",null); int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n; }
    public Cursor payments(long patientId) { return getReadableDatabase().rawQuery("SELECT monto,fecha,nota FROM pagos WHERE paciente_id=? ORDER BY fecha DESC",new String[]{String.valueOf(patientId)}); }
}
