package com.example.gestoriaasistente;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private CustomerDbHelper db;
    private SharedPreferences prefs;
    private TextView collectedValue, pendingValue, patientCount;
    private LinearLayout root;
    private boolean dark;
    private final int navy=Color.rgb(16,37,62), teal=Color.rgb(16,189,183), ink=Color.rgb(27,39,54), muted=Color.rgb(111,129,149);
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        db=new CustomerDbHelper(this); prefs=getSharedPreferences("dentaljg",MODE_PRIVATE); dark=prefs.getBoolean("dark",false);
        collectedValue=findViewById(R.id.collectedValue); pendingValue=findViewById(R.id.pendingValue); patientCount=findViewById(R.id.patientCount); root=findViewById(R.id.rootLayout);
        findViewById(R.id.btnAddPatient).setOnClickListener(v->addPatient());
        findViewById(R.id.btnPatients).setOnClickListener(v->showPatients());
        findViewById(R.id.btnReports).setOnClickListener(v->showReports());
        findViewById(R.id.btnSettings).setOnClickListener(v->settings());
        findViewById(R.id.btnReminders).setOnClickListener(v->showReminders());
        findViewById(R.id.tilePatients).setOnClickListener(v->showPatients());
        findViewById(R.id.tileCollections).setOnClickListener(v->choosePatientForPayment());
        findViewById(R.id.tileWhatsApp).setOnClickListener(v->choosePatientForWhatsApp());
        findViewById(R.id.tileReports).setOnClickListener(v->showReports());
        applyTheme(); refresh();
    }
    @Override protected void onResume(){super.onResume();refresh();}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
    private String money(double n){return NumberFormat.getCurrencyInstance(new Locale("es","MX")).format(n);}
    private void refresh(){if(collectedValue!=null){collectedValue.setText(money(db.sumPaid()));pendingValue.setText(money(db.sumPending()));patientCount.setText(String.valueOf(db.count()));}}
    private void applyTheme(){
        root.setBackgroundColor(dark?Color.rgb(12,22,36):Color.rgb(245,247,251));
        int title=dark?Color.rgb(241,247,255):ink;
        ((TextView)findViewById(R.id.title)).setTextColor(title);
        ((TextView)findViewById(R.id.subtitle)).setTextColor(dark?Color.rgb(180,197,216):muted);
        int[] ids={R.id.tilePatients,R.id.tileCollections,R.id.tileWhatsApp,R.id.tileReports};
        for(int id:ids)findViewById(id).setBackgroundColor(dark?Color.rgb(26,43,62):Color.WHITE);
        recolorText(root, dark);
        int[] buttonIds={R.id.btnAddPatient,R.id.btnPatients,R.id.btnReports,R.id.btnSettings,R.id.btnReminders};
        for(int id:buttonIds){Button b=findViewById(id); if(dark){b.setTextColor(Color.rgb(225,240,249)); if(id!=R.id.btnAddPatient)b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(31,53,74)));} }
        getWindow().setStatusBarColor(dark?Color.rgb(8,17,29):navy);getWindow().setNavigationBarColor(dark?Color.rgb(8,17,29):Color.rgb(245,247,251));
    }
    private void recolorText(View view, boolean useDark){
        if(view instanceof TextView){TextView t=(TextView)view;int c=t.getCurrentTextColor();if(useDark && (c==ink || c==Color.rgb(27,39,54)))t.setTextColor(Color.rgb(235,243,250));}
        if(view instanceof android.view.ViewGroup){android.view.ViewGroup group=(android.view.ViewGroup)view;for(int i=0;i<group.getChildCount();i++)recolorText(group.getChildAt(i),useDark);}
    }
    private LinearLayout form(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(28,8,28,0);return l;}
    private EditText field(LinearLayout box,String hint,int type){EditText e=new EditText(this);e.setHint(hint);e.setInputType(type);box.addView(e);return e;}
    private void addPatient(){
        LinearLayout f=form(); EditText name=field(f,"Nombre completo del paciente",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS); EditText phone=field(f,"WhatsApp con lada (10 dígitos)",InputType.TYPE_CLASS_PHONE); EditText treatment=field(f,"Tratamiento o concepto",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); EditText total=field(f,"Saldo total / costo del tratamiento ($)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); EditText periods=field(f,"Número de quincenas acordadas",InputType.TYPE_CLASS_NUMBER); EditText payment=field(f,"Cantidad del pago quincenal ($)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        periods.setText("1");
        new AlertDialog.Builder(this).setTitle("Registrar paciente").setMessage("Registra el saldo acordado y el plan de pagos.").setView(f).setNegativeButton("Cancelar",null).setPositiveButton("Guardar paciente",(d,w)->{
            String n=name.getText().toString().trim(), p=phone.getText().toString().replaceAll("[^0-9]",""), t=treatment.getText().toString().trim(); double amount=parse(total.getText().toString()), installment=parse(payment.getText().toString()); int q=parseInt(periods.getText().toString());
            if(n.isEmpty()||p.length()<10||amount<=0||q<=0||installment<=0){toast("Completa nombre, teléfono, saldo, quincenas y pago quincenal.");return;} db.add(n,p,t,amount,q,installment);refresh();toast("Paciente guardado correctamente.");
        }).show();
    }
    private double parse(String s){try{return Double.parseDouble(s.replace(",","."));}catch(Exception e){return 0;}}
    private int parseInt(String s){try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;}}
    private void showPatients(){
        Cursor c=db.all(); LinearLayout list=form(); list.setPadding(24,4,24,4); int count=0;
        while(c.moveToNext()){count++; final long id=c.getLong(0); String name=c.getString(1),phone=c.getString(2),treatment=c.getString(3); double total=c.getDouble(4),paid=c.getDouble(5),balance=c.getDouble(6);int quincenas=c.getInt(7);double installment=c.getDouble(8);
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(18,14,18,14);card.setBackgroundColor(dark?Color.rgb(26,43,62):Color.rgb(241,247,250));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=12;list.addView(card,cp);
            card.addView(txt(name,17,dark?Color.WHITE:ink,true));card.addView(txt((treatment==null||treatment.isEmpty()?"Tratamiento":treatment)+"  ·  "+phone,12,dark?Color.LTGRAY:muted,false));card.addView(txt("Saldo total: "+money(total)+"    Abonado: "+money(paid),13,dark?Color.WHITE:ink,false));card.addView(txt("Pendiente: "+money(balance)+" · "+quincenas+" quincenas · "+money(installment)+" por quincena",13,balance>0?Color.rgb(205,117,69):Color.rgb(22,150,105),true));
            TextView actions=txt("ABONAR  ·  NOTA/RECORDATORIO  ·  WHATSAPP  ·  HISTORIAL",11,teal,true);actions.setPadding(0,12,0,2);card.addView(actions);card.setOnClickListener(v->patientActions(id,name,phone,total,paid,balance));actions.setOnClickListener(v->patientActions(id,name,phone,total,paid,balance));
        }c.close(); if(count==0)list.addView(txt("Aún no hay pacientes. Usa ‘Registrar paciente’ para comenzar.",15,muted,false));
        ScrollView scroll=new ScrollView(this);scroll.addView(list);new AlertDialog.Builder(this).setTitle("Pacientes y saldos").setView(scroll).setPositiveButton("Agregar paciente",(d,w)->addPatient()).setNegativeButton("Cerrar",null).show();
    }
    private void patientActions(long id,String name,String phone,double total,double paid,double balance){
        String[] actions=balance>0?new String[]{"Registrar abono", "Agregar nota o recordatorio", "Preparar recordatorio por WhatsApp", "Ver historial de pagos", "Eliminar paciente"}:new String[]{"Agregar nota o recordatorio","Preparar mensaje por WhatsApp","Ver historial de pagos","Eliminar paciente"};
        new AlertDialog.Builder(this).setTitle(name).setItems(actions,(d,which)->{String a=actions[which];if(a.equals("Registrar abono"))addPayment(id,name,balance);else if(a.equals("Agregar nota o recordatorio"))addReminder(id,name);else if(a.contains("WhatsApp"))confirmWhatsApp(name,phone,balance);else if(a.equals("Ver historial de pagos"))showPatientDetails(id,name,total,paid,balance);else if(a.equals("Eliminar paciente"))new AlertDialog.Builder(this).setMessage("¿Eliminar a "+name+" y su historial de pagos y recordatorios?").setNegativeButton("Cancelar",null).setPositiveButton("Eliminar",(dd,ww)->{db.delete(id);refresh();showPatients();}).show();}).setNegativeButton("Cerrar",null).show();
    }
    private void addPayment(long id,String name,double balance){LinearLayout f=form();EditText amount=field(f,"Cantidad recibida ($)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);EditText note=field(f,"Nota: efectivo, transferencia, quincena…",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        new AlertDialog.Builder(this).setTitle("Registrar abono · "+name).setMessage("Saldo pendiente: "+money(balance)).setView(f).setNegativeButton("Cancelar",null).setPositiveButton("Guardar abono",(d,w)->{double n=parse(amount.getText().toString());if(n<=0){toast("Escribe una cantidad válida.");return;}if(n>balance+0.009){toast("El abono supera el saldo pendiente.");return;}if(db.payment(id,n,note.getText().toString().trim())){refresh();toast("Abono guardado. El saldo se actualizó.");}else toast("No se pudo guardar el abono.");}).show();}
    private void showPatientDetails(long id,String name,double total,double paid,double balance){StringBuilder s=new StringBuilder("Saldo total: ").append(money(total)).append("\nAbonado: ").append(money(paid)).append("\nPendiente: ").append(money(balance)).append("\n\nHistorial de pagos:\n");Cursor c=db.payments(id);int found=0;while(c.moveToNext()){found++;s.append(new SimpleDateFormat("d MMM yyyy · HH:mm",new Locale("es","MX")).format(new Date(c.getLong(1)))).append(" — ").append(money(c.getDouble(0)));String note=c.getString(2);if(note!=null&&!note.isEmpty())s.append(" (").append(note).append(")");s.append("\n");}c.close();if(found==0)s.append("Sin abonos registrados.");new AlertDialog.Builder(this).setTitle(name).setMessage(s.toString()).setPositiveButton("Aceptar",null).show();}
    private void confirmWhatsApp(String name,String phone,double balance){String template=prefs.getString("message","Hola {nombre}, te recordamos que tienes un saldo pendiente de {saldo} en Dental JG. Si ya realizaste tu pago, por favor ignora este mensaje. ¡Gracias!");String msg=template.replace("{nombre}",name).replace("{saldo}",money(Math.max(0,balance)));
        new AlertDialog.Builder(this).setTitle("Confirmar recordatorio").setMessage("Se abrirá WhatsApp con este mensaje. Tú decides si enviarlo:\n\n"+msg).setNegativeButton("Cancelar",null).setPositiveButton("Abrir WhatsApp",(d,w)->{try{String digits=phone.replaceAll("[^0-9]","");if(digits.length()==10)digits="52"+digits;Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+digits+"?text="+Uri.encode(msg)));startActivity(i);}catch(Exception e){toast("No se pudo abrir WhatsApp.");}}).show();}
    private void choosePatientForPayment(){choosePatient("¿A qué paciente registrarás un abono?",(id,name,phone,balance)->{if(balance>0)addPayment(id,name,balance);else toast("Este paciente no tiene saldo pendiente.");});}
    private void choosePatientForWhatsApp(){choosePatient("¿A qué paciente recordarás el pago?",(id,name,phone,balance)->confirmWhatsApp(name,phone,balance));}
    private interface PatientAction{void run(long id,String name,String phone,double balance);}
    private void choosePatient(String title,PatientAction action){Cursor c=db.all();java.util.ArrayList<Long> ids=new java.util.ArrayList<>();java.util.ArrayList<String> labels=new java.util.ArrayList<>();java.util.ArrayList<String> names=new java.util.ArrayList<>();java.util.ArrayList<String> phones=new java.util.ArrayList<>();java.util.ArrayList<Double> balances=new java.util.ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));names.add(c.getString(1));phones.add(c.getString(2));balances.add(c.getDouble(6));labels.add(c.getString(1)+" · pendiente "+money(c.getDouble(6)));}c.close();if(labels.isEmpty()){toast("Primero registra un paciente.");return;}new AlertDialog.Builder(this).setTitle(title).setItems(labels.toArray(new String[0]),(d,which)->action.run(ids.get(which),names.get(which),phones.get(which),balances.get(which))).setNegativeButton("Cancelar",null).show();}
    private void addReminder(long patientId,String name){LinearLayout f=form();EditText note=field(f,"Nota o motivo del recordatorio",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|InputType.TYPE_TEXT_FLAG_MULTI_LINE);note.setMinLines(2);TextView dateLabel=txt("Fecha del recordatorio: "+new SimpleDateFormat("d MMM yyyy",new Locale("es","MX")).format(new Date()),14,teal,true);f.addView(dateLabel);final Calendar selected=Calendar.getInstance();dateLabel.setOnClickListener(v->new DatePickerDialog(this,(DatePicker view,int y,int m,int day)->{selected.set(y,m,day,9,0,0);dateLabel.setText("Fecha del recordatorio: "+new SimpleDateFormat("d MMM yyyy",new Locale("es","MX")).format(selected.getTime()));},selected.get(Calendar.YEAR),selected.get(Calendar.MONTH),selected.get(Calendar.DAY_OF_MONTH)).show());
        new AlertDialog.Builder(this).setTitle("Nota / recordatorio · "+name).setMessage("Toca la fecha para cambiarla. La app guardará la nota en la lista de pendientes.").setView(f).setNegativeButton("Cancelar",null).setPositiveButton("Guardar recordatorio",(d,w)->{String text=note.getText().toString().trim();if(text.isEmpty()){toast("Escribe una nota o recordatorio.");return;}db.addReminder(patientId,text,selected.getTimeInMillis());toast("Recordatorio guardado.");}).show();}
    private void showReminders(){Cursor c=db.reminders();java.util.ArrayList<Long> ids=new java.util.ArrayList<>();java.util.ArrayList<String> labels=new java.util.ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));String date=new SimpleDateFormat("d MMM",new Locale("es","MX")).format(new Date(c.getLong(3)));labels.add(date+" · "+c.getString(1)+"\n"+c.getString(2));}c.close();if(labels.isEmpty()){new AlertDialog.Builder(this).setTitle("Notas y recordatorios").setMessage("No hay recordatorios pendientes. Entra a un paciente y selecciona ‘Agregar nota o recordatorio’ para crear uno.").setPositiveButton("Entendido",null).show();return;}new AlertDialog.Builder(this).setTitle("Pendientes · toca para marcar realizado").setItems(labels.toArray(new String[0]),(d,which)->new AlertDialog.Builder(this).setMessage("¿Marcar este recordatorio como realizado?").setNegativeButton("Todavía no",null).setPositiveButton("Sí, realizado",(dd,ww)->{db.completeReminder(ids.get(which));showReminders();}).show()).setNegativeButton("Cerrar",null).show();}
    private void showReports(){Cursor c=db.all();StringBuilder s=new StringBuilder("Resumen de cobranza\n\nTotal cobrado: ").append(money(db.sumPaid())).append("\nSaldo pendiente: ").append(money(db.sumPending())).append("\nPacientes registrados: ").append(db.count()).append("\n\nCuentas pendientes:\n");int n=0;while(c.moveToNext()){double balance=c.getDouble(6);if(balance>0){n++;s.append("• ").append(c.getString(1)).append(" — ").append(money(balance)).append("; pago quincenal ").append(money(c.getDouble(8))).append("\n");}}c.close();if(n==0)s.append("No hay saldos pendientes.");new AlertDialog.Builder(this).setTitle("Reporte de cobranza").setMessage(s.toString()).setPositiveButton("Cerrar",null).show();}
    private void settings(){LinearLayout f=form();TextView themeLabel=txt(dark?"Tema oscuro activado":"Tema claro activado",15,teal,true);f.addView(themeLabel);Button toggle=new Button(this);toggle.setText(dark?"Cambiar a tema claro":"Activar tema oscuro");f.addView(toggle);final boolean[] newDark={dark};toggle.setOnClickListener(v->{newDark[0]=!newDark[0];toggle.setText(newDark[0]?"Cambiar a tema claro":"Activar tema oscuro");themeLabel.setText(newDark[0]?"Tema oscuro activado":"Tema claro activado");});EditText msg=field(f,"Plantilla WhatsApp. Usa {nombre} y {saldo}.",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|InputType.TYPE_TEXT_FLAG_MULTI_LINE);msg.setMinLines(4);msg.setText(prefs.getString("message","Hola {nombre}, te recordamos que tienes un saldo pendiente de {saldo} en Dental JG. Si ya realizaste tu pago, por favor ignora este mensaje. ¡Gracias!"));new AlertDialog.Builder(this).setTitle("Ajustes de DENTAL JG").setMessage("Elige el tema y personaliza los mensajes.").setView(f).setNegativeButton("Cancelar",null).setPositiveButton("Guardar cambios",(d,w)->{dark=newDark[0];prefs.edit().putBoolean("dark",dark).putString("message",msg.getText().toString().trim().isEmpty()?prefs.getString("message",""):msg.getText().toString().trim()).apply();applyTheme();toast("Ajustes guardados.");}).show();}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
