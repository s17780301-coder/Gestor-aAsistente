DENTAL JG — Proyecto Android

Funciones incluidas:
- Alta local de pacientes con saldo total, número de quincenas y cantidad del pago quincenal.
- Resumen de dinero cobrado, saldo pendiente y número de pacientes.
- Registro de abonos parciales o liquidación del saldo.
- Consulta del saldo y resumen del historial de pagos por paciente.
- Notas y recordatorios pendientes por paciente, con fecha elegida y opción de marcarlos como realizados.
- Tema oscuro activable desde Ajustes.
- Tarjetas principales conectadas a sus funciones (pacientes, cobranza, WhatsApp y reportes).
- Recordatorio por WhatsApp con confirmación antes de abrir WhatsApp; no envía automáticamente.
- Reporte de cuentas pendientes.
- Personalización de la plantilla de WhatsApp usando {nombre} y {saldo}.

Los datos se guardan localmente en el teléfono. No se requiere cuenta ni conexión para registrar pacientes y pagos.

PARA GENERAR EL APK DESDE GITHUB (teléfono):
1. Sube el contenido de este ZIP a la raíz de un repositorio de GitHub (no subas el ZIP dentro del repositorio; descomprímelo primero).
2. Abre la pestaña Actions.
3. Selecciona “Compilar DENTAL JG”.
4. Pulsa “Run workflow” y confirma.
5. Cuando termine en verde, abre la ejecución y descarga el artefacto “DentalJG-APK”.
6. Descomprime el artefacto descargado y abre app-debug.apk para instalarlo.

Nota: el APK se genera en GitHub Actions; este paquete es el proyecto fuente preparado para compilar, no el APK instalado.
