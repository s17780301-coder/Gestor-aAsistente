GESTORÍA ASISTENTE - VERSIÓN 4.0

NOVEDADES
- Interfaz futurista con colores neón, tarjetas y botones con respuesta visual.
- Conserva los recordatorios de quincena, el mensaje editable para WhatsApp, voz y selección de tono.
- Base de datos local de clientes frecuentes (nombre, teléfono y notas).
- Calendario con próximas quincenas, aviso personal dos días antes y preparación de mensajes un día antes.
- Estadísticas de clientes y recordatorios preparados.
- Tema claro/oscuro.

FECHAS
- Quincenas: día 15 y último día de la quincena (30; febrero se ajusta a 28/29).
- Aviso personal: dos días antes (normalmente 13 y 28).
- Preparar mensajes a clientes: un día antes (normalmente 14 y 29).
- WhatsApp no envía automáticamente: se abre el chat y la persona confirma el envío.

COMPILAR DESDE GITHUB ACTIONS
1. Sube este ZIP al repositorio público y conserva el nombre GestoriaAsistente_V5.0_FUTURISTA.zip para que el flujo de trabajo existente lo encuentre.
2. En GitHub abre Actions.
3. Abre "Compilar Gestoria Asistente" y pulsa Run workflow.
4. Espera a que termine en verde.
5. Abre la ejecución, baja a Artifacts y descarga GestoriaAsistente-APK-V4.
6. Descomprime el artefacto descargado y abre el APK en tu teléfono para instalarlo.

NOTA: La base de datos de clientes se guarda localmente en el teléfono. Haz respaldo manual de los datos importantes; desinstalar la app puede borrar sus datos.
