package com.example.gestoriaasistente;

import android.Manifest;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends android.app.Activity {
    private static final int NOTIFICATION_PERMISSION = 100;
    private static final int PICK_TONE = 101;
    private SharedPreferences prefs;
    private CustomerDbHelper customers;
    private boolean darkMode;
    private TextView status;
    private EditText messageInput;
    private boolean askedExactAlarm = false;
    private TextToSpeech tts;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("gestoria", MODE_PRIVATE);
        customers = new CustomerDbHelper(this);
        darkMode = prefs.getBoolean("dark_mode", false);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        messageInput = findViewById(R.id.messageInput);
        messageInput.setText(prefs.getString("whatsapp_message", defaultMessage()));
        tts = new TextToSpeech(this, result -> { if (tts != null && result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("es", "MX")); });
        refreshDates(); applyColors(); updateStatus();

        findViewById(R.id.btnSchedule).setOnClickListener(v -> requestAndSchedule());
        findViewById(R.id.btnCancel).setOnClickListener(v -> {
            cancelReminders(); prefs.edit().putBoolean("enabled", false).apply(); updateStatus();
            Toast.makeText(this, "Recordatorios pausados.", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btnSaveMessage).setOnClickListener(v -> saveMessage());
        findViewById(R.id.btnWhatsApp).setOnClickListener(v -> openWhatsApp(prefs.getString("whatsapp_message", defaultMessage()), null));
        findViewById(R.id.btnVoice).setOnClickListener(v -> speak(messageInput.getText().toString().trim().isEmpty() ? defaultMessage() : messageInput.getText().toString().trim()));
        findViewById(R.id.btnTone).setOnClickListener(v -> chooseTone());
        findViewById(R.id.btnCustomers).setOnClickListener(v -> showCustomers());
        findViewById(R.id.btnBulkWhatsApp).setOnClickListener(v -> prepareCustomerMessages());
        findViewById(R.id.btnTheme).setOnClickListener(v -> { darkMode = !darkMode; prefs.edit().putBoolean("dark_mode", darkMode).apply(); recreate(); });
        findViewById(R.id.btnCalendar).setOnClickListener(v -> showCalendar());
        findViewById(R.id.btnStats).setOnClickListener(v -> showStatistics());
    }

    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } if (customers != null) customers.close(); super.onDestroy(); }

    @Override protected void onResume() {
        super.onResume();
        if (askedExactAlarm) {
            askedExactAlarm = false;
            if (Build.VERSION.SDK_INT >= 31) {
                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (am != null && am.canScheduleExactAlarms()) scheduleReminders();
                else Toast.makeText(this, "Para horarios exactos, permite las alarmas en Ajustes.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private String defaultMessage() { return "Hola, te recuerdo amablemente que la fecha de tu pago es mañana, por favor. ¡Gracias!"; }

    private void requestAndSchedule() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null && !am.canScheduleExactAlarms()) {
                askedExactAlarm = true;
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()))); }
                catch (Exception e) { scheduleReminders(); }
                return;
            }
        }
        scheduleReminders();
    }

    private void saveMessage() {
        String msg = messageInput.getText().toString().trim(); if (msg.isEmpty()) msg = defaultMessage();
        prefs.edit().putString("whatsapp_message", msg).apply(); messageInput.setText(msg);
        Toast.makeText(this, "Mensaje guardado.", Toast.LENGTH_SHORT).show();
    }

    private void speak(String text) {
        if (tts == null) { Toast.makeText(this, "La voz aún se está preparando.", Toast.LENGTH_SHORT).show(); return; }
        if (Build.VERSION.SDK_INT >= 21) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "gestoria_voice");
        else tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void chooseTone() {
        Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Elige el tono de Gestoría Asistente");
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
        String saved = prefs.getString("tone_uri", "");
        if (!saved.isEmpty()) intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(saved));
        startActivityForResult(intent, PICK_TONE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_TONE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            prefs.edit().putString("tone_uri", uri == null ? "" : uri.toString()).apply();
            GestoriaApplication.rebuildChannel(this);
            Toast.makeText(this, "Tono guardado. Si Android ya creó el canal, el nuevo tono se aplicará al canal actualizado.", Toast.LENGTH_LONG).show();
        }
    }

    private void refreshDates() {
        SimpleDateFormat fmt = new SimpleDateFormat("EEEE d 'de' MMMM", new Locale("es", "MX"));
        Calendar now = Calendar.getInstance(), next = nextQuincenaAfter(now), after = nextQuincenaAfter(next);
        ((TextView)findViewById(R.id.nextPayment)).setText("PRÓXIMA QUINCENA\n" + capitalize(fmt.format(new Date(next.getTimeInMillis()))) + " · 9:00 a. m.");
        ((TextView)findViewById(R.id.afterPayment)).setText("Después: " + capitalize(fmt.format(new Date(after.getTimeInMillis()))) + " · 9:00 a. m.\nTu aviso personal será 2 días antes.");
    }
    private String capitalize(String s) { return s == null || s.isEmpty() ? s : s.substring(0,1).toUpperCase(new Locale("es", "MX")) + s.substring(1); }

    private Calendar nextQuincenaAfter(Calendar from) {
        Calendar c = (Calendar) from.clone(); c.set(Calendar.HOUR_OF_DAY, 9); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        for (int i=0; i<8; i++) {
            Calendar fifteenth = (Calendar)c.clone(); fifteenth.set(Calendar.DAY_OF_MONTH, 15);
            if (fifteenth.after(from)) return fifteenth;
            Calendar end = (Calendar)c.clone(); end.set(Calendar.DAY_OF_MONTH, Math.min(30, end.getActualMaximum(Calendar.DAY_OF_MONTH)));
            if (end.after(from)) return end;
            c.add(Calendar.MONTH, 1); c.set(Calendar.DAY_OF_MONTH, 1); c.set(Calendar.HOUR_OF_DAY, 9); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        }
        c.set(Calendar.DAY_OF_MONTH, 15); return c;
    }

    private void scheduleReminders() {
        Calendar target = nextQuincenaAfter(Calendar.getInstance());
        // Personal notice 2 days before; client-message preparation notice 1 day before.
        for (int cycle=0; cycle<4; cycle++) {
            Calendar two = (Calendar)target.clone(); two.add(Calendar.DAY_OF_MONTH, -2);
            Calendar one = (Calendar)target.clone(); one.add(Calendar.DAY_OF_MONTH, -1);
            setAlarm(two, "Tu quincena será en 2 días. Revisa tus cobros y prepara tus pendientes.", 100 + cycle*2);
            setAlarm(one, "Hoy toca preparar y enviar los recordatorios de pago a tus clientes por WhatsApp.", 101 + cycle*2);
            target = nextQuincenaAfter(target);
        }
        prefs.edit().putBoolean("enabled", true).apply(); updateStatus();
        Toast.makeText(this, "Avisos programados: 2 días antes para ti y 1 día antes para clientes.", Toast.LENGTH_LONG).show();
    }

    private void setAlarm(Calendar when, String message, int requestCode) {
        if (when.before(Calendar.getInstance())) return;
        AlarmManager am = (AlarmManager)getSystemService(Context.ALARM_SERVICE); if (am == null) return;
        Intent intent = new Intent(this, QuincenaReceiver.class); intent.putExtra("message", message);
        PendingIntent pi = PendingIntent.getBroadcast(this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        else am.setExact(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
    }

    private void cancelReminders() {
        AlarmManager am = (AlarmManager)getSystemService(Context.ALARM_SERVICE); if (am == null) return;
        for (int code=100; code<=107; code++) { Intent i = new Intent(this, QuincenaReceiver.class); PendingIntent pi = PendingIntent.getBroadcast(this, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE); am.cancel(pi); pi.cancel(); }
    }
    private void updateStatus() {
        if (status == null) return;
        status.setText(prefs.getBoolean("enabled", false) ? "● Recordatorios ACTIVADOS\nPara ti: 2 días antes. Para clientes: 1 día antes (14 y 29 cuando corresponda)." : "○ Recordatorios pausados\nActívalos para recibir avisos automáticos.");
    }

    private void showCustomers() {
        Cursor cursor = customers.all();
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(28, 8, 28, 8);
        if (cursor.getCount()==0) { TextView empty = new TextView(this); empty.setText("Todavía no hay clientes guardados. Pulsa ‘Agregar cliente’ para comenzar."); empty.setPadding(0,12,0,12); list.addView(empty); }
        while (cursor.moveToNext()) {
            long id=cursor.getLong(0); String name=cursor.getString(1), phone=cursor.getString(2), notes=cursor.getString(3);
            Button item = new Button(this); item.setAllCaps(false); item.setText(name + "\n" + phone + (notes==null||notes.isEmpty()?"":"\n"+notes));
            item.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(name).setItems(new String[]{"Enviar recordatorio por WhatsApp", "Eliminar cliente"}, (d, which) -> {
                if (which==0) openWhatsApp(prefs.getString("whatsapp_message", defaultMessage()), phone);
                else new AlertDialog.Builder(this).setMessage("¿Eliminar a " + name + " de tus clientes frecuentes?").setNegativeButton("Cancelar", null).setPositiveButton("Eliminar", (dd,ww)->{ customers.delete(id); showCustomers(); }).show();
            }).setNegativeButton("Cerrar", null).show());
            list.addView(item);
        }
        cursor.close();
        new AlertDialog.Builder(this).setTitle("Clientes frecuentes").setView(list).setPositiveButton("Agregar cliente", (d,w)->showAddCustomer()).setNegativeButton("Cerrar", null).show();
    }

    private void showAddCustomer() {
        LinearLayout form = new LinearLayout(this); form.setPadding(28,8,28,0); form.setOrientation(LinearLayout.VERTICAL);
        EditText name = new EditText(this); name.setHint("Nombre del cliente"); name.setSingleLine(true); form.addView(name);
        EditText phone = new EditText(this); phone.setHint("WhatsApp con código de país, ej. 5212221234567"); phone.setInputType(3); phone.setSingleLine(true); form.addView(phone);
        EditText notes = new EditText(this); notes.setHint("Notas opcionales (servicio, fecha, etc.)"); form.addView(notes);
        new AlertDialog.Builder(this).setTitle("Agregar cliente frecuente").setView(form).setNegativeButton("Cancelar",null).setPositiveButton("Guardar",(d,w)->{
            String n=name.getText().toString().trim(), p=phone.getText().toString().replaceAll("[^0-9]", ""), no=notes.getText().toString().trim();
            if(n.isEmpty()||p.length()<8) { Toast.makeText(this,"Escribe un nombre y un teléfono válido.",Toast.LENGTH_LONG).show(); return; }
            customers.add(n,p,no); Toast.makeText(this,"Cliente guardado en el teléfono.",Toast.LENGTH_SHORT).show(); showCustomers();
        }).show();
    }

    private void showCalendar() {
        SimpleDateFormat fmt = new SimpleDateFormat("EEE d MMM yyyy", new Locale("es", "MX"));
        Calendar target = nextQuincenaAfter(Calendar.getInstance());
        StringBuilder out = new StringBuilder("PRÓXIMAS FECHAS DE QUINCENA\n\n");
        for (int i = 0; i < 8; i++) {
            Calendar personal = (Calendar) target.clone(); personal.add(Calendar.DAY_OF_MONTH, -2);
            Calendar clients = (Calendar) target.clone(); clients.add(Calendar.DAY_OF_MONTH, -1);
            out.append("◆ ").append(capitalize(fmt.format(new Date(target.getTimeInMillis())))).append("\n")
               .append("   Tu aviso personal: ").append(fmt.format(new Date(personal.getTimeInMillis()))).append("\n")
               .append("   Preparar mensajes: ").append(fmt.format(new Date(clients.getTimeInMillis()))).append("\n\n");
            target = nextQuincenaAfter(target);
        }
        TextView content = new TextView(this); content.setText(out.toString()); content.setTextSize(15); content.setPadding(28, 18, 28, 10);
        content.setTextColor(darkMode ? Color.rgb(235,245,255) : Color.rgb(28,43,62));
        new AlertDialog.Builder(this).setTitle("Calendario de quincenas").setView(content).setPositiveButton("Entendido", null).show();
    }

    private void showStatistics() {
        Cursor c = customers.all(); int count = c.getCount(); c.close();
        int prepared = prefs.getInt("prepared_reminders", 0);
        Calendar next = nextQuincenaAfter(Calendar.getInstance());
        SimpleDateFormat fmt = new SimpleDateFormat("d 'de' MMMM", new Locale("es", "MX"));
        String report = "RESUMEN DE TU GESTORÍA\n\n" +
                "Clientes frecuentes guardados: " + count + "\n\n" +
                "Recordatorios preparados para WhatsApp: " + prepared + "\n\n" +
                "Recordatorios automáticos: " + (prefs.getBoolean("enabled", false) ? "ACTIVOS" : "PAUSADOS") + "\n\n" +
                "Próxima quincena: " + capitalize(fmt.format(new Date(next.getTimeInMillis()))) + "\n\n" +
                "Consejo: abre cada cliente desde la base de datos para preparar su mensaje individual. Los mensajes no se envían sin tu confirmación en WhatsApp.";
        TextView content = new TextView(this); content.setText(report); content.setTextSize(16); content.setPadding(28, 18, 28, 10);
        content.setTextColor(darkMode ? Color.rgb(235,245,255) : Color.rgb(28,43,62));
        new AlertDialog.Builder(this).setTitle("Estadísticas").setView(content).setPositiveButton("Cerrar", null).show();
    }

    private void prepareCustomerMessages() {
        Cursor c=customers.all();
        if(c.getCount()==0){ c.close(); new AlertDialog.Builder(this).setMessage("Primero agrega tus clientes frecuentes.").setPositiveButton("Agregar cliente",(d,w)->showAddCustomer()).setNegativeButton("Cerrar",null).show(); return; }
        String[] names=new String[c.getCount()]; String[] phones=new String[c.getCount()]; int ix=0;
        while(c.moveToNext()){ names[ix]=c.getString(1); phones[ix]=c.getString(2); ix++; } c.close();
        new AlertDialog.Builder(this).setTitle("Enviar recordatorio").setItems(names,(d,which)->openWhatsApp(prefs.getString("whatsapp_message",defaultMessage()),phones[which])).setNegativeButton("Cerrar",null).show();
    }

    private void openWhatsApp(String message, String phone) {
        saveMessage(); String msg=prefs.getString("whatsapp_message", defaultMessage());
        if (phone != null && !phone.trim().isEmpty()) {
            prefs.edit().putInt("prepared_reminders", prefs.getInt("prepared_reminders", 0) + 1).apply();
        }
        String url = phone==null ? "https://wa.me/?text="+Uri.encode(msg) : "https://wa.me/"+phone+"?text="+Uri.encode(msg);
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch(Exception e){ Toast.makeText(this,"No se pudo abrir WhatsApp o el navegador.",Toast.LENGTH_LONG).show(); }
    }

    private void applyColors() {
        int bg = darkMode ? Color.rgb(7, 13, 28) : Color.rgb(239, 245, 252);
        int card = darkMode ? Color.rgb(19, 31, 52) : Color.WHITE;
        int fg = darkMode ? Color.rgb(236, 246, 255) : Color.rgb(23, 37, 58);
        int secondary = darkMode ? Color.rgb(164, 187, 210) : Color.rgb(83, 103, 126);
        View root = findViewById(R.id.rootLayout);
        if (root != null) root.setBackgroundColor(bg);
        int[] panelIds = {R.id.panelHero, R.id.panelControl, R.id.panelCustomers, R.id.panelMessages};
        for (int panelId : panelIds) {
            View panel = findViewById(panelId);
            if (panel != null) {
                GradientDrawable panelBg = new GradientDrawable();
                panelBg.setColor(card);
                panelBg.setCornerRadius(28f);
                panelBg.setStroke(1, darkMode ? Color.rgb(28, 73, 105) : Color.rgb(207, 225, 243));
                panel.setBackground(panelBg);
                panel.setElevation(darkMode ? 3f : 2f);
            }
        }
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(darkMode ? Color.rgb(7,13,28) : Color.rgb(239,245,252));
            getWindow().setNavigationBarColor(darkMode ? Color.rgb(7,13,28) : Color.rgb(239,245,252));
            if (Build.VERSION.SDK_INT >= 23) getWindow().getDecorView().setSystemUiVisibility(darkMode ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        int[] textIds = {R.id.title, R.id.subtitle, R.id.nextPayment, R.id.afterPayment, R.id.status};
        for (int id : textIds) {
            TextView t = findViewById(id);
            if (t != null) t.setTextColor(id == R.id.subtitle || id == R.id.status ? secondary : fg);
        }
        TextView title = findViewById(R.id.title);
        if (title != null) { title.setTypeface(null, Typeface.BOLD); title.setLetterSpacing(0.01f); }
        for (int id : new int[]{R.id.nextPayment, R.id.afterPayment, R.id.status}) {
            TextView t = findViewById(id);
            if (t != null) {
                GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                        id == R.id.nextPayment ? new int[]{darkMode ? Color.rgb(13,48,76) : Color.rgb(217,244,255), darkMode ? Color.rgb(26,35,75) : Color.rgb(235,230,255)} : new int[]{card, card});
                gd.setCornerRadius(26); gd.setStroke(1, darkMode ? Color.rgb(35,72,103) : Color.rgb(213,227,241)); t.setBackground(gd);
            }
        }
        EditText edit = findViewById(R.id.messageInput);
        if (edit != null) { edit.setTextColor(fg); edit.setHintTextColor(secondary); GradientDrawable ed = new GradientDrawable(); ed.setColor(card); ed.setCornerRadius(20); ed.setStroke(1, darkMode ? Color.rgb(35,72,103) : Color.rgb(213,227,241)); edit.setBackground(ed); }
        int[] buttons = {R.id.btnSchedule,R.id.btnCancel,R.id.btnSaveMessage,R.id.btnWhatsApp,R.id.btnTheme,R.id.btnVoice,R.id.btnTone,R.id.btnCustomers,R.id.btnBulkWhatsApp,R.id.btnCalendar,R.id.btnStats};
        for (int id : buttons) {
            Button b = findViewById(id);
            if (b != null) {
                boolean primary = id == R.id.btnSchedule || id == R.id.btnCustomers;
                GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                        primary ? new int[]{Color.rgb(0,190,220), Color.rgb(104,85,245)} : new int[]{card, card});
                gd.setCornerRadius(20);
                if (!primary) gd.setStroke(1, darkMode ? Color.rgb(42,69,98) : Color.rgb(209,224,240));
                b.setBackground(gd); b.setTextColor(primary ? Color.WHITE : fg); b.setAllCaps(false); b.setTypeface(null, Typeface.BOLD); b.setPadding(10, 12, 10, 12);
                b.setElevation(primary ? 5f : 1f);
                b.setOnTouchListener((view, event) -> {
                    if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) view.animate().scaleX(0.98f).scaleY(0.98f).setDuration(70).start();
                    else if (event.getAction() == android.view.MotionEvent.ACTION_UP || event.getAction() == android.view.MotionEvent.ACTION_CANCEL) view.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                    return false;
                });
            }
        }
    }

}
