DENTAL JG 10.1 — COLORES DEL LOGO, CLÍNICAS Y PACIENTES

1. Extrae el ZIP completo y sube su contenido al repositorio GitHub que utilizas para DENTAL JG.
2. Ejecuta el workflow de GitHub Actions para compilar las APK.
3. Descarga los artefactos del workflow e instala ambas APK.
4. Inicia sesión con la misma cuenta de Supabase en el gestor y el panel.

Cambios de esta versión:
- Se usa el turquesa del logotipo (#19B9B0) y el azul de DENTAL JG (#1769C2), no un verde distinto.
- El panel administrativo mantiene tema oscuro, ahora en tonos neutros azul-gris y con los colores reales de marca.
- En Administrar clínicas puedes editar el nombre o eliminar una clínica. Al editar se actualiza el nombre en los pacientes asignados. Al eliminar, se quita la asignación de clínica de esos pacientes, pero no se eliminan sus expedientes ni pagos.
- Los nombres de clínica que aparecen únicamente en expedientes antiguos se marcan como heredados; primero registra la clínica en el catálogo para poder administrarla.
- La tarjeta “Pacientes registrados” abre el directorio/formulario de pacientes. “Ver pacientes” en una clínica también lleva a la sección de pacientes filtrada por esa clínica.

Si GitHub Actions falla, comparte el error exacto antes de modificar Supabase. Se comprobó la sintaxis de JavaScript, pero esta entrega aún necesita una compilación completa y prueba real contra Supabase.
