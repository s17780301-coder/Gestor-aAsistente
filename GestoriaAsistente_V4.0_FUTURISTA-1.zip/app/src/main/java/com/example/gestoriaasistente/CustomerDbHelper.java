package com.example.gestoriaasistente;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CustomerDbHelper extends SQLiteOpenHelper {
    public CustomerDbHelper(Context context) { super(context, "gestoria_clientes.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE clientes (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, telefono TEXT NOT NULL, notas TEXT DEFAULT '')");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    public long add(String nombre, String telefono, String notas) {
        ContentValues v = new ContentValues(); v.put("nombre", nombre); v.put("telefono", telefono); v.put("notas", notas);
        return getWritableDatabase().insert("clientes", null, v);
    }
    public Cursor all() { return getReadableDatabase().rawQuery("SELECT id,nombre,telefono,notas FROM clientes ORDER BY nombre COLLATE NOCASE", null); }
    public void delete(long id) { getWritableDatabase().delete("clientes", "id=?", new String[]{String.valueOf(id)}); }
}
