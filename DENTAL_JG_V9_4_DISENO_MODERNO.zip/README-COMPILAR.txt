DENTAL JG V9.4 — mejora visual y formularios

Cambios de esta versión:
- Se conservan las funciones existentes de pacientes, cobranza, pagos, reportes, WhatsApp, recordatorios y tema oscuro.
- El registro del paciente ahora incluye Número de póliza y Clínica.
- Se corrigió el contraste del texto al escribir y se modernizaron los campos de formulario.
- El registro inicial del gestor tiene una cabecera visual renovada.
- Se mejoraron los espacios y las tarjetas del panel principal; el formulario de paciente ahora permite desplazarse para ver todos los campos.
- La base de datos se actualiza de la versión 3 a la 4 sin borrar los pacientes existentes; los campos nuevos quedan vacíos para registros anteriores.
- Se añadió el permiso de Internet para preparar la siguiente etapa de conexión.

IMPORTANTE SOBRE EL PANEL ADMINISTRATIVO EN TIEMPO REAL:
La sincronización por internet todavía NO está activa en este ZIP. Para que los cobros se vean en otro dispositivo hace falta crear y alojar un servicio web con base de datos, acceso protegido y el panel administrativo, y conectar esta app a ese servicio. No sería correcto afirmar que ya sincroniza sin ese servidor. El siguiente paso es preparar y publicar el backend/panel y luego integrar sus credenciales seguras.

Para compilar desde GitHub:
1. Sube/reemplaza los archivos del ZIP en tu repositorio.
2. Abre Actions y ejecuta el flujo "Compilar DENTAL JG".
3. Si termina en verde, abre la ejecución y descarga el artefacto DentalJG-APK.

Este ZIP contiene el proyecto fuente; no es por sí mismo una APK instalable.
