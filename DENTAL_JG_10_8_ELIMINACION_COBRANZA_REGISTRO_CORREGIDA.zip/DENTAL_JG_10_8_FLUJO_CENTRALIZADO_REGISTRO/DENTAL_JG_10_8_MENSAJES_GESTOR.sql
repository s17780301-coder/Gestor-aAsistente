-- DENTAL JG 10.8: mensajes desde Gestoría hacia Cobranza y Recibos.
-- Ejecutar una sola vez en Supabase SQL Editor con una cuenta administradora.
create table if not exists public.app_messages (
  id uuid primary key default gen_random_uuid(),
  title text not null check (length(trim(title)) between 1 and 160),
  body text not null check (length(trim(body)) between 1 and 4000),
  target text not null check (target in ('cobranza','recibos','ambos')),
  created_by uuid not null default auth.uid() references auth.users(id),
  created_by_email text not null default '',
  created_at timestamptz not null default now(),
  is_active boolean not null default true
);
create index if not exists app_messages_active_created_idx on public.app_messages (is_active, created_at desc);
alter table public.app_messages enable row level security;
revoke all on public.app_messages from public, anon, authenticated;
grant select, insert on public.app_messages to authenticated;
drop policy if exists app_messages_read_active on public.app_messages;
create policy app_messages_read_active on public.app_messages for select to authenticated using (is_active = true);
drop policy if exists app_messages_insert_self on public.app_messages;
create policy app_messages_insert_self on public.app_messages for insert to authenticated with check (created_by = auth.uid());
-- No se otorgan permisos de edición ni borrado a las aplicaciones cliente.
