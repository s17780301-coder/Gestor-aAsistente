DENTAL JG COBRANZA — APK independiente

COMPILAR EN GITHUB
1. Sube el contenido de esta carpeta a la raíz del repositorio.
2. Abre Actions y ejecuta “Compilar DENTAL JG Cobranza - Una APK”.
3. Descarga el artefacto DENTAL-JG-Cobranza-Recibos-APK.

IMPORTANTE: Para que funcione recibos, gestores y carteras, abre Supabase > SQL Editor y ejecuta completo el archivo app/src/main/assets/supabase_cobranza_v1.sql (también está en cobranza-web/supabase_cobranza_v1.sql). Es una migración aditiva; no borra pacientes ni pagos.

La app consulta las tablas existentes public.patients y public.payments. El botón de carteras agrupa pacientes por el campo clinic, crea/actualiza una cartera por clínica y asigna los pacientes sin duplicar carteras. Después puedes registrar gestores y asignarlos en Carteras.
