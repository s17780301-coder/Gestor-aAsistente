-- DENTAL JG 10.8.12 — Permitir editar/eliminar clientes desde Cobranza y Registro.
-- Ejecutar en Supabase SQL Editor. No elimina datos por sí misma.
-- Roles autorizados: admin, cobranza y registro. Gestor queda excluido.

DROP POLICY IF EXISTS "admins update patient profiles" ON public.patients;
DROP POLICY IF EXISTS "client managers update patient profiles" ON public.patients;
CREATE POLICY "client managers update patient profiles"
ON public.patients FOR UPDATE TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.app_user_roles r
  WHERE r.user_id = auth.uid() AND r.role IN ('admin','cobranza','registro')
))
WITH CHECK (EXISTS (
  SELECT 1 FROM public.app_user_roles r
  WHERE r.user_id = auth.uid() AND r.role IN ('admin','cobranza','registro')
));
GRANT UPDATE ON public.patients TO authenticated;

CREATE OR REPLACE FUNCTION public.delete_patient_permanently(p_patient_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  p public.patients%rowtype;
  v_payments integer := 0;
  v_receipts integer := 0;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.app_user_roles r
    WHERE r.user_id = auth.uid() AND r.role IN ('admin','cobranza','registro')
  ) THEN
    RAISE EXCEPTION 'Solo Administración, Cobranza o Registro pueden eliminar clientes';
  END IF;
  SELECT * INTO p FROM public.patients WHERE id = p_patient_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'No se encontró el cliente'; END IF;

  IF to_regclass('public.collection_portfolio_patients') IS NOT NULL THEN
    EXECUTE 'DELETE FROM public.collection_portfolio_patients WHERE patient_id = $1' USING p.id;
  END IF;
  IF to_regclass('public.collection_period_patients') IS NOT NULL THEN
    EXECUTE 'DELETE FROM public.collection_period_patients WHERE patient_id = $1' USING p.id;
  END IF;
  IF to_regclass('public.collection_receipts') IS NOT NULL THEN
    EXECUTE 'DELETE FROM public.collection_receipts WHERE patient_id = $1' USING p.id;
    GET DIAGNOSTICS v_receipts = ROW_COUNT;
  END IF;
  DELETE FROM public.payments WHERE patient_id = p.id;
  GET DIAGNOSTICS v_payments = ROW_COUNT;
  DELETE FROM public.patients WHERE id = p.id;
  RETURN jsonb_build_object('success', true, 'patient_id', p.id, 'payments_deleted', v_payments, 'receipts_deleted', v_receipts);
END;
$$;
REVOKE ALL ON FUNCTION public.delete_patient_permanently(uuid) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.delete_patient_permanently(uuid) TO authenticated;
