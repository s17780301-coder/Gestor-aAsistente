-- DENTAL JG 10.8.10: campos nuevos de Registro, folio de sistema y mensajería interna.
create sequence if not exists public.dental_jg_patient_folio_seq;
alter table public.patients add column if not exists folio text;
alter table public.patients add column if not exists first_names text not null default '';
alter table public.patients add column if not exists surnames text not null default '';
alter table public.patients add column if not exists address text not null default '';
alter table public.patients add column if not exists phone2 text not null default '';
alter table public.patients add column if not exists observations text not null default '';
update public.patients set folio='JG-'||lpad(nextval('public.dental_jg_patient_folio_seq')::text,6,'0') where coalesce(folio,'')='';
create unique index if not exists patients_folio_unique_idx on public.patients(folio) where folio is not null;

create or replace function public.register_dental_jg_patient(
 p_name text, p_phone text default '', p_treatment text default '', p_total numeric default 0,
 p_installments integer default 0, p_installment_amount numeric default 0, p_policy_number text default '', p_clinic text default '',
 p_first_names text, p_surnames text, p_address text, p_phone2 text, p_observations text
) returns uuid language plpgsql security definer set search_path=public as $$
declare new_id uuid; new_folio text;
begin
 if auth.uid() is null then raise exception 'Inicia sesión para registrar clientes.'; end if;
 if not exists(select 1 from public.app_user_roles where user_id=auth.uid() and role in ('registro','admin')) then raise exception 'Esta cuenta no tiene permiso para registrar clientes.'; end if;
 if length(trim(coalesce(p_first_names,p_name,'')))=0 or length(trim(coalesce(p_surnames,'')))=0 or length(trim(coalesce(p_clinic,'')))=0 or length(trim(coalesce(p_policy_number,'')))=0 or length(trim(coalesce(p_address,'')))=0 or length(trim(coalesce(p_phone,'')))=0 then raise exception 'Completa todos los campos obligatorios.'; end if;
 new_folio:='JG-'||lpad(nextval('public.dental_jg_patient_folio_seq')::text,6,'0');
 insert into public.patients(folio,first_names,surnames,address,phone2,observations,name,phone,treatment,total,paid,installments,installment_amount,policy_number,clinic,source_device,created_at,updated_at)
 values(new_folio,trim(coalesce(p_first_names,p_name)),trim(coalesce(p_surnames,'')),trim(coalesce(p_address,'')),trim(coalesce(p_phone2,'')),trim(coalesce(p_observations,'')),trim(p_name),trim(p_phone),trim(coalesce(p_observations,p_treatment,'')),0,0,0,p_installment_amount,trim(p_policy_number),trim(p_clinic),'DENTAL JG Registro',now(),now()) returning id into new_id;
 return new_id;
end; $$;
revoke all on function public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text) from public, anon;
grant execute on function public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text) to authenticated;

create table if not exists public.app_internal_messages (
 id uuid primary key default gen_random_uuid(), sender_id uuid not null references auth.users(id) on delete cascade,
 recipient_id uuid not null references auth.users(id) on delete cascade, sender_app text not null, recipient_app text not null,
 subject text not null default '', body text not null, created_at timestamptz not null default now(), read_at timestamptz
);
alter table public.app_internal_messages enable row level security;
grant select,insert,update on public.app_internal_messages to authenticated;
drop policy if exists "messages visible to sender or recipient" on public.app_internal_messages;
create policy "messages visible to sender or recipient" on public.app_internal_messages for select to authenticated using(auth.uid()=sender_id or auth.uid()=recipient_id);
drop policy if exists "users send internal messages" on public.app_internal_messages;
create policy "users send internal messages" on public.app_internal_messages for insert to authenticated with check(auth.uid()=sender_id);
drop policy if exists "recipients mark messages read" on public.app_internal_messages;
create policy "recipients mark messages read" on public.app_internal_messages for update to authenticated using(auth.uid()=recipient_id) with check(auth.uid()=recipient_id);
create index if not exists app_internal_messages_recipient_created_idx on public.app_internal_messages(recipient_id,created_at desc);
do $$ begin if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='app_internal_messages') then alter publication supabase_realtime add table public.app_internal_messages; end if; end $$;
create or replace function public.send_dental_jg_internal_message(p_recipient_role text,p_sender_app text,p_subject text,p_body text)
returns integer language plpgsql security definer set search_path=public as $$
declare n integer;
begin
 if auth.uid() is null then raise exception 'Inicia sesión para enviar mensajes.'; end if;
 if coalesce(trim(p_body),'')='' then raise exception 'Escribe el mensaje.'; end if;
 insert into public.app_internal_messages(sender_id,recipient_id,sender_app,recipient_app,subject,body)
 select auth.uid(),r.user_id,coalesce(nullif(trim(p_sender_app),''),'DENTAL JG'),p_recipient_role,coalesce(trim(p_subject),''),trim(p_body)
 from public.app_user_roles r where r.role=p_recipient_role and r.user_id<>auth.uid();
 get diagnostics n = row_count;
 return n;
end; $$;
revoke all on function public.send_dental_jg_internal_message(text,text,text,text) from public,anon;
grant execute on function public.send_dental_jg_internal_message(text,text,text,text) to authenticated;
