GESTORIA ASISTENTE 2.0

Mejoras incluidas:
- Tema oscuro/claro con preferencia guardada.
- Diseño visual renovado y botones más claros.
- Próxima quincena mostrada en pantalla.
- Recordatorios para las dos próximas quincenas (2 días y 1 día antes).
- Mensaje de pago preparado para compartir por WhatsApp.
- Corrección del cálculo al pasar de fin de mes a la siguiente quincena.

Para generar el APK desde GitHub:
1. Sube este ZIP a la raíz del repositorio que ya usaste.
2. En Acciones, ejecuta el flujo de trabajo que compila el ZIP CORREGIDO.
3. Abre la ejecución verde y descarga el artefacto GestoriaAsistente-APK.
4. Extrae el archivo descargado e instala app-debug.apk.

Nota: esta es la versión fuente preparada para compilar; no es un APK ya compilado.
