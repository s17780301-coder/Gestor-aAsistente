package com.example.gestoriaasistente;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends android.app.Activity {
    private static final int NOTIFICATION_PERMISSION = 100;
    private SharedPreferences prefs;
    private boolean darkMode;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        prefs = getSharedPreferences("gestoria", MODE_PRIVATE);
        darkMode = prefs.getBoolean("dark_mode", false);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        applyColors();

        TextView next = findViewById(R.id.nextPayment);
        status = findViewById(R.id.status);
        Button schedule = findViewById(R.id.btnSchedule);
        Button whatsapp = findViewById(R.id.btnWhatsApp);
        Button settingsButton = findViewById(R.id.btnSettings);
        Button themeButton = findViewById(R.id.btnTheme);

        next.setText(getNextQuincenaText());
        updateStatus();
        themeButton.setText(darkMode ? "☀  Cambiar a tema claro" : "☾  Cambiar a tema oscuro");

        schedule.setOnClickListener(v -> {
            requestNotificationPermission();
            scheduleReminders();
            prefs.edit().putBoolean("enabled", true).apply();
            updateStatus();
            Toast.makeText(this, "Recordatorios programados para las próximas quincenas.", Toast.LENGTH_LONG).show();
        });

        whatsapp.setOnClickListener(v -> {
            String message = "Hola, te recuerdo amablemente que la fecha de tu pago es mañana. ¡Gracias!";
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/?text=" + Uri.encode(message)));
            try {
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "No se pudo abrir WhatsApp o el navegador.", Toast.LENGTH_LONG).show();
            }
        });

        settingsButton.setOnClickListener(v -> {
            boolean enabled = prefs.getBoolean("enabled", false);
            if (enabled) {
                Toast.makeText(this, "Los recordatorios están activados. Puedes volver a programarlos cuando quieras.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Activa los recordatorios para recibir avisos 2 días y 1 día antes de la quincena.", Toast.LENGTH_LONG).show();
            }
        });

        themeButton.setOnClickListener(v -> {
            darkMode = !darkMode;
            prefs.edit().putBoolean("dark_mode", darkMode).apply();
            recreate();
        });
    }

    private void applyColors() {
        int background = darkMode ? Color.rgb(18, 24, 34) : Color.rgb(245, 247, 251);
        int card = darkMode ? Color.rgb(31, 41, 55) : Color.WHITE;
        int text = darkMode ? Color.rgb(241, 245, 249) : Color.rgb(27, 39, 54);
        int secondary = darkMode ? Color.rgb(190, 202, 218) : Color.rgb(91, 105, 122);
        View root = findViewById(R.id.rootLayout);
        if (root != null) root.setBackgroundColor(background);
        TextView title = findViewById(R.id.title);
        TextView subtitle = findViewById(R.id.subtitle);
        TextView next = findViewById(R.id.nextPayment);
        TextView statusText = findViewById(R.id.status);
        if (title != null) { title.setTextColor(text); title.setTypeface(null, Typeface.BOLD); }
        if (subtitle != null) subtitle.setTextColor(secondary);
        if (next != null) {
            next.setTextColor(text);
            next.setPadding(28, 32, 28, 32);
            GradientDrawable shape = new GradientDrawable();
            shape.setColor(card);
            shape.setCornerRadius(28);
            next.setBackground(shape);
        }
        if (statusText != null) statusText.setTextColor(secondary);
        int accent = darkMode ? Color.rgb(38, 181, 205) : Color.rgb(0, 139, 170);
        int[] ids = {R.id.btnSchedule, R.id.btnWhatsApp, R.id.btnSettings, R.id.btnTheme};
        for (int id : ids) {
            Button b = findViewById(id);
            if (b != null) {
                GradientDrawable shape = new GradientDrawable();
                shape.setColor(id == R.id.btnSchedule ? accent : card);
                shape.setCornerRadius(22);
                b.setBackground(shape);
                b.setTextColor(id == R.id.btnSchedule ? Color.WHITE : text);
                b.setAllCaps(false);
                b.setPadding(16, 18, 16, 18);
            }
        }
    }

    private void updateStatus() {
        if (status != null) {
            status.setText(prefs.getBoolean("enabled", false)
                    ? "● Recordatorios ACTIVADOS\nRecibirás avisos antes de las próximas quincenas."
                    : "○ Recordatorios desactivados\nActívalos para recibir avisos automáticos.");
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
        }
    }

    private void scheduleReminders() {
        Calendar now = Calendar.getInstance();
        Calendar target = getNextQuincena(now);
        for (int cycle = 0; cycle < 2; cycle++) {
            Calendar twoDays = (Calendar) target.clone();
            twoDays.add(Calendar.DAY_OF_MONTH, -2);
            Calendar oneDay = (Calendar) target.clone();
            oneDay.add(Calendar.DAY_OF_MONTH, -1);
            setAlarm(twoDays, "Tu quincena será en 2 días.", 100 + cycle * 2);
            setAlarm(oneDay, "Recuerda: la fecha de tu pago es mañana, por favor.", 101 + cycle * 2);
            target = getNextQuincena(target);
            target.add(Calendar.SECOND, 1);
        }
    }

    private void setAlarm(Calendar when, String message, int requestCode) {
        if (when.before(Calendar.getInstance())) return;
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, QuincenaReceiver.class);
        intent.putExtra("message", message);
        PendingIntent pi = PendingIntent.getBroadcast(this, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            Intent settings = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
            settings.setData(Uri.parse("package:" + getPackageName()));
            startActivity(settings);
            return;
        }
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        else am.setExact(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
    }

    private Calendar getNextQuincena(Calendar from) {
        Calendar target = (Calendar) from.clone();
        target.set(Calendar.HOUR_OF_DAY, 9);
        target.set(Calendar.MINUTE, 0);
        target.set(Calendar.SECOND, 0);
        target.set(Calendar.MILLISECOND, 0);
        int day = from.get(Calendar.DAY_OF_MONTH);
        if (day < 15 || (day == 15 && from.get(Calendar.HOUR_OF_DAY) < 9)) {
            target.set(Calendar.DAY_OF_MONTH, 15);
        } else {
            int lastDay = target.getActualMaximum(Calendar.DAY_OF_MONTH);
            target.set(Calendar.DAY_OF_MONTH, lastDay);
            if (target.before(from)) {
                target.add(Calendar.MONTH, 1);
                target.set(Calendar.DAY_OF_MONTH, 15);
            }
        }
        return target;
    }

    private String getNextQuincenaText() {
        Calendar next = getNextQuincena(Calendar.getInstance());
        SimpleDateFormat fmt = new SimpleDateFormat("EEEE d 'de' MMMM", new Locale("es", "MX"));
        return "PRÓXIMA QUINCENA\n" + fmt.format(new Date(next.getTimeInMillis()));
    }
}
