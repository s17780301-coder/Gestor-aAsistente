DENTAL JG V9 - COBRANZA QUINCENAL

CAMBIOS:
- Botón de configuración con engrane en la esquina superior derecha; reemplaza el símbolo de cruz.
- Tema oscuro persistente desde Configuración.
- Perfil de usuario y nombre de clínica configurables.
- Mensaje de WhatsApp centrado exclusivamente en el pago quincenal; no incluye monto ni saldo total.
- Cada opción en la tarjeta del paciente tiene su propia acción: Abonar, Nota, WhatsApp e Historial.
- En Cobranza se muestran solo los pacientes pendientes de la quincena actual.
- Al registrar un pago se puede marcar la quincena como pagada; el paciente deja de aparecer en los pendientes de esa quincena. La próxima quincena vuelve a aparecer si aún tiene saldo.
- Se conserva la base de datos existente y se agrega la tabla de quincenas pagadas mediante migración.

PARA COMPILAR EN GITHUB:
1. Sube todos los archivos de este ZIP al repositorio, reemplazando los anteriores.
2. Abre la pestaña Actions/Acciones.
3. Selecciona “Compilar DENTAL JG”.
4. Pulsa “Run workflow/Ejecutar flujo de trabajo”.
5. Cuando termine, abre la ejecución y descarga el artefacto “DentalJG-APK”.

Este ZIP contiene el código fuente del proyecto; no es la APK instalable.
