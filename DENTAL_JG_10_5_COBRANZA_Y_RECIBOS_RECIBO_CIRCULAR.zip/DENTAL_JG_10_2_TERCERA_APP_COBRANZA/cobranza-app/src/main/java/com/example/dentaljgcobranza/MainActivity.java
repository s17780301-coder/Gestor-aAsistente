package com.example.dentaljgcobranza;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF102A43);
        getWindow().setNavigationBarColor(0xFF102A43);
        webView = new WebView(this);
        setContentView(webView);
        assetLoader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse local = assetLoader.shouldInterceptRequest(request.getUrl());
                return local != null ? local : super.shouldInterceptRequest(view, request);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("appassets.androidplatform.net".equals(uri.getHost())) return false;
                if ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                return true;
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }
    private static class PrintBridge {
        private final Activity activity;
        PrintBridge(Activity activity) { this.activity = activity; }
        @JavascriptInterface public void printReceipt(String html) {
            activity.runOnUiThread(() -> {
                WebView printView = new WebView(activity);
                printView.getSettings().setJavaScriptEnabled(false);
                WebViewAssetLoader printAssetLoader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(activity)).build();
                printView.loadDataWithBaseURL("https://appassets.androidplatform.net/assets/", "<!doctype html><html><head><meta charset='utf-8'><style>body{font:14px Arial;color:#111;margin:24px}table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid #ddd;padding:8px;text-align:left}.receipt-head{display:flex;align-items:center;gap:15px;border-bottom:3px solid #19b9b0;padding-bottom:12px}.receipt-head img{width:90px;max-height:70px;object-fit:contain}.receipt-head h1{color:#102a43}.folio{margin-left:auto;text-align:right}.totals{margin:22px 0 0 auto;width:300px}.totals div{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #ddd}.net{font-size:18px;font-weight:bold}.foot{margin-top:30px;border-top:1px solid #ddd;padding-top:12px}.signature{margin-top:60px;width:220px;border-top:1px solid #333;text-align:center;padding-top:8px}</style></head><body>" + html + "</body></html>", "text/html", "UTF-8", null);
                printView.setWebViewClient(new WebViewClient() {
                    @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                        WebResourceResponse local = printAssetLoader.shouldInterceptRequest(request.getUrl());
                        return local != null ? local : super.shouldInterceptRequest(view, request);
                    }
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager manager = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                        String jobName = "DENTAL_JG_Recibo";
                        manager.print(jobName, view.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("receipt", "Receipt", 300, 300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                    }
                });
            });
        }
    }
    @Override public void onBackPressed() { if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if(webView!=null) webView.destroy(); super.onDestroy(); }
}
