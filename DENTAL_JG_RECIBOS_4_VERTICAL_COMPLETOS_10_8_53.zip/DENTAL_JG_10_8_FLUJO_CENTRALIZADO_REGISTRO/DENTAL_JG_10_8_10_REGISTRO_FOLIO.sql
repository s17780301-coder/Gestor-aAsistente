-- DENTAL JG 10.8.10: campos de Registro y folio de sistema.
create sequence if not exists public.dental_jg_patient_folio_seq;
alter table public.patients add column if not exists folio text;
alter table public.patients add column if not exists first_names text not null default '';
alter table public.patients add column if not exists surnames text not null default '';
alter table public.patients add column if not exists address text not null default '';
alter table public.patients add column if not exists phone2 text not null default '';
alter table public.patients add column if not exists observations text not null default '';
update public.patients set folio='JG-'||lpad(nextval('public.dental_jg_patient_folio_seq')::text,6,'0') where coalesce(folio,'')='';
create unique index if not exists patients_folio_unique_idx on public.patients(folio) where folio is not null;

create or replace function public.register_dental_jg_patient(
 p_name text, p_phone text default '', p_treatment text default '', p_total numeric default 0,
 p_installments integer default 0, p_installment_amount numeric default 0, p_policy_number text default '', p_clinic text default '',
 p_first_names text, p_surnames text, p_address text, p_phone2 text, p_observations text
) returns uuid language plpgsql security definer set search_path=public as $$
declare new_id uuid; new_folio text;
begin
 if auth.uid() is null then raise exception 'Inicia sesión para registrar clientes.'; end if;
 if not exists(select 1 from public.app_user_roles where user_id=auth.uid() and role in ('registro','admin')) then raise exception 'Esta cuenta no tiene permiso para registrar clientes.'; end if;
 if length(trim(coalesce(p_first_names,p_name,'')))=0 or length(trim(coalesce(p_surnames,'')))=0 or length(trim(coalesce(p_clinic,'')))=0 or length(trim(coalesce(p_policy_number,'')))=0 or length(trim(coalesce(p_address,'')))=0 or length(trim(coalesce(p_phone,'')))=0 then raise exception 'Completa todos los campos obligatorios.'; end if;
 new_folio:='JG-'||lpad(nextval('public.dental_jg_patient_folio_seq')::text,6,'0');
 insert into public.patients(folio,first_names,surnames,address,phone2,observations,name,phone,treatment,total,paid,installments,installment_amount,policy_number,clinic,source_device,created_at,updated_at)
 values(new_folio,trim(coalesce(p_first_names,p_name)),trim(coalesce(p_surnames,'')),trim(coalesce(p_address,'')),trim(coalesce(p_phone2,'')),trim(coalesce(p_observations,'')),trim(p_name),trim(p_phone),trim(coalesce(p_observations,p_treatment,'')),0,0,0,p_installment_amount,trim(p_policy_number),trim(p_clinic),'DENTAL JG Registro',now(),now()) returning id into new_id;
 return new_id;
end; $$;
revoke all on function public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text) from public, anon;
grant execute on function public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text) to authenticated;
