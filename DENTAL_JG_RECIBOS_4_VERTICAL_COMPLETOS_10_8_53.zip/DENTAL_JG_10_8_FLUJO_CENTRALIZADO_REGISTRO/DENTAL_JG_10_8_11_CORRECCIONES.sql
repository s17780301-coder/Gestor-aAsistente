-- DENTAL JG 10.8.11 — correcciones solicitadas
-- Ejecutar una sola vez (o volver a ejecutar sin borrar los datos existentes).
-- IMPORTANTE: la eliminación definitiva borra cliente, pagos, recibos y asignaciones; no archiva.

create table if not exists public.dental_jg_policies (
  name text primary key,
  active boolean not null default true,
  created_by uuid references auth.users(id) on delete set null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.dental_jg_policies enable row level security;
grant select, insert, update on public.dental_jg_policies to authenticated;
drop policy if exists "authenticated manage dental policies" on public.dental_jg_policies;
create policy "authenticated manage dental policies" on public.dental_jg_policies
  for all to authenticated using (true) with check (true);

-- Permite que el administrador corrija los datos del expediente desde Administración/Cobranza.
drop policy if exists "admins update patient profiles" on public.patients;
create policy "admins update patient profiles" on public.patients for update to authenticated
  using (exists (select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin'))
  with check (exists (select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin'));
grant update on public.patients to authenticated;

-- Gestores compartidos: el administrador puede consultar/editar gestores de cualquier usuario;
-- usuarios autenticados pueden consultarlos para asignar carteras, pero solo editar los propios salvo admin.
drop policy if exists "admins manage all collection managers" on public.collection_managers;
create policy "admins manage all collection managers" on public.collection_managers for all to authenticated
  using (exists (select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin'))
  with check (exists (select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin'));
drop policy if exists "authenticated view collection managers" on public.collection_managers;
create policy "authenticated view collection managers" on public.collection_managers for select to authenticated using (true);

-- El administrador debe poder sumar lo cobrado por todos los gestores, no solo los recibos propios.
alter table public.collection_receipts add column if not exists manager_id uuid references public.collection_managers(id) on delete set null;
do $$ begin
  if to_regclass('public.collection_receipts') is not null then
    execute 'drop policy if exists "admins view all collection receipts for totals" on public.collection_receipts';
    execute $policy$create policy "admins view all collection receipts for totals" on public.collection_receipts for select to authenticated
      using (exists (select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin'))$policy$;
  end if;
end $$;

create or replace function public.delete_patient_permanently(p_patient_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  p public.patients%rowtype;
  v_payments integer := 0;
  v_receipts integer := 0;
begin
  if not exists (select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin') then
    raise exception 'Solo un administrador puede eliminar definitivamente clientes';
  end if;
  select * into p from public.patients where id=p_patient_id for update;
  if not found then raise exception 'No se encontró el cliente'; end if;

  -- Tablas opcionales de las distintas versiones se borran dinámicamente si existen.
  if to_regclass('public.collection_portfolio_patients') is not null then
    execute 'delete from public.collection_portfolio_patients where patient_id = $1' using p.id;
  end if;
  if to_regclass('public.collection_period_patients') is not null then
    execute 'delete from public.collection_period_patients where patient_id = $1' using p.id;
  end if;
  if to_regclass('public.collection_receipts') is not null then
    execute 'delete from public.collection_receipts where patient_id = $1' using p.id;
    get diagnostics v_receipts = row_count;
  end if;
  delete from public.payments where patient_id=p.id;
  get diagnostics v_payments = row_count;
  delete from public.patients where id=p.id;
  return jsonb_build_object('success',true,'patient_id',p.id,'payments_deleted',v_payments,'receipts_deleted',v_receipts);
end;
$$;
revoke all on function public.delete_patient_permanently(uuid) from public, anon;
grant execute on function public.delete_patient_permanently(uuid) to authenticated;

-- Realtime para refrescar los catálogos al guardar una póliza o modificar pacientes.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='dental_jg_policies') then
    alter publication supabase_realtime add table public.dental_jg_policies;
  end if;
end $$;
