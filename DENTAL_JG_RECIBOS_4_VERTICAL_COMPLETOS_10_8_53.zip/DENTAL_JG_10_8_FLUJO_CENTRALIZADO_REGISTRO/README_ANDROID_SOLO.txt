DENTAL JG — PAQUETE SOLO ANDROID

Este paquete conserva únicamente los proyectos de aplicaciones Android:
- cobranza-app
- registro-app
- gestor-app
- panel-apk

Se eliminaron las aplicaciones web independientes (cobranza-web, registro-web, panel-web y Windows-App-Standalone).
Los archivos web que están dentro de src/main/assets de los proyectos Android se conservan porque son recursos internos que utilizan sus aplicaciones; no son versiones web independientes.

CAMBIO EN COBRANZA
En Carteras se añadió “Generar recibos pendientes”. Selecciona el gestor y genera los recibos que falten para los pagos de los clientes asignados. Los datos del cliente se toman del registro compartido de pacientes; se conserva el formato de recibo existente y el logotipo oficial.
Los recibos se guardan mediante la función SQL existente create_collection_receipt y después se pueden revisar e imprimir desde “Recibos generados”. La función requiere conexión a Supabase y que esté instalada la migración supabase_cobranza_v1.sql.

VALIDACIÓN
El archivo app.js de Cobranza pasó la comprobación sintáctica de Node.js. Este entorno no tiene Gradle instalado ni incluye gradlew, por lo que aquí no fue posible compilar ni verificar APK instalables.
