package com.example.gestoriaasistente;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class QuincenaReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String message = intent.getStringExtra("message");
        if (message == null || message.trim().isEmpty()) message = "Tienes un recordatorio de quincena.";
        Intent open = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, GestoriaApplication.CHANNEL_ID)
                : new Notification.Builder(context);
        if (Build.VERSION.SDK_INT < 26) {
            String saved=context.getSharedPreferences("dentaljg",Context.MODE_PRIVATE).getString("tone_uri","");
            android.net.Uri sound=saved.isEmpty()?android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION):android.net.Uri.parse(saved);
            builder.setSound(sound);
        }
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("DENTAL JG · Recordatorio")
                .setContentText(message)
                .setStyle(new Notification.BigTextStyle().bigText(message))
                .setAutoCancel(true).setContentIntent(pi);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), builder.build());
        QuincenaScheduler.scheduleAll(context);
    }
}
