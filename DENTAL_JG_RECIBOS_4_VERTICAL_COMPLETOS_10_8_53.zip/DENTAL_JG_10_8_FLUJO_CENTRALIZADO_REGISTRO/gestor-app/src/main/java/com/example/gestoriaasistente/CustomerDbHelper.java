package com.example.gestoriaasistente;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONObject;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;

public class CustomerDbHelper extends SQLiteOpenHelper {
    public CustomerDbHelper(Context context) { super(context, "dentaljg.db", null, 6); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE pacientes (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, telefono TEXT NOT NULL, tratamiento TEXT DEFAULT '', total REAL NOT NULL, pagado REAL NOT NULL DEFAULT 0, quincenas INTEGER NOT NULL DEFAULT 1, pago_quincenal REAL NOT NULL DEFAULT 0, numero_poliza TEXT DEFAULT '', clinica TEXT DEFAULT '', remote_id TEXT DEFAULT NULL, payment_method TEXT NOT NULL DEFAULT 'efectivo')");
        db.execSQL("CREATE TABLE pagos (id INTEGER PRIMARY KEY AUTOINCREMENT, paciente_id INTEGER NOT NULL, monto REAL NOT NULL, fecha INTEGER NOT NULL, nota TEXT DEFAULT '', remote_id TEXT DEFAULT NULL)");
        db.execSQL("CREATE TABLE recordatorios (id INTEGER PRIMARY KEY AUTOINCREMENT, paciente_id INTEGER NOT NULL, nota TEXT NOT NULL, fecha INTEGER NOT NULL, hecho INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE quincenas_pagadas (paciente_id INTEGER NOT NULL, periodo TEXT NOT NULL, monto REAL NOT NULL DEFAULT 0, fecha INTEGER NOT NULL, PRIMARY KEY(paciente_id, periodo))");
        db.execSQL("CREATE INDEX IF NOT EXISTS pacientes_remote_id_idx ON pacientes(remote_id)");
        db.execSQL("CREATE INDEX IF NOT EXISTS pagos_remote_id_idx ON pagos(remote_id)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE pacientes ADD COLUMN quincenas INTEGER NOT NULL DEFAULT 1");
            db.execSQL("ALTER TABLE pacientes ADD COLUMN pago_quincenal REAL NOT NULL DEFAULT 0");
            db.execSQL("CREATE TABLE IF NOT EXISTS recordatorios (id INTEGER PRIMARY KEY AUTOINCREMENT, paciente_id INTEGER NOT NULL, nota TEXT NOT NULL, fecha INTEGER NOT NULL, hecho INTEGER NOT NULL DEFAULT 0)");
        }
        if (oldVersion < 3) {
            db.execSQL("CREATE TABLE IF NOT EXISTS quincenas_pagadas (paciente_id INTEGER NOT NULL, periodo TEXT NOT NULL, monto REAL NOT NULL DEFAULT 0, fecha INTEGER NOT NULL, PRIMARY KEY(paciente_id, periodo))");
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE pacientes ADD COLUMN numero_poliza TEXT DEFAULT ''");
            db.execSQL("ALTER TABLE pacientes ADD COLUMN clinica TEXT DEFAULT ''");
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE pacientes ADD COLUMN remote_id TEXT DEFAULT NULL");
            db.execSQL("ALTER TABLE pagos ADD COLUMN remote_id TEXT DEFAULT NULL");
            db.execSQL("CREATE INDEX IF NOT EXISTS pacientes_remote_id_idx ON pacientes(remote_id)");
            db.execSQL("CREATE INDEX IF NOT EXISTS pagos_remote_id_idx ON pagos(remote_id)");
        }
        if (oldVersion < 6) db.execSQL("ALTER TABLE pacientes ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'efectivo'");
        if (oldVersion < 6) db.execSQL("ALTER TABLE pacientes ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'efectivo'");
    }
    public long add(String nombre, String telefono, String tratamiento, double total, int quincenas, double pagoQuincenal, String numeroPoliza, String clinica) {
        ContentValues v = new ContentValues(); v.put("nombre", nombre); v.put("telefono", telefono); v.put("tratamiento", tratamiento); v.put("total", total); v.put("pagado", 0); v.put("quincenas", quincenas); v.put("pago_quincenal", pagoQuincenal); v.put("numero_poliza", numeroPoliza); v.put("clinica", clinica);
        return getWritableDatabase().insert("pacientes", null, v);
    }
    public Cursor transferPatients() { return getReadableDatabase().rawQuery("SELECT id,nombre,telefono,MAX(total-pagado,0) saldo,clinica FROM pacientes WHERE lower(payment_method)='transferencia' ORDER BY nombre COLLATE NOCASE", null); }
    public Cursor all() { return getReadableDatabase().rawQuery("SELECT id,nombre,telefono,tratamiento,total,pagado,MAX(total-pagado,0) saldo,quincenas,pago_quincenal,numero_poliza,clinica FROM pacientes ORDER BY nombre COLLATE NOCASE", null); }
    public Cursor one(long id) { return getReadableDatabase().rawQuery("SELECT id,nombre,telefono,tratamiento,total,pagado,MAX(total-pagado,0) saldo,quincenas,pago_quincenal,numero_poliza,clinica FROM pacientes WHERE id=?", new String[]{String.valueOf(id)}); }
    public void delete(long id) { getWritableDatabase().delete("recordatorios", "paciente_id=?", new String[]{String.valueOf(id)}); getWritableDatabase().delete("pagos", "paciente_id=?", new String[]{String.valueOf(id)}); getWritableDatabase().delete("pacientes", "id=?", new String[]{String.valueOf(id)}); }
    public boolean payment(long id, double amount, String note) {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { ContentValues p=new ContentValues(); p.put("paciente_id",id); p.put("monto",amount); p.put("fecha",System.currentTimeMillis()); p.put("nota",note); db.insertOrThrow("pagos",null,p);
            db.execSQL("UPDATE pacientes SET pagado=MIN(total,pagado+?) WHERE id=?",new Object[]{amount,id}); db.setTransactionSuccessful(); return true;
        } catch(Exception e) { return false; } finally { db.endTransaction(); }
    }
    public long addReminder(long patientId, String note, long date) { ContentValues v=new ContentValues();v.put("paciente_id",patientId);v.put("nota",note);v.put("fecha",date);return getWritableDatabase().insert("recordatorios",null,v); }
    public Cursor reminders() { return getReadableDatabase().rawQuery("SELECT r.id,p.nombre,r.nota,r.fecha,r.hecho,r.paciente_id FROM recordatorios r JOIN pacientes p ON p.id=r.paciente_id WHERE r.hecho=0 ORDER BY r.fecha ASC",null); }
    public void completeReminder(long id) { ContentValues v=new ContentValues();v.put("hecho",1);getWritableDatabase().update("recordatorios",v,"id=?",new String[]{String.valueOf(id)}); }
    public void markFortnightPaid(long patientId, String period, double amount) { ContentValues v=new ContentValues(); v.put("paciente_id",patientId); v.put("periodo",period); v.put("monto",amount); v.put("fecha",System.currentTimeMillis()); getWritableDatabase().insertWithOnConflict("quincenas_pagadas",null,v,SQLiteDatabase.CONFLICT_REPLACE); }
    public boolean isFortnightPaid(long patientId, String period) { Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM quincenas_pagadas WHERE paciente_id=? AND periodo=?",new String[]{String.valueOf(patientId),period}); boolean paid=c.moveToFirst(); c.close(); return paid; }
    public Cursor pendingFortnight(String period) { return getReadableDatabase().rawQuery("SELECT p.id,p.nombre,p.telefono,p.pago_quincenal,MAX(p.total-p.pagado,0) saldo FROM pacientes p LEFT JOIN quincenas_pagadas q ON q.paciente_id=p.id AND q.periodo=? WHERE q.paciente_id IS NULL AND p.total>p.pagado ORDER BY p.nombre COLLATE NOCASE",new String[]{period}); }
    public int pendingFortnightCount(String period) { Cursor c=pendingFortnight(period); int n=c.getCount(); c.close(); return n; }
    public double sumQuincenal(){ double total=0; Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(pago_quincenal),0) FROM pacientes",null); try{if(c.moveToFirst())total=c.getDouble(0);}finally{c.close();} return total; }
    public double sumPaid() { Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(pagado),0) FROM pacientes",null); double n=0; if(c.moveToFirst()) n=c.getDouble(0); c.close(); return n; }
    public double sumPending() { Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(MAX(total-pagado,0)),0) FROM pacientes",null); double n=0; if(c.moveToFirst()) n=c.getDouble(0); c.close(); return n; }
    public int count() { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM pacientes",null); int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n; }
    public Cursor payments(long patientId) { return getReadableDatabase().rawQuery("SELECT monto,fecha,nota FROM pagos WHERE paciente_id=? ORDER BY fecha DESC",new String[]{String.valueOf(patientId)}); }

    public void setRemotePatientId(long localId, String remoteId) {
        ContentValues v = new ContentValues(); v.put("remote_id", remoteId);
        getWritableDatabase().update("pacientes", v, "id=?", new String[]{String.valueOf(localId)});
    }
    public void setRemotePaymentId(long localId, String remoteId) {
        ContentValues v = new ContentValues(); v.put("remote_id", remoteId);
        getWritableDatabase().update("pagos", v, "id=?", new String[]{String.valueOf(localId)});
    }
    public void upsertRemotePatient(JSONObject p) throws Exception {
        String remoteId = p.optString("id", ""); if (remoteId.isEmpty()) return;
        SQLiteDatabase database = getWritableDatabase();
        Cursor c = database.rawQuery("SELECT id FROM pacientes WHERE remote_id=? LIMIT 1", new String[]{remoteId});
        long localId = c.moveToFirst() ? c.getLong(0) : -1; c.close();
        ContentValues v = new ContentValues();
        v.put("remote_id", remoteId); v.put("nombre", p.optString("name", "Paciente"));
        v.put("telefono", p.optString("phone", "")); v.put("tratamiento", p.optString("treatment", ""));
        v.put("total", p.optDouble("total", 0)); v.put("pagado", p.optDouble("paid", 0));
        v.put("quincenas", Math.max(1, p.optInt("installments", 1)));
        v.put("pago_quincenal", p.optDouble("installment_amount", 0));
        v.put("numero_poliza", p.optString("policy_number", "")); v.put("clinica", p.optString("clinic", "")); v.put("payment_method", p.optString("payment_method", "efectivo")); v.put("payment_method", p.optString("payment_method", "efectivo"));
        if (localId >= 0) database.update("pacientes", v, "id=?", new String[]{String.valueOf(localId)});
        else database.insertOrThrow("pacientes", null, v);
    }
    public void upsertRemotePayment(JSONObject p) throws Exception {
        String remoteId = p.optString("id", ""); String patientRemote = p.optString("patient_id", "");
        if (remoteId.isEmpty() || patientRemote.isEmpty()) return;
        SQLiteDatabase database = getWritableDatabase();
        Cursor existing = database.rawQuery("SELECT id FROM pagos WHERE remote_id=? LIMIT 1", new String[]{remoteId});
        boolean found = existing.moveToFirst(); existing.close();
        Cursor patient = database.rawQuery("SELECT id FROM pacientes WHERE remote_id=? LIMIT 1", new String[]{patientRemote});
        if (!patient.moveToFirst()) { patient.close(); return; }
        long localPatientId = patient.getLong(0); patient.close();
        long paidAt = parseRemoteDate(p.optString("paid_at", p.optString("created_at", "")));
        if (!found) {
            ContentValues v = new ContentValues(); v.put("remote_id", remoteId); v.put("paciente_id", localPatientId);
            v.put("monto", p.optDouble("amount", 0)); v.put("fecha", paidAt);
            String note = p.optString("concept", "Abono"); String reference = p.optString("reference", "");
            v.put("nota", reference.isEmpty() ? note : note + " · " + reference);
            database.insertOrThrow("pagos", null, v);
        }
        // Al sincronizar un pago de Cobranza, marcar la quincena de la fecha real del pago
        // para que el paciente deje de aparecer en los pendientes de ese periodo.
        java.util.Calendar calendar = java.util.Calendar.getInstance();
        calendar.setTimeInMillis(paidAt);
        String period = String.format(java.util.Locale.US, "%04d-%02d-Q%d",
                calendar.get(java.util.Calendar.YEAR), calendar.get(java.util.Calendar.MONTH) + 1,
                calendar.get(java.util.Calendar.DAY_OF_MONTH) <= 15 ? 1 : 2);
        markFortnightPaid(localPatientId, period, p.optDouble("amount", 0));
    }
    private long parseRemoteDate(String value) {
        if (value == null || value.isEmpty()) return System.currentTimeMillis();
        String[] patterns = {"yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for (String pattern : patterns) {
            try {
                SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.US);
                f.setTimeZone(TimeZone.getTimeZone("UTC")); ParsePosition pos = new ParsePosition(0);
                java.util.Date d = f.parse(value, pos); if (d != null && pos.getIndex() == value.length()) return d.getTime();
            } catch (Exception ignored) { }
        }
        return System.currentTimeMillis();
    }
}
