package com.example.gestoriaasistente;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

public class GestoriaApplication extends Application {
    public static final String CHANNEL_ID = "quincena_channel_v7";
    @Override public void onCreate() { super.onCreate(); createChannel(this); }
    public static void rebuildChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager != null) manager.deleteNotificationChannel(CHANNEL_ID);
        }
        createChannel(context);
    }
    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Recordatorios de quincena", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Avisos personales y recordatorios para clientes");
            String saved = context.getSharedPreferences("dentaljg", Context.MODE_PRIVATE).getString("tone_uri", "");
            Uri sound = saved.isEmpty() ? android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION) : Uri.parse(saved);
            AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            channel.setSound(sound, attrs);
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }
}
