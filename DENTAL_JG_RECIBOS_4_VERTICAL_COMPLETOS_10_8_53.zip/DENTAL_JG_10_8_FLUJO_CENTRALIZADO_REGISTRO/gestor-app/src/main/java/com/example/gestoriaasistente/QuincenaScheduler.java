package com.example.gestoriaasistente;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/** Agenda avisos dos días antes de cada fecha real de quincena y avisos de cierre. */
public final class QuincenaScheduler {
  private QuincenaScheduler() {}
  public static void scheduleAll(Context context) {
    scheduleQuincena(context, 15, 101);
    scheduleQuincena(context, 30, 102);
    scheduleFixed(context, 4, 103, "Aviso de cierre: revisa y cierra la cobranza del periodo.");
    scheduleFixed(context, 19, 104, "Aviso de cierre: revisa y cierra la cobranza del periodo.");
  }
  private static void scheduleQuincena(Context context, int nominalPayDay, int id) {
    Calendar now=Calendar.getInstance(); now.set(Calendar.SECOND,0); now.set(Calendar.MILLISECOND,0);
    Calendar target=Calendar.getInstance(); target.set(Calendar.HOUR_OF_DAY,9); target.set(Calendar.MINUTE,0); target.set(Calendar.SECOND,0); target.set(Calendar.MILLISECOND,0);
    for(int attempt=0; attempt<3; attempt++) {
      target.set(Calendar.DAY_OF_MONTH,1);
      int last=target.getActualMaximum(Calendar.DAY_OF_MONTH);
      int actualPayDay=(target.get(Calendar.MONTH)==Calendar.FEBRUARY)?last:Math.min(nominalPayDay,last);
      target.set(Calendar.DAY_OF_MONTH,actualPayDay);
      target.add(Calendar.DAY_OF_MONTH,-2);
      target.set(Calendar.HOUR_OF_DAY,9);
      if(target.after(now)) break;
      target=Calendar.getInstance(); target.add(Calendar.MONTH,attempt+1); target.set(Calendar.DAY_OF_MONTH,1);
      target.set(Calendar.HOUR_OF_DAY,9); target.set(Calendar.MINUTE,0); target.set(Calendar.SECOND,0); target.set(Calendar.MILLISECOND,0);
    }
    Calendar payday=(Calendar)target.clone(); payday.add(Calendar.DAY_OF_MONTH,2);
    String payDate=new SimpleDateFormat("d 'de' MMMM",new Locale("es","MX")).format(payday.getTime());
    String message="¡En dos días empieza la quincena!";
    Intent i=new Intent(context,QuincenaReceiver.class).putExtra("message",message).putExtra("schedule_id",id);
    PendingIntent pi=PendingIntent.getBroadcast(context,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
    if(am!=null){if(android.os.Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,target.getTimeInMillis(),pi);else am.set(AlarmManager.RTC_WAKEUP,target.getTimeInMillis(),pi);}
    Calendar transferTarget=(Calendar)target.clone();transferTarget.add(Calendar.DAY_OF_MONTH,1);transferTarget.set(Calendar.HOUR_OF_DAY,9);
    Intent ti=new Intent(context,QuincenaReceiver.class).putExtra("message","¡Enviar mensaje a clientes que pagan por transferencia por favor!").putExtra("schedule_id",id+10);
    PendingIntent tpi=PendingIntent.getBroadcast(context,id+10,ti,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    if(am!=null){if(android.os.Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,transferTarget.getTimeInMillis(),tpi);else am.set(AlarmManager.RTC_WAKEUP,transferTarget.getTimeInMillis(),tpi);}
  }
  private static void scheduleFixed(Context c,int day,int id,String message){
    Calendar now=Calendar.getInstance(),target=Calendar.getInstance();target.set(Calendar.HOUR_OF_DAY,9);target.set(Calendar.MINUTE,0);target.set(Calendar.SECOND,0);target.set(Calendar.MILLISECOND,0);target.set(Calendar.DAY_OF_MONTH,Math.min(day,target.getActualMaximum(Calendar.DAY_OF_MONTH)));
    if(!target.after(now)){target.add(Calendar.MONTH,1);target.set(Calendar.DAY_OF_MONTH,Math.min(day,target.getActualMaximum(Calendar.DAY_OF_MONTH)));}
    Intent i=new Intent(c,QuincenaReceiver.class).putExtra("message",message).putExtra("schedule_id",id);PendingIntent pi=PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null){if(android.os.Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,target.getTimeInMillis(),pi);else am.set(AlarmManager.RTC_WAKEUP,target.getTimeInMillis(),pi);}
  }
}
