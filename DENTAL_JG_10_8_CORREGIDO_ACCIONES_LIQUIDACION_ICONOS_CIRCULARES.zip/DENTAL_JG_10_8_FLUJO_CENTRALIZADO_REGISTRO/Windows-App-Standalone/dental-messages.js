/* DENTAL JG 10.8 — mensajería entre aplicaciones. */
(()=>{'use strict';
 function init(){
  const cfg=window.DENTAL_CONFIG||{};
  if(!window.supabase||!cfg.supabaseUrl||!cfg.supabaseAnonKey)return;
  const path=location.pathname.toLowerCase();
  const role=window.DENTAL_APP_ROLE||(path.includes('registro')?'registro':path.includes('panel')?'admin':path.includes('gestor')?'gestor':'cobranza');
  const storageKey='dental-jg-messages-'+role;
  const client=window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseAnonKey,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false,storageKey}});
  let activeUser=null,activeRole=null,loaded=false,activeToken=null;
  const $=id=>document.getElementById(id);
  const styles=`#djm-launch{position:fixed;right:18px;bottom:18px;z-index:9998;border:0;border-radius:999px;background:#087f8c;color:#fff;font-weight:800;padding:13px 18px;box-shadow:0 8px 26px #0b344233;cursor:pointer;display:block!important}#djm-box{position:fixed;z-index:9999;right:16px;bottom:76px;width:min(440px,calc(100vw - 32px));max-height:75vh;overflow:auto;background:#fff;color:#1b2736;border:1px solid #d9e5ed;border-radius:18px;box-shadow:0 20px 60px #071e3350;padding:16px;font:14px system-ui,sans-serif}#djm-box[hidden]{display:none!important}#djm-box h3{margin:0 0 12px;color:#1769c2}#djm-box label{display:block;font-weight:600;margin:9px 0 4px}#djm-box input,#djm-box textarea,#djm-box select{box-sizing:border-box;width:100%;border:1px solid #cbd8e2;border-radius:9px;padding:10px;font:inherit}#djm-box textarea{min-height:75px;resize:vertical}#djm-box button{border:0;border-radius:9px;padding:9px 12px;cursor:pointer;font-weight:700}#djm-send{background:#087f8c;color:#fff}#djm-close{background:#edf2f6;color:#233}#djm-list{margin:12px 0;display:grid;gap:8px}#djm-list article{background:#f3f8fb;border-radius:10px;padding:10px;overflow-wrap:anywhere}#djm-list small{display:block;color:#607080;margin-top:5px}#djm-status{color:#8a2c2c;white-space:pre-wrap}`;
  const style=document.createElement('style');style.textContent=styles;document.head.appendChild(style);
  const launch=document.createElement('button');launch.id='djm-launch';launch.type='button';launch.textContent='✉ Mensajes entre apps';launch.setAttribute('aria-label','Abrir mensajería entre aplicaciones');document.body.appendChild(launch);
  const box=document.createElement('section');box.id='djm-box';box.hidden=true;box.innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h3>Mensajería DENTAL JG</h3><button id="djm-close" type="button">Cerrar</button></div><p style="margin:0;color:#607080">Envía avisos entre Registro, Cobranza, Gestor y Administración. No incluyas datos clínicos sensibles.</p><label for="djm-target">Enviar a</label><select id="djm-target"><option value="all">Todas las apps</option><option value="registro">Registro de clientes</option><option value="cobranza">Cobranza y recibos</option><option value="gestor">Gestor</option><option value="admin">Administración</option></select><label for="djm-subject">Asunto</label><input id="djm-subject" maxlength="180" placeholder="Asunto del mensaje"><label for="djm-body">Mensaje</label><textarea id="djm-body" maxlength="10000" placeholder="Escribe el aviso..."></textarea><div style="display:flex;gap:8px;align-items:center;margin-top:10px"><button id="djm-send" type="button">Enviar mensaje</button><button id="djm-refresh" type="button">Actualizar</button></div><p id="djm-status" role="status"></p><h3 style="margin-top:14px">Bandeja</h3><div id="djm-list">Inicia sesión para consultar mensajes.</div>`;document.body.appendChild(box);
  launch.onclick=()=>{box.hidden=!box.hidden;if(!box.hidden){if(!activeUser)$('djm-status').textContent='Inicia sesión en esta aplicación. Si ya iniciaste, revisa el rol asignado en Supabase.';loadMessages()}};$('djm-close').onclick=()=>box.hidden=true;
  function readStoredSession(){
   const keys=[];try{const ref=new URL(cfg.supabaseUrl).hostname.split('.')[0];keys.push('sb-'+ref+'-auth-token')}catch(e){}
   keys.push('sb-nfwhymppyzoriihdwlyc-auth-token');
   try{for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&/sb-.+-auth-token$/.test(k))keys.push(k)}}catch(e){}
   for(const k of [...new Set(keys)]){try{const raw=localStorage.getItem(k);if(!raw)continue;const j=JSON.parse(raw);const s=j.currentSession||j.session||j;if(s?.access_token&&s?.refresh_token)return s}catch(e){}}
   return null;
  }
  async function syncSession(){
   const s=readStoredSession();
   if(!s){activeUser=null;activeRole=null;activeToken=null;launch.textContent='✉ Mensajes entre apps';return}
   if(activeUser&&activeToken===s.access_token)return;
   try{const {data,error}=await client.auth.setSession({access_token:s.access_token,refresh_token:s.refresh_token});if(error)throw error;activeToken=s.access_token;const {data:u,error:ue}=await client.auth.getUser();if(ue||!u.user)throw ue||new Error('Sesión no válida');activeUser=u.user;
    const {data:roles,error:re}=await client.from('app_user_roles').select('role').eq('user_id',activeUser.id);
    if(re){activeRole=null;$('djm-status').textContent='No se pudo comprobar el rol. Ejecuta el SQL de mensajería y revisa permisos: '+re.message;launch.textContent='✉ Mensajes entre apps';return}
    const available=(roles||[]).map(x=>x.role);activeRole=available.includes(role)?role:(available.includes('admin')?'admin':available.includes('registro')&&role==='registro'?'registro':available.includes('cobranza')&&role==='cobranza'?'cobranza':available.includes('gestor')&&role==='gestor'?'gestor':null);
    launch.textContent=activeRole?'✉ Mensajes entre apps':'✉ Mensajes (revisar permisos)';if(!loaded){loaded=true;loadMessages()}
   }catch(e){activeUser=null;activeRole=null;activeToken=null;$('djm-status').textContent='No se pudo activar la sesión de mensajería: '+(e?.message||'vuelve a iniciar sesión');}
  }
  async function loadMessages(){if(!activeUser||!activeRole){$('djm-list').textContent='Inicia sesión y asegúrate de tener el rol de esta aplicación en Supabase.';return} $('djm-list').textContent='Cargando…';const {data,error}=await client.from('app_messages').select('id,sender_app,target_app,subject,body,created_at,sender_user_id').order('created_at',{ascending:false}).limit(60);if(error){$('djm-list').textContent='No se pudieron cargar mensajes. Ejecuta el SQL de mensajería en Supabase. '+error.message;return}const rows=data||[];$('djm-list').innerHTML=rows.length?rows.map(m=>`<article><strong>${escapeHtml(m.subject||'(Sin asunto)')}</strong><div>${escapeHtml(m.body)}</div><small>${escapeHtml(m.sender_app)} → ${escapeHtml(m.target_app)} · ${new Date(m.created_at).toLocaleString('es-MX')}</small></article>`).join(''):'No hay mensajes todavía.'}
  function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
  $('djm-refresh').onclick=loadMessages;
  $('djm-send').onclick=async()=>{const body=$('djm-body').value.trim();if(!body){$('djm-status').textContent='Escribe el mensaje antes de enviarlo.';return}if(!activeUser||!activeRole){$('djm-status').textContent='Inicia sesión y verifica los permisos de esta aplicación.';return}const payload={sender_user_id:activeUser.id,sender_app:activeRole,target_app:$('djm-target').value,subject:$('djm-subject').value.trim(),body};$('djm-send').disabled=true;$('djm-status').textContent='Enviando…';const {error}=await client.from('app_messages').insert(payload);$('djm-send').disabled=false;if(error){$('djm-status').textContent='No se pudo enviar. Verifica el SQL y los roles en Supabase. '+error.message;return}$('djm-status').textContent='Mensaje enviado.';$('djm-body').value='';$('djm-subject').value='';await loadMessages()};
  syncSession();setInterval(syncSession,3000);setInterval(()=>{if(!box.hidden&&activeUser)loadMessages()},15000);window.addEventListener('storage',syncSession);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
