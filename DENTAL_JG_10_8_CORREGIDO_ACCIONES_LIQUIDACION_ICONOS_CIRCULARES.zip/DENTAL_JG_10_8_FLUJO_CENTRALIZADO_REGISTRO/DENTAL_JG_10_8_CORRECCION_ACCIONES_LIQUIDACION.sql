-- DENTAL JG 10.8 — corrección de botones, recibo LIQUIDADO y archivo automático inmediato.
-- Ejecutar DESPUÉS de las migraciones base de DENTAL JG, Cobranza, Archivo y Mensajería.
-- No elimina el historial: guarda el expediente, pagos y recibos en patient_account_archive.

begin;

-- La cuenta deja de aparecer entre clientes activos en el mismo momento en que el saldo llega a cero.
-- archive_after se conserva para compatibilidad con la versión anterior, pero ya no espera 3 años.
create or replace function public.set_dental_jg_liquidation_date()
returns trigger language plpgsql set search_path = public as $$
declare was_liquidated boolean := false;
begin
  if TG_OP = 'UPDATE' then
    was_liquidated := coalesce(OLD.total,0) > 0 and coalesce(OLD.paid,0) >= coalesce(OLD.total,0);
  end if;
  if coalesce(NEW.total,0) > 0 and coalesce(NEW.paid,0) >= coalesce(NEW.total,0) then
    if TG_OP = 'INSERT' or not was_liquidated or OLD.liquidated_at is null then
      NEW.liquidated_at := now();
    else
      NEW.liquidated_at := OLD.liquidated_at;
    end if;
    NEW.archive_after := NEW.liquidated_at;
  else
    NEW.liquidated_at := null;
    NEW.archive_after := null;
    NEW.archived_at := null;
  end if;
  NEW.updated_at := now();
  return NEW;
end;
$$;

-- Función interna: crea/actualiza el último recibo con estado LIQUIDADO,
-- guarda el expediente y después retira al cliente de las tablas activas.
create or replace function public.archive_dental_jg_settled_patient(
  p_patient_id uuid,
  p_old_paid numeric default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  p public.patients%rowtype;
  pay public.payments%rowtype;
  settings_row public.collection_receipt_settings%rowtype;
  receipt_row public.collection_receipts%rowtype;
  v_created_by uuid;
  v_folio text;
  v_amount numeric(12,2);
  v_previous numeric(12,2);
  v_tabulator numeric(12,2) := 0;
  v_snapshot jsonb;
  v_data jsonb;
  v_archive_id uuid;
  v_period_entries jsonb := '[]'::jsonb;
  v_portfolio_entries jsonb := '[]'::jsonb;
begin
  select * into p from public.patients where id = p_patient_id for update;
  if not found or coalesce(p.total,0) <= 0 or coalesce(p.paid,0) < coalesce(p.total,0) then
    return;
  end if;

  select * into pay
    from public.payments
   where patient_id = p.id
   order by paid_at desc, created_at desc
   limit 1;

  v_amount := case
    when pay.id is not null then coalesce(pay.amount,0)
    when p_old_paid is not null then greatest(0,coalesce(p.paid,0)-coalesce(p_old_paid,0))
    else coalesce(p.total,0)
  end;
  if v_amount <= 0 then v_amount := coalesce(p.total,0); end if;
  v_previous := least(coalesce(p.total,0), greatest(0, coalesce(p.total,0) - (coalesce(p.paid,0)-v_amount)));
  if v_previous <= 0 then v_previous := least(coalesce(p.total,0),v_amount); end if;

  -- Determina el usuario dueño del recibo. Normalmente será el usuario que registró el último pago.
  select created_by into v_created_by
    from public.collection_receipts
   where patient_id = p.id
   order by created_at desc limit 1;
  if v_created_by is null then
    select r.user_id into v_created_by
      from public.app_user_roles r
     where r.role in ('admin','cobranza')
     order by case r.role when 'admin' then 1 else 2 end
     limit 1;
  end if;
  if v_created_by is null then v_created_by := auth.uid(); end if;
  if v_created_by is null then
    select r.user_id into v_created_by
      from public.app_user_roles r
     where r.role in ('registro','gestor')
     order by case r.role when 'registro' then 1 else 2 end
     limit 1;
  end if;
  if v_created_by is null then
    select id into v_created_by from auth.users order by created_at limit 1;
  end if;

  if v_created_by is not null then
    insert into public.collection_receipt_settings(user_id) values(v_created_by)
      on conflict(user_id) do nothing;
    select * into settings_row from public.collection_receipt_settings where user_id=v_created_by for update;
    v_tabulator := coalesce(settings_row.tabulator_default,0);
    v_snapshot := jsonb_build_object(
      'title',coalesce(settings_row.receipt_title,'RECIBO DE COBRANZA'),
      'footer',coalesce(settings_row.receipt_footer,''),
      'logo','logo-dental-jg.png',
      'date',to_char(coalesce(pay.paid_at,now()) at time zone 'America/Mexico_City','YYYY-MM-DD'),
      'nextDate','',
      'holder',coalesce(to_jsonb(p)->>'holder',p.name,''),
      'address',coalesce(to_jsonb(p)->>'address',''),
      'contract',coalesce(to_jsonb(p)->>'contract_number',to_jsonb(p)->>'policy_number',''),
      'phone',coalesce(to_jsonb(p)->>'phone',''),
      'policy',coalesce(to_jsonb(p)->>'treatment',to_jsonb(p)->>'policy_type',to_jsonb(p)->>'policy_number','Básica'),
      'mode','Quincenal',
      'paymentNumber',greatest(1,coalesce(p.installments,1)),
      'paymentTotal',greatest(1,coalesce(p.installments,1)),
      'folioPrefix',coalesce(settings_row.folio_prefix,'JG-'),
      'currency','MXN',
      'status','LIQUIDADO',
      'liquidated',true
    );

    -- Si ya había un recibo para el último pago, lo convierte en recibo de liquidación.
    if pay.id is not null then
      select * into receipt_row from public.collection_receipts
       where payment_id=pay.id order by created_at desc limit 1 for update;
    else
      select * into receipt_row from public.collection_receipts
       where patient_id=p.id order by created_at desc limit 1 for update;
    end if;

    if receipt_row.id is not null then
      update public.collection_receipts
         set new_balance=0,
             previous_balance=v_previous,
             concept=case when coalesce(collection_receipts.concept,'')='' then 'Liquidación de saldo' else collection_receipts.concept end,
             receipt_snapshot=coalesce(collection_receipts.receipt_snapshot,'{}'::jsonb)||v_snapshot||jsonb_build_object('status','LIQUIDADO','liquidated',true)
       where id=receipt_row.id;
    else
      v_folio := coalesce(settings_row.folio_prefix,'JG-') ||
        lpad(settings_row.next_folio::text,greatest(settings_row.folio_digits,length(settings_row.next_folio::text)),'0');
      update public.collection_receipt_settings set next_folio=next_folio+1,updated_at=now() where user_id=v_created_by;
      insert into public.collection_receipts(
        created_by,folio,payment_id,patient_id,patient_name,clinic,payment_amount,
        previous_balance,tabulator,net_amount,new_balance,concept,notes,receipt_snapshot
      ) values(
        v_created_by,v_folio,pay.id,p.id,coalesce(p.name,''),coalesce(p.clinic,''),v_amount,
        v_previous,v_tabulator,greatest(0,v_amount-v_tabulator),0,
        'Liquidación de saldo',coalesce(pay.reference,''),
        v_snapshot||jsonb_build_object('status','LIQUIDADO','liquidated',true)
      ) returning * into receipt_row;
    end if;
  end if;

  -- Snapshot completo antes de borrar los registros operativos.
  select jsonb_build_object(
    'patient',to_jsonb(p),
    'payments',coalesce((select jsonb_agg(to_jsonb(x) order by x.paid_at,x.created_at) from public.payments x where x.patient_id=p.id),'[]'::jsonb),
    'receipts',coalesce((select jsonb_agg(to_jsonb(x) order by x.created_at) from public.collection_receipts x where x.patient_id=p.id),'[]'::jsonb)
  ) into v_data;
  v_data := v_data || jsonb_build_object('liquidation_status','LIQUIDADO','liquidated_at',coalesce(p.liquidated_at,now()));

  if to_regclass('public.collection_period_patients') is not null then
    execute 'select coalesce(jsonb_agg(to_jsonb(x)), ''[]''::jsonb) from public.collection_period_patients x where x.patient_id = $1'
      into v_period_entries using p.id;
    v_data := v_data || jsonb_build_object('collection_period_patients',v_period_entries);
  end if;
  if to_regclass('public.collection_portfolio_patients') is not null then
    execute 'select coalesce(jsonb_agg(to_jsonb(x)), ''[]''::jsonb) from public.collection_portfolio_patients x where x.patient_id = $1'
      into v_portfolio_entries using p.id;
    v_data := v_data || jsonb_build_object('collection_portfolio_patients',v_portfolio_entries);
  end if;

  insert into public.patient_account_archive(
    original_patient_id,patient_name,clinic,liquidated_at,archived_at,archive_data,
    deletion_completed_at,archive_reason,restored_at
  ) values (
    p.id,coalesce(p.name,''),coalesce(p.clinic,''),coalesce(p.liquidated_at,now()),now(),v_data,now(),'LIQUIDADO',null
  ) on conflict do nothing returning id into v_archive_id;

  -- Si existía un expediente anterior con restricción de ID único, actualiza ese registro sin perder la copia reciente.
  if v_archive_id is null then
    update public.patient_account_archive
       set patient_name=coalesce(p.name,''),clinic=coalesce(p.clinic,''),liquidated_at=coalesce(p.liquidated_at,now()),
           archived_at=now(),archive_data=v_data,deletion_completed_at=now(),archive_reason='LIQUIDADO',restored_at=null
     where id=(select id from public.patient_account_archive where original_patient_id=p.id order by archived_at desc limit 1);
  end if;

  if to_regclass('public.collection_period_patients') is not null then
    execute 'delete from public.collection_period_patients where patient_id = $1' using p.id;
  end if;
  if to_regclass('public.collection_portfolio_patients') is not null then
    execute 'delete from public.collection_portfolio_patients where patient_id = $1' using p.id;
  end if;
  -- Los recibos permanecen consultables/imprimibles en Cobranza; al borrar al paciente,
  -- patient_id queda NULL por la FK ON DELETE SET NULL. El archivo también conserva la copia.
  delete from public.payments where patient_id=p.id;
  delete from public.patients where id=p.id;
end;
$$;

-- Cobranza debe poder consultar/imprimir los recibos automáticos aunque el pago se haya registrado desde Gestor.
drop policy if exists "dental jg staff view all receipts" on public.collection_receipts;
create policy "dental jg staff view all receipts"
  on public.collection_receipts for select to authenticated
  using (exists (select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('admin','cobranza','registro','gestor')));

revoke all on function public.archive_dental_jg_settled_patient(uuid,numeric) from public,anon,authenticated;

create or replace function public.auto_archive_dental_jg_settled_patient_trigger()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if coalesce(NEW.total,0)>0 and coalesce(NEW.paid,0)>=coalesce(NEW.total,0)
     and (coalesce(OLD.total,0)<=0 or coalesce(OLD.paid,0)<coalesce(OLD.total,0)) then
    perform public.archive_dental_jg_settled_patient(NEW.id,OLD.paid);
  end if;
  return NEW;
end;
$$;
revoke all on function public.auto_archive_dental_jg_settled_patient_trigger() from public,anon,authenticated;
drop trigger if exists trg_dental_jg_auto_archive_settled on public.patients;
create trigger trg_dental_jg_auto_archive_settled
after update of total,paid on public.patients
for each row execute function public.auto_archive_dental_jg_settled_patient_trigger();

-- Migra también los clientes que ya estaban liquidados antes de instalar esta corrección.
do $$
declare r record;
begin
  for r in select id,paid from public.patients where coalesce(total,0)>0 and coalesce(paid,0)>=coalesce(total,0) loop
    perform public.archive_dental_jg_settled_patient(r.id,r.paid);
  end loop;
end $$;

commit;

-- Comprobación posterior:
-- SELECT patient_name,archive_reason,liquidated_at,archived_at,archive_data->>'liquidation_status'
-- FROM public.patient_account_archive ORDER BY archived_at DESC LIMIT 20;
-- SELECT folio,patient_name,concept,new_balance,receipt_snapshot->>'status'
-- FROM public.collection_receipts ORDER BY created_at DESC LIMIT 20;
