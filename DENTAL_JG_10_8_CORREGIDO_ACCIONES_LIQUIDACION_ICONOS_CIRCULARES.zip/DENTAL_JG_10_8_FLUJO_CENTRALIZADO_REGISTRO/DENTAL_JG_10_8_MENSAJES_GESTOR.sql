-- DENTAL JG 10.8 — mensajería interna entre aplicaciones
-- Migración ADITIVA: no borra ni modifica pacientes, pagos ni tablas existentes.
-- Requiere que public.app_user_roles exista y contenga roles: registro, cobranza, gestor, admin.
-- Ejecutar una sola vez desde Supabase > SQL Editor, con una cuenta administradora del proyecto.

begin;

create table if not exists public.app_messages (
  id uuid primary key default gen_random_uuid(),
  sender_user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  sender_app text not null check (sender_app in ('registro','cobranza','gestor','admin')),
  target_app text not null check (target_app in ('registro','cobranza','gestor','admin','all')),
  recipient_user_id uuid null references auth.users(id) on delete cascade,
  subject text not null default '' check (char_length(subject) <= 180),
  body text not null check (char_length(trim(body)) between 1 and 10000),
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  expires_at timestamptz null,
  constraint app_messages_expiry_valid check (expires_at is null or expires_at > created_at)
);

create index if not exists app_messages_target_created_idx
  on public.app_messages (target_app, created_at desc);
create index if not exists app_messages_recipient_created_idx
  on public.app_messages (recipient_user_id, created_at desc);
create index if not exists app_messages_sender_created_idx
  on public.app_messages (sender_user_id, created_at desc);

alter table public.app_messages enable row level security;
revoke all on public.app_messages from anon;
grant select, insert on public.app_messages to authenticated;

-- Solo puede leer un mensaje su destinatario (usuario/rol), el emisor o un administrador.
drop policy if exists "app messages visible to intended apps" on public.app_messages;
create policy "app messages visible to intended apps"
  on public.app_messages for select to authenticated
  using (
    sender_user_id = auth.uid()
    or exists (
      select 1 from public.app_user_roles r
      where r.user_id = auth.uid() and r.role = 'admin'
    )
    or (
      (recipient_user_id is null or recipient_user_id = auth.uid())
      and exists (
        select 1 from public.app_user_roles r
        where r.user_id = auth.uid()
          and (r.role = app_messages.target_app or app_messages.target_app = 'all')
      )
    )
  );

-- El usuario solo puede enviar desde un rol que realmente tenga asignado.
drop policy if exists "app messages insert with assigned role" on public.app_messages;
create policy "app messages insert with assigned role"
  on public.app_messages for insert to authenticated
  with check (
    sender_user_id = auth.uid()
    and exists (
      select 1 from public.app_user_roles r
      where r.user_id = auth.uid() and r.role = app_messages.sender_app
    )
    and (
      target_app <> 'admin'
      or exists (
        select 1 from public.app_user_roles r
        where r.user_id = auth.uid() and r.role = 'admin'
      )
    )
  );

-- Confirmación de lectura individual: cada usuario puede marcar sus propios mensajes recibidos.
create table if not exists public.app_message_reads (
  message_id uuid not null references public.app_messages(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  read_at timestamptz not null default now(),
  primary key (message_id, user_id)
);
create index if not exists app_message_reads_user_idx
  on public.app_message_reads (user_id, read_at desc);

alter table public.app_message_reads enable row level security;
revoke all on public.app_message_reads from anon;
grant select, insert on public.app_message_reads to authenticated;

drop policy if exists "users view own message read receipts" on public.app_message_reads;
create policy "users view own message read receipts"
  on public.app_message_reads for select to authenticated
  using (user_id = auth.uid());

drop policy if exists "users mark messages they can receive as read" on public.app_message_reads;
create policy "users mark messages they can receive as read"
  on public.app_message_reads for insert to authenticated
  with check (
    user_id = auth.uid()
    and exists (
      select 1 from public.app_messages m
      where m.id = app_message_reads.message_id
        and (m.recipient_user_id is null or m.recipient_user_id = auth.uid())
        and (
          exists (select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin')
          or exists (
            select 1 from public.app_user_roles r
            where r.user_id=auth.uid()
              and (r.role = m.target_app or m.target_app = 'all')
          )
        )
    )
  );

-- Permite que los clientes suscritos a Supabase Realtime reciban mensajes nuevos.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (
      select 1 from pg_publication_tables
      where pubname='supabase_realtime' and schemaname='public' and tablename='app_messages'
    ) then
      alter publication supabase_realtime add table public.app_messages;
    end if;
    if not exists (
      select 1 from pg_publication_tables
      where pubname='supabase_realtime' and schemaname='public' and tablename='app_message_reads'
    ) then
      alter publication supabase_realtime add table public.app_message_reads;
    end if;
  end if;
end $$;

commit;

-- IMPORTANTE:
-- 1) Este SQL crea el almacenamiento seguro de mensajes; por sí solo no añade botones ni llamadas
--    a la app Android. Gestor y las demás apps deben implementar POST/GET a /rest/v1/app_messages
--    y, opcionalmente, escribir lecturas en /rest/v1/app_message_reads.
-- 2) Primero asigna el rol correcto en public.app_user_roles a cada usuario de Supabase Auth.
-- 3) No envíes información clínica sensible en el cuerpo de los mensajes.
