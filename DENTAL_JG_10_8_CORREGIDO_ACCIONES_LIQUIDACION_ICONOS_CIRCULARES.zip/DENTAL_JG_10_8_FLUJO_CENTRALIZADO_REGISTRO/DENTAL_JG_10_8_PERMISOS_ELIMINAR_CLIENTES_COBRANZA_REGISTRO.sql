-- DENTAL JG 10.8 — Habilitar archivado/eliminación de clientes desde Cobranza y Registro.
-- Ejecutar en Supabase > SQL Editor del MISMO proyecto usado por las apps.
-- No borra datos permanentemente: archive_patient_account guarda expediente, pagos y recibos antes de retirarlos.
-- Los usuarios deben tener uno de estos roles en public.app_user_roles: admin, cobranza o registro.

create or replace function public.archive_patient_account(p_patient_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  p public.patients%rowtype;
  v_data jsonb;
  v_archive_id uuid;
  v_period_entries jsonb := '[]'::jsonb;
  v_portfolio_entries jsonb := '[]'::jsonb;
begin
  if auth.uid() is null or not exists (
    select 1 from public.app_user_roles r
    where r.user_id = auth.uid() and r.role in ('admin','cobranza','registro')
  ) then
    raise exception 'Solo las cuentas autorizadas de Cobranza, Registro o administración pueden archivar clientes' using errcode = '42501';
  end if;

  select * into p from public.patients where id = p_patient_id for update;
  if not found then raise exception 'No se encontró el cliente activo'; end if;

  select jsonb_build_object(
    'patient', to_jsonb(p),
    'payments', coalesce((select jsonb_agg(to_jsonb(x) order by x.paid_at, x.created_at) from public.payments x where x.patient_id = p.id), '[]'::jsonb),
    'receipts', coalesce((select jsonb_agg(to_jsonb(x) order by x.created_at) from public.collection_receipts x where x.patient_id = p.id), '[]'::jsonb)
  ) into v_data;

  if to_regclass('public.collection_period_patients') is not null then
    execute 'select coalesce(jsonb_agg(to_jsonb(x)), ''[]''::jsonb) from public.collection_period_patients x where x.patient_id = $1' into v_period_entries using p.id;
    v_data := v_data || jsonb_build_object('collection_period_patients', v_period_entries);
  end if;
  if to_regclass('public.collection_portfolio_patients') is not null then
    execute 'select coalesce(jsonb_agg(to_jsonb(x)), ''[]''::jsonb) from public.collection_portfolio_patients x where x.patient_id = $1' into v_portfolio_entries using p.id;
    v_data := v_data || jsonb_build_object('collection_portfolio_patients', v_portfolio_entries);
  end if;

  insert into public.patient_account_archive(original_patient_id, patient_name, clinic, liquidated_at, archived_at, archive_data, deletion_completed_at, archive_reason, restored_at)
  values (p.id, p.name, coalesce(p.clinic,''), p.liquidated_at, now(), v_data, now(), 'MANUAL', null)
  returning id into v_archive_id;

  if to_regclass('public.collection_period_patients') is not null then
    execute 'delete from public.collection_period_patients where patient_id = $1' using p.id;
  end if;
  if to_regclass('public.collection_portfolio_patients') is not null then
    execute 'delete from public.collection_portfolio_patients where patient_id = $1' using p.id;
  end if;
  delete from public.collection_receipts where patient_id = p.id;
  delete from public.payments where patient_id = p.id;
  delete from public.patients where id = p.id;
  return v_archive_id;
end;
$$;

revoke all on function public.archive_patient_account(uuid) from public, anon;
grant execute on function public.archive_patient_account(uuid) to authenticated;
