(() => {
  const cfg = window.DENTAL_CONFIG || {};
  const configured = cfg.supabaseUrl && cfg.supabaseAnonKey && !cfg.supabaseUrl.includes('PEGA_AQUI') && !cfg.supabaseAnonKey.includes('PEGA_AQUI');
  const $ = id => document.getElementById(id);
  function runBrandIntro(){const intro=$('brandIntro');if(!intro)return;try{if(!sessionStorage.getItem('dentalIntroSeen')){const AC=window.AudioContext||window.webkitAudioContext;if(AC){const ac=new AC();const osc=ac.createOscillator(),gain=ac.createGain();osc.type='sine';osc.frequency.setValueAtTime(660,ac.currentTime);osc.frequency.exponentialRampToValueAtTime(880,ac.currentTime+.16);gain.gain.setValueAtTime(.0001,ac.currentTime);gain.gain.exponentialRampToValueAtTime(.045,ac.currentTime+.035);gain.gain.exponentialRampToValueAtTime(.0001,ac.currentTime+.28);osc.connect(gain);gain.connect(ac.destination);osc.start();osc.stop(ac.currentTime+.29);}sessionStorage.setItem('dentalIntroSeen','1');}}catch(e){}setTimeout(()=>intro.classList.add('done'),1550);}
  runBrandIntro();
  let client = null, channel = null, patients = [], payments = [], clinics = [], clinicTableAvailable = true, refreshTimer = null, loadInProgress = false, loadAgain = false;
  let selectedClinic = '__all__', warnedClinicTable = false;
  const money = n => new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN',maximumFractionDigits:2}).format(Number(n)||0);
  const date = s => s ? new Intl.DateTimeFormat('es-MX',{dateStyle:'medium',timeStyle:'short'}).format(new Date(s)) : '—';
  const safe = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function toast(s){$('toast').textContent=s;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),3000)}
  function msg(s){$('loginMessage').textContent=s}
  function connection(ok,label){$('connectionDot').classList.toggle('ok',!!ok);$('connectionText').textContent=label}
  function showApp(){ $('loginView').classList.add('hidden');$('appView').classList.remove('hidden');$('todayLabel').textContent=new Intl.DateTimeFormat('es-MX',{dateStyle:'medium'}).format(new Date()); }
  function logout(){if(channel&&client)client.removeChannel(channel);channel=null;if(refreshTimer)clearInterval(refreshTimer);refreshTimer=null;patients=[];payments=[];clinics=[];$('appView').classList.add('hidden');$('loginView').classList.remove('hidden');if(client)client.auth.signOut();}
  function goto(page){document.querySelectorAll('.page').forEach(p=>p.classList.add('hidden'));$(page+'Page').classList.remove('hidden');document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.page===page));$('pageTitle').textContent=({overview:'Resumen general',patients:'Pacientes',payments:'Cobranza',clinics:'Clínicas',receipts:'Diseño e impresión de recibos'})[page]||'DENTAL JG';}
  function nameFor(id){return patients.find(p=>p.id===id)?.name||'Paciente';}
  function clinicForPayment(p){const patient=patients.find(x=>x.id===p.patient_id);return String(patient?.clinic||p.clinic||'').trim();}
  function clinicMatches(name){return selectedClinic==='__all__'||String(name||'').trim()===selectedClinic;}
  function filteredPatients(){return patients.filter(p=>clinicMatches(p.clinic));}
  function filteredPayments(){return payments.filter(p=>clinicMatches(clinicForPayment(p)));}
  function renderClinicControls(){
    const filter=$('clinicFilter');if(!filter)return;
    const names=[...new Set([...clinics.map(c=>c.name),...patients.map(p=>String(p.clinic||'').trim()).filter(Boolean)])].sort((a,b)=>a.localeCompare(b,'es'));
    filter.innerHTML='<option value="__all__">Todas las clínicas</option>'+names.map(n=>`<option value="${safe(n)}">${safe(n)}</option>`).join('');
    if(selectedClinic!=='__all__'&&!names.includes(selectedClinic))selectedClinic='__all__';filter.value=selectedClinic;
    const patientClinic=$('patientClinic');
    if(patientClinic){const previous=patientClinic.value;patientClinic.innerHTML='<option value="">Selecciona una clínica</option>'+names.map(n=>`<option value="${safe(n)}">${safe(n)}</option>`).join('');if(names.includes(previous))patientClinic.value=previous;else if(selectedClinic!=='__all__'&&names.includes(selectedClinic))patientClinic.value=selectedClinic;}
  }
  function renderClinics(){
    const names=[...new Set([...clinics.map(c=>c.name),...patients.map(p=>String(p.clinic||'').trim()).filter(Boolean)])].sort((a,b)=>a.localeCompare(b,'es'));
    $('clinicCount').textContent=`${names.length} ${names.length===1?'clínica':'clínicas'}`;
    $('clinicRows').innerHTML=names.length?names.map(n=>{const count=patients.filter(p=>String(p.clinic||'').trim()===n).length;const c=clinics.find(x=>x.name===n);return `<tr><td><span class="clinic-tag">${safe(n)}</span>${c?'':'<small class="legacy-clinic-note"> · nombre encontrado en pacientes</small>'}</td><td>${count}</td><td class="clinic-actions"><button class="small-action" data-select-clinic="${safe(n)}" type="button">Ver pacientes</button>${c?` <button class="small-action" data-edit-clinic="${safe(c.id)}" type="button">Editar nombre</button> <button class="small-action danger-action" data-delete-clinic="${safe(c.id)}" type="button">Eliminar</button>`:' <span class="legacy-clinic-note">Registra esta clínica para editarla</span>'}</td></tr>`}).join(''):'<tr><td colspan="3" class="empty">Todavía no hay clínicas. Agrega la primera arriba.</td></tr>';
    document.querySelectorAll('[data-select-clinic]').forEach(b=>b.addEventListener('click',()=>{selectedClinic=b.dataset.selectClinic;renderClinicControls();render();goto('patients');toast('Mostrando pacientes de: '+selectedClinic)}));
    document.querySelectorAll('[data-edit-clinic]').forEach(b=>b.addEventListener('click',()=>editClinic(b.dataset.editClinic)));
    document.querySelectorAll('[data-delete-clinic]').forEach(b=>b.addEventListener('click',()=>deleteClinic(b.dataset.deleteClinic)));
  }
  async function editClinic(id){
    const clinic=clinics.find(c=>String(c.id)===String(id));if(!clinic)return;
    const next=(window.prompt('Escribe el nuevo nombre de la clínica:',clinic.name)||'').trim();if(!next||next===clinic.name)return;
    if([...clinics].some(c=>String(c.id)!==String(id)&&String(c.name||'').toLocaleLowerCase('es-MX')===next.toLocaleLowerCase('es-MX'))){toast('Ya existe una clínica con ese nombre.');return;}
    const old=clinic.name;
    const {error}=await client.from('clinics').update({name:next}).eq('id',id);
    if(error){console.error(error);toast('No se pudo modificar la clínica: '+(error.message||'revisa los permisos.'));return;}
    const {error:patientError}=await client.from('patients').update({clinic:next}).eq('clinic',old);
    if(patientError){console.error(patientError);toast('Se cambió el nombre, pero algunos pacientes podrían conservar el anterior. Actualiza y revisa los pacientes.');}else toast('Nombre de clínica actualizado.');
    if(selectedClinic===old)selectedClinic=next;await load(true);
  }
  async function deleteClinic(id){
    const clinic=clinics.find(c=>String(c.id)===String(id));if(!clinic)return;
    const count=patients.filter(p=>String(p.clinic||'').trim()===clinic.name).length;
    const detail=count?` Hay ${count} paciente(s) asignado(s); se quitará su asignación de clínica, pero sus expedientes y pagos se conservarán.`:' Esta acción no se puede deshacer.';
    if(!window.confirm(`¿Eliminar la clínica “${clinic.name}”?${detail}`))return;
    if(count){const {error}=await client.from('patients').update({clinic:''}).eq('clinic',clinic.name);if(error){console.error(error);toast('No se pudo desasignar a los pacientes. La clínica no se eliminó.');return;}}
    const {error}=await client.from('clinics').delete().eq('id',id);
    if(error){console.error(error);toast('No se pudo eliminar la clínica: '+(error.message||'revisa los permisos.'));return;}
    if(selectedClinic===clinic.name)selectedClinic='__all__';await load(true);toast('Clínica eliminada. Los expedientes y pagos se conservaron.');
  }
  function render(){
    renderClinicControls();
    const visiblePatients=filteredPatients(), visiblePayments=filteredPayments();
    const paid = visiblePatients.filter(p=>Number(p.total||0)-Number(p.paid||0)<=0).length;
    const collected = visiblePatients.reduce((s,p)=>s+Math.max(0,Number(p.installment_amount||0)),0);
    const pending = visiblePayments.reduce((s,p)=>s+Number(p.amount||0),0);
    $('metricPatients').textContent=visiblePatients.length.toLocaleString('es-MX');$('metricCollected').textContent=money(collected);$('metricPending').textContent=money(pending);$('metricPaid').textContent=paid.toLocaleString('es-MX');
    const recent=[...visiblePayments].sort((a,b)=>new Date(b.paid_at||b.created_at)-new Date(a.paid_at||a.created_at)).slice(0,7);
    $('recentRows').innerHTML=recent.length?recent.map(p=>`<tr><td>${safe(p.patient_name||nameFor(p.patient_id))}</td><td><span class="pill">Pago registrado</span></td><td>${safe(date(p.paid_at||p.created_at))}</td><td class="money">${money(p.amount)}</td></tr>`).join(''):'<tr><td colspan="4" class="empty">Todavía no hay pagos registrados para esta selección.</td></tr>';
    const term=($('patientSearch')?.value||'').toLowerCase();const list=visiblePatients.filter(p=>[p.name,p.phone,p.clinic,p.policy_number].some(x=>String(x||'').toLowerCase().includes(term)));
    $('patientRows').innerHTML=list.length?list.map(p=>`<tr class="patient-row" data-open-patient="${safe(p.id)}" tabindex="0" role="button" aria-label="Abrir expediente de ${safe(p.name)}"><td><button type="button" class="patient-name-link" data-open-patient="${safe(p.id)}">${safe(p.name)}</button></td><td>${safe(p.phone||'—')}</td><td>${safe(p.clinic||'—')}</td><td>${safe(p.policy_number||'—')}</td><td>${money(p.total)}</td><td>${money(p.paid)}</td><td class="money">${money(Math.max(0,Number(p.total||0)-Number(p.paid||0)))}</td></tr>`).join(''):'<tr><td colspan="7" class="empty">No se encontraron pacientes para esta selección.</td></tr>';
    
    const pt=($('paymentSearch')?.value||'').toLowerCase();const plist=[...visiblePayments].filter(p=>String(p.patient_name||nameFor(p.patient_id)).toLowerCase().includes(pt)).sort((a,b)=>new Date(b.paid_at||b.created_at)-new Date(a.paid_at||a.created_at));
    $('paymentRows').innerHTML=plist.length?plist.map(p=>`<tr><td>${safe(p.patient_name||nameFor(p.patient_id))}</td><td>${safe(date(p.paid_at||p.created_at))}</td><td>${safe(p.concept||'Abono')}</td><td class="money">${money(p.amount)}</td><td>${safe(p.reference||'—')}</td></tr>`).join(''):'<tr><td colspan="5" class="empty">Todavía no hay pagos registrados para esta selección.</td></tr>';
    renderClinics();
  }
  async function load(silent=false){
    if(!client)return;
    if(loadInProgress){loadAgain=true;return;}
    loadInProgress=true;
    if(!silent)connection(false,'Actualizando…');
    try {
      const [pr,pa,cr]=await Promise.all([
        client.from('patients').select('*').order('created_at',{ascending:false}),
        client.from('payments').select('*').order('paid_at',{ascending:false}),
        client.from('clinics').select('*').order('name',{ascending:true})
      ]);
      if(pr.error||pa.error){connection(false,'Error de conexión');const detail=(pr.error&&pr.error.message)||(pa.error&&pa.error.message)||'Revisa tablas y permisos.';if(!silent)toast('No se pudieron leer los datos: '+detail);console.error(pr.error,pa.error);return;}
      patients=pr.data||[];payments=pa.data||[];
      clinicTableAvailable=!cr.error;clinics=cr.error?[]:(cr.data||[]);
      if(cr.error&&!warnedClinicTable){warnedClinicTable=true;toast('No se pudo leer la lista de clínicas. Revisa la tabla public.clinics y sus permisos.');console.warn('No se pudo leer clinics',cr.error);}
      render();connection(true,'En línea · actualizado automáticamente');
      const openId=$('patientDialog')?.dataset.patientId;
      if(openId&&!$('patientDialog').classList.contains('hidden'))openPatient(openId,false);
    } catch(err){console.error(err);connection(false,'Sin conexión');if(!silent)toast('No se pudo actualizar. Revisa tu conexión.');}
    finally {loadInProgress=false;if(loadAgain){loadAgain=false;load(true);}}
  }
  function realtime(){
    if(channel)client.removeChannel(channel);
    channel=client.channel('dental-jg-live').on('postgres_changes',{event:'*',schema:'public',table:'patients'},()=>load(true)).on('postgres_changes',{event:'*',schema:'public',table:'payments'},()=>load(true)).on('postgres_changes',{event:'*',schema:'public',table:'clinics'},()=>load(true)).subscribe(status=>{if(status==='SUBSCRIBED')connection(true,'En línea · actualizado automáticamente');else if(status==='CHANNEL_ERROR'||status==='TIMED_OUT')connection(false,'Reintentando conexión…');});
    if(refreshTimer)clearInterval(refreshTimer);
    refreshTimer=setInterval(()=>{if(document.visibilityState==='visible'&&client&&!$('appView').classList.contains('hidden'))load(true)},5000);
  }
  async function archiveDeletePatient(id){
    const p=patients.find(item=>String(item.id)===String(id));if(!p)return;
    const remaining=Math.max(0,Number(p.total||0)-Number(p.paid||0));
    const message=`Vas a eliminar manualmente a “${p.name}”.\n\nAntes de borrarlo, DENTAL JG guardará una copia histórica de su expediente, pagos y recibos en Supabase. Después desaparecerá de los pacientes activos.\n\nSaldo pendiente: ${money(remaining)}\n\nEsta acción no se puede deshacer desde la app. ¿Deseas continuar?`;
    if(!window.confirm(message))return;
    const button=$('deletePatientManual');if(button){button.disabled=true;button.textContent='Archivando y eliminando…';}
    const {data,error}=await client.rpc('archive_patient_account',{p_patient_id:p.id});
    if(button){button.disabled=false;button.textContent='Archivar y eliminar cliente';}
    if(error){console.error(error);toast('No se pudo eliminar. Verifica que ejecutaste el SQL de archivo y que tu usuario tenga rol admin. Detalle: '+(error.message||'error'));return;}
    const dialog=$('patientDialog');dialog.classList.add('hidden');dialog.setAttribute('aria-hidden','true');delete dialog.dataset.patientId;
    toast('Cliente archivado y eliminado de los activos.');await load(true);
  }
  function openPatient(id,focus=true){
    const p=patients.find(item=>String(item.id)===String(id));if(!p){toast('No encontré ese paciente. Actualizando…');load();return;}
    const dialog=$('patientDialog');if(!dialog)return;dialog.dataset.patientId=String(p.id);
    const paid=Number(p.paid||0),total=Number(p.total||0),remaining=Math.max(0,total-paid);
    const detailRows=[['Clínica',p.clinic||'—'],['Teléfono',p.phone||'—'],['Tratamiento',p.treatment||'—'],['Número de póliza',p.policy_number||'—'],['Costo total',money(total)],['Pagado',money(paid)],['Saldo pendiente',money(remaining)],['Número de pagos',String(p.installments??'—')],['Importe por pago',money(p.installment_amount||0)]];
    $('patientDialogTitle').textContent=p.name||'Expediente del paciente';
    $('patientDialogDetails').innerHTML=detailRows.map(([label,value])=>`<div class="detail-item"><small>${safe(label)}</small><strong>${safe(value)}</strong></div>`).join('');
    const history=payments.filter(x=>String(x.patient_id||'')===String(p.id)||(String(x.patient_name||'').trim().toLocaleLowerCase('es-MX')===String(p.name||'').trim().toLocaleLowerCase('es-MX'))).sort((a,b)=>new Date(b.paid_at||b.created_at)-new Date(a.paid_at||a.created_at));
    $('patientDialogPayments').innerHTML=history.length?history.map(x=>`<tr><td>${safe(date(x.paid_at||x.created_at))}</td><td>${safe(x.concept||'Abono')}</td><td>${money(x.amount)}</td><td>${safe(x.reference||'—')}</td></tr>`).join(''):'<tr><td colspan="4" class="empty">Este paciente todavía no tiene pagos registrados.</td></tr>';
    dialog.classList.remove('hidden');dialog.setAttribute('aria-hidden','false');if(focus)$('closePatientDialog').focus();
  }
  document.addEventListener('click',e=>{const target=e.target.closest('[data-open-patient]');if(target){e.preventDefault();e.stopPropagation();openPatient(target.dataset.openPatient);}});document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('tr[data-open-patient]')){e.preventDefault();openPatient(e.target.dataset.openPatient);}});
  $('loginForm').addEventListener('submit',async e=>{e.preventDefault();if(!configured){$('setupNotice').classList.remove('hidden');msg('Primero configura config.js siguiendo LEEME.txt.');return;}msg('Validando acceso…');if(!client)client=window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseAnonKey,{auth:{persistSession:true,autoRefreshToken:true,storage:window.localStorage}});const {error}=await client.auth.signInWithPassword({email:$('email').value.trim(),password:$('password').value});if(error){msg('No se pudo iniciar sesión. Verifica correo y contraseña.');return;}msg('');showApp();await load();realtime();});
  $('logoutBtn').addEventListener('click',logout);$('closePatientDialog').addEventListener('click',()=>{$('patientDialog').classList.add('hidden');$('patientDialog').setAttribute('aria-hidden','true');});$('patientDialog').addEventListener('click',e=>{if(e.target===$('patientDialog')){$('patientDialog').classList.add('hidden');$('patientDialog').setAttribute('aria-hidden','true');}});document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&client&&!$('appView').classList.contains('hidden'))load(true)});document.querySelectorAll('.nav').forEach(b=>b.addEventListener('click',()=>goto(b.dataset.page)));document.querySelectorAll('[data-goto]').forEach(b=>{b.addEventListener('click',()=>goto(b.dataset.goto));if(b.dataset.goto==='patients')b.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();goto('patients');}});});

  $('patientSearch').addEventListener('input',render);$('paymentSearch').addEventListener('input',render);$('refreshPatients').addEventListener('click',load);$('refreshPayments').addEventListener('click',load);$('refreshClinics').addEventListener('click',load);
  $('clinicFilter').addEventListener('change',e=>{selectedClinic=e.target.value;render();});
  $('patientForm').addEventListener('submit',async e=>{
    e.preventDefault();if(!client){toast('Inicia sesión antes de registrar pacientes.');return;}
    const name=$('patientName').value.trim();const clinic=$('patientClinic').value.trim();
    const total=Number($('patientTotal').value);const installments=Math.max(0,Math.trunc(Number($('patientInstallments').value)||0));const installmentAmount=Number($('patientInstallmentAmount').value)||0;
    if(!name){toast('Escribe el nombre del paciente.');return;}
    if(!clinic){toast('Primero registra una clínica y selecciónala.');return;}
    if(!Number.isFinite(total)||total<0||!Number.isFinite(installmentAmount)||installmentAmount<0){toast('Revisa los importes: no pueden ser negativos.');return;}
    const form=$('patientForm');const button=form.querySelector('button[type="submit"]');button.disabled=true;button.textContent='Guardando…';
    const payload={name,phone:$('patientPhone').value.trim(),treatment:$('patientTreatment').value.trim(),clinic,policy_number:$('patientPolicy').value.trim(),total,paid:0,installments,installment_amount:installmentAmount,source_device:'DENTAL JG'};
    const {data,error}=await client.from('patients').insert(payload).select().single();button.disabled=false;button.textContent='+ Guardar paciente';
    if(error){console.error('Error al guardar paciente:',error);toast('No se pudo guardar: '+(error.message||'revisa los permisos de patients en Supabase.'));return;}
    patients.unshift(data);form.reset();$('patientTotal').value='0';$('patientInstallments').value='0';$('patientInstallmentAmount').value='0';render();toast('Paciente registrado correctamente.');
  });
  $('clinicForm').addEventListener('submit',async e=>{
    e.preventDefault();if(!client)return;
    if(!clinicTableAvailable){toast('Primero ejecuta el archivo supabase_schema.sql en Supabase.');return;}
    const name=$('clinicName').value.trim();if(!name){toast('Escribe el nombre de la clínica.');return;}
    const exists=[...clinics.map(c=>c.name),...patients.map(p=>String(p.clinic||'').trim())].some(n=>n.toLocaleLowerCase('es-MX')===name.toLocaleLowerCase('es-MX'));
    if(exists){toast('Esa clínica ya está registrada.');return;}
    const button=$('clinicForm').querySelector('button[type="submit"]');button.disabled=true;button.textContent='Guardando…';
    const {data,error}=await client.from('clinics').insert({name}).select().single();button.disabled=false;button.textContent='+ Agregar clínica';
    if(error){console.error(error);toast(error.code==='23505'?'Esa clínica ya existe.':'No se pudo guardar. Revisa la tabla y permisos en Supabase.');return;}
    clinics.push(data);selectedClinic=name;$('clinicName').value='';render();toast('Clínica agregada correctamente.');
  });
  if(!configured)$('setupNotice').classList.remove('hidden');
  $('todayLabel').textContent=new Intl.DateTimeFormat('es-MX',{dateStyle:'medium'}).format(new Date());
  // Supabase persists the login in local storage. Restore it automatically when the app reopens.
  if(configured){try{client=window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseAnonKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,storage:window.localStorage}});client.auth.getSession().then(({data,error})=>{if(!error&&data&&data.session){showApp();load(true);realtime();}}).catch(err=>console.warn('No se pudo restaurar la sesión',err));client.auth.onAuthStateChange((event,session)=>{if(event==='SIGNED_IN'&&session&&$('appView').classList.contains('hidden')){showApp();load(true);realtime();}});}catch(err){console.error('No se pudo inicializar la sesión',err);}}

  // Panel navegador: selector funcional de 10 diseños de recibo.
  const panelDesign=$('panelReceiptDesign');
  function panelReceiptMarkup(){
    const design=Math.max(1,Math.min(10,Number(panelDesign?.value)||1));
    const val=id=>safe($(id)?.value?.trim()||'—');
    const dateVal=$('panelReceiptDate')?.value||new Date().toISOString().slice(0,10);
    const dateText=dateVal==='—'?'—':new Intl.DateTimeFormat('es-MX',{dateStyle:'long'}).format(new Date(dateVal+'T12:00:00'));
    const amount=Number($('panelReceiptAmount')?.value||0);
    return `<article class="panel-receipt receipt-design-${design}"><header class="pr-head"><div><div class="pr-brand">DENTAL JG</div><h3>RECIBO DE COBRANZA</h3><small>Comprobante de pago</small></div><div><span class="pr-label">Folio</span><strong>${val('panelReceiptFolio')}</strong><br><span class="pr-label">Fecha</span><strong>${safe(dateText)}</strong></div></header><div class="pr-row"><div class="pr-field"><span class="pr-label">Recibimos de</span>${val('panelReceiptPatient')}</div><div class="pr-field"><span class="pr-label">Concepto</span>${val('panelReceiptConcept')}</div></div><div class="pr-row"><div class="pr-field"><span class="pr-label">Forma de pago</span>Pago recibido</div><div class="pr-field"><span class="pr-label">Moneda</span>Pesos mexicanos (MXN)</div></div><div class="pr-amount">IMPORTE RECIBIDO: ${money(amount)}</div><div class="pr-row"><div class="pr-field"><span class="pr-label">Firma / recepción</span>________________________________</div><div class="pr-field"><span class="pr-label">Observaciones</span>________________________________</div></div><footer class="pr-footer">recibo no válido sin cello</footer></article>`;
  }
  function panelPreview(){const area=$('panelReceiptPreviewArea');if(!area)return;area.innerHTML=panelReceiptMarkup();}
  if(panelDesign){const saved=localStorage.getItem('dentaljg_panel_receipt_design');panelDesign.value=saved&&Number(saved)>=1&&Number(saved)<=10?saved:'1';panelDesign.addEventListener('change',()=>{localStorage.setItem('dentaljg_panel_receipt_design',panelDesign.value);panelPreview();toast('Diseño de recibo aplicado.');});}
  $('panelReceiptPreview')?.addEventListener('click',panelPreview);
  $('panelReceiptPrint')?.addEventListener('click',()=>{panelPreview();const area=$('panelReceiptPreviewArea');const one=area.innerHTML;area.innerHTML='<div class="panel-print-sheet">'+one+one+one+one+'</div>';window.print();area.innerHTML=one;});
  $('panelReceiptPatient')?.addEventListener('input',panelPreview);$('panelReceiptFolio')?.addEventListener('input',panelPreview);$('panelReceiptAmount')?.addEventListener('input',panelPreview);$('panelReceiptConcept')?.addEventListener('input',panelPreview);$('panelReceiptDate')?.addEventListener('change',panelPreview);
  if($('panelReceiptDate'))$('panelReceiptDate').value=new Date().toISOString().slice(0,10);panelPreview();
})();
