package com.example.gestoriaasistente;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

public class GestoriaApplication extends Application {
    public static final String CHANNEL_ID = "quincena_channel";

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Recordatorios de quincena",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Avisos de próximos pagos quincenales");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }
}
