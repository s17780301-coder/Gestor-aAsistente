package com.example.gestoriaasistente;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends android.app.Activity {
    private static final int NOTIFICATION_PERMISSION = 100;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("gestoria", MODE_PRIVATE);

        TextView next = findViewById(R.id.nextPayment);
        TextView status = findViewById(R.id.status);
        Button schedule = findViewById(R.id.btnSchedule);
        Button whatsapp = findViewById(R.id.btnWhatsApp);
        Button settingsButton = findViewById(R.id.btnSettings);

        next.setText(getNextQuincenaText());
        status.setText(prefs.getBoolean("enabled", false)
                ? "Recordatorios: ACTIVADOS"
                : "Recordatorios: desactivados");

        schedule.setOnClickListener(v -> {
            requestNotificationPermission();
            scheduleReminders();
            prefs.edit().putBoolean("enabled", true).apply();
            status.setText("Recordatorios: ACTIVADOS");
            Toast.makeText(this, "Recordatorios programados.", Toast.LENGTH_SHORT).show();
        });

        whatsapp.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"));
            startActivity(intent);
        });

        settingsButton.setOnClickListener(v ->
                Toast.makeText(this,
                        "Configuración avanzada se incorporará en la siguiente versión.",
                        Toast.LENGTH_SHORT).show());
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    NOTIFICATION_PERMISSION);
        }
    }

    private void scheduleReminders() {
        Calendar now = Calendar.getInstance();
        Calendar target = getNextQuincena(now);

        Calendar twoDays = (Calendar) target.clone();
        twoDays.add(Calendar.DAY_OF_MONTH, -2);

        Calendar oneDay = (Calendar) target.clone();
        oneDay.add(Calendar.DAY_OF_MONTH, -1);

        setAlarm(twoDays, "Tu quincena será en 2 días.");
        setAlarm(oneDay, "Para recordarle que la fecha de su pago es mañana por favor.");
    }

    private void setAlarm(Calendar when, String message) {
        if (when.before(Calendar.getInstance())) return;

        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, QuincenaReceiver.class);
        intent.putExtra("message", message);

        int requestCode = message.hashCode();
        PendingIntent pi = PendingIntent.getBroadcast(
                this, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            Intent settings = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
            settings.setData(Uri.parse("package:" + getPackageName()));
            startActivity(settings);
            return;
        }

        if (Build.VERSION.SDK_INT >= 23) {
            am.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    when.getTimeInMillis(),
                    pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        }
    }

    private Calendar getNextQuincena(Calendar from) {
        Calendar target = (Calendar) from.clone();
        int day = from.get(Calendar.DAY_OF_MONTH);
        int month = from.get(Calendar.MONTH);
        int year = from.get(Calendar.YEAR);

        if (day < 15) {
            target.set(year, month, 15, 9, 0, 0);
        } else {
            int lastDay = target.getActualMaximum(Calendar.DAY_OF_MONTH);
            int quincenaDay = (month == Calendar.FEBRUARY) ? lastDay : 30;
            target.set(year, month, quincenaDay, 9, 0, 0);
            if (target.before(from)) {
                target.add(Calendar.MONTH, 1);
                int newMonthLast = target.getActualMaximum(Calendar.DAY_OF_MONTH);
                int nextDay = target.get(Calendar.MONTH) == Calendar.FEBRUARY
                        ? newMonthLast : 15;
                target.set(target.get(Calendar.YEAR), target.get(Calendar.MONTH),
                        nextDay, 9, 0, 0);
            }
        }
        return target;
    }

    private String getNextQuincenaText() {
        Calendar next = getNextQuincena(Calendar.getInstance());
        SimpleDateFormat fmt = new SimpleDateFormat(
                "EEEE d 'de' MMMM", new Locale("es", "MX"));
        return "Próxima quincena: " + fmt.format(new Date(next.getTimeInMillis()));
    }
}
