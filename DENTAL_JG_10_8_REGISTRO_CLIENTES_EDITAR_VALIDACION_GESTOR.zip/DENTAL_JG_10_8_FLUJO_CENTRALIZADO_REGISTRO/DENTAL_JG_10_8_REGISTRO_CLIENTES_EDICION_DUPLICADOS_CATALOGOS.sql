-- DENTAL JG 10.8 | Registro de clientes: edición segura, catálogos y asignación de gestor.
-- Migración aditiva: no borra clientes, pagos, recibos ni historial.
create extension if not exists pgcrypto;

-- Catálogo de clínicas (compatible con el catálogo ya utilizado por Panel Administrativo).
create table if not exists public.clinics (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create unique index if not exists clinics_name_unique_idx on public.clinics(lower(name));

create table if not exists public.policy_types (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create unique index if not exists policy_types_name_unique_idx on public.policy_types(lower(name));
insert into public.policy_types(name) values ('Básica'),('VIP'),('Orto'),('Damon') on conflict do nothing;
insert into public.clinics(name)
 select distinct trim(clinic) from public.patients where coalesce(trim(clinic),'')<>'' on conflict do nothing;

-- La app Gestor sincroniza el nombre de su perfil a collection_managers.
create table if not exists public.collection_managers (
 id uuid primary key default gen_random_uuid(),
 created_by uuid not null default auth.uid() references auth.users(id) on delete cascade,
 full_name text not null,
 phone text not null default '',
 active boolean not null default true,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 unique(created_by,full_name)
);

alter table public.patients add column if not exists address text not null default '';
alter table public.patients add column if not exists phone2 text not null default '';
alter table public.patients add column if not exists policy_type text not null default '';
alter table public.patients add column if not exists first_payment_date date;
alter table public.patients add column if not exists observations text not null default '';
alter table public.patients add column if not exists assigned_manager_id uuid;
do $$ begin
 if not exists(select 1 from pg_constraint where conname='patients_assigned_manager_id_fkey' and conrelid='public.patients'::regclass) then
  alter table public.patients add constraint patients_assigned_manager_id_fkey foreign key(assigned_manager_id) references public.collection_managers(id) on delete set null;
 end if;
end $$;

alter table public.clinics enable row level security;
alter table public.policy_types enable row level security;
alter table public.collection_managers enable row level security;
grant select,insert,update on public.clinics to authenticated;
grant select,insert,update on public.policy_types to authenticated;
grant select,insert,update on public.collection_managers to authenticated;
drop policy if exists "registro manage clinics catalog" on public.clinics;
create policy "registro manage clinics catalog" on public.clinics for all to authenticated using(exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('registro','admin'))) with check(exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('registro','admin')));
drop policy if exists "registro manage policy types catalog" on public.policy_types;
create policy "registro manage policy types catalog" on public.policy_types for all to authenticated using(exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('registro','admin'))) with check(exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('registro','admin')));
drop policy if exists "users manage own collection managers" on public.collection_managers;
create policy "users manage own collection managers" on public.collection_managers for all to authenticated using(created_by=auth.uid()) with check(created_by=auth.uid());
drop policy if exists "authenticated users can view active collection managers" on public.collection_managers;
create policy "authenticated users can view active collection managers" on public.collection_managers for select to authenticated using(active=true);

-- Alta con validación de rol y detección de coincidencias fuertes en el servidor.
create or replace function public.register_dental_jg_patient(
 p_name text,
 p_clinic text,
 p_address text,
 p_phone text,
 p_phone2 text,
 p_policy_type text,
 p_policy_number text,
 p_total numeric,
 p_installments integer,
 p_installment_amount numeric,
 p_first_payment_date date,
 p_assigned_manager_id uuid,
 p_observations text
) returns uuid language plpgsql security definer set search_path=public as $$
declare new_id uuid; v_name text; v_phone text; v_phone2 text; v_policy text;
begin
 if auth.uid() is null or not exists(select 1 from public.app_user_roles where user_id=auth.uid() and role in ('registro','admin')) then raise exception 'Esta cuenta no tiene permiso para registrar clientes.'; end if;
 v_name:=lower(regexp_replace(trim(coalesce(p_name,'')),'[^[:alnum:]]','','g'));
 v_phone:=regexp_replace(coalesce(p_phone,''),'[^0-9]','','g');
 v_phone2:=regexp_replace(coalesce(p_phone2,''),'[^0-9]','','g');
 v_policy:=lower(regexp_replace(trim(coalesce(p_policy_number,'')),'[^[:alnum:]]','','g'));
 if coalesce(trim(p_name),'')='' or coalesce(trim(p_clinic),'')='' or coalesce(trim(p_address),'')='' or coalesce(trim(p_phone),'')='' or coalesce(trim(p_policy_type),'')='' or coalesce(trim(p_policy_number),'')='' or p_first_payment_date is null or p_assigned_manager_id is null or coalesce(trim(p_observations),'')='' then raise exception 'Completa todos los campos obligatorios.'; end if;
 if length(v_phone)<10 or length(v_phone)>15 then raise exception 'El teléfono debe contener entre 10 y 15 dígitos.'; end if;
 if coalesce(trim(p_phone2),'')<>'' and (length(v_phone2)<10 or length(v_phone2)>15) then raise exception 'El segundo teléfono debe contener entre 10 y 15 dígitos.'; end if;
 if coalesce(p_total,0)<=0 or coalesce(p_installment_amount,0)<=0 or coalesce(p_installments,0)<1 or p_installments>240 then raise exception 'Revisa el total, el pago quincenal y el número de quincenas.'; end if;
 if not exists(select 1 from public.collection_managers where id=p_assigned_manager_id and active=true) then raise exception 'El gestor seleccionado ya no está activo.'; end if;
 if exists(select 1 from public.patients p where lower(regexp_replace(trim(coalesce(p.name,'')),'[^[:alnum:]]','','g'))=v_name and (regexp_replace(coalesce(p.phone,''),'[^0-9]','','g')=v_phone or (v_policy<>'' and lower(regexp_replace(trim(coalesce(p.policy_number,'')),'[^[:alnum:]]','','g'))=v_policy))) then raise exception 'Posible duplicado: ya existe un paciente con el mismo nombre y teléfono o número de póliza.'; end if;
 insert into public.patients(name,clinic,address,phone,phone2,policy_type,policy_number,total,paid,installments,installment_amount,first_payment_date,assigned_manager_id,observations,treatment,source_device,created_at,updated_at)
 values(trim(p_name),trim(p_clinic),trim(p_address),trim(p_phone),coalesce(trim(p_phone2),''),trim(p_policy_type),trim(p_policy_number),p_total,0,p_installments,p_installment_amount,p_first_payment_date,p_assigned_manager_id,trim(p_observations),'','DENTAL JG Registro',now(),now()) returning id into new_id;
 return new_id;
end; $$;
revoke all on function public.register_dental_jg_patient(text,text,text,text,text,text,text,numeric,integer,numeric,date,uuid,text) from public,anon;
grant execute on function public.register_dental_jg_patient(text,text,text,text,text,text,text,numeric,integer,numeric,date,uuid,text) to authenticated;

-- Edición: modifica los datos del expediente sin tocar paid, pagos, recibos ni created_at.
create or replace function public.update_dental_jg_patient(
 p_patient_id uuid,
 p_name text,
 p_clinic text,
 p_address text,
 p_phone text,
 p_phone2 text,
 p_policy_type text,
 p_policy_number text,
 p_total numeric,
 p_installments integer,
 p_installment_amount numeric,
 p_first_payment_date date,
 p_assigned_manager_id uuid,
 p_observations text
) returns uuid language plpgsql security definer set search_path=public as $$
declare v_name text; v_phone text; v_phone2 text; v_policy text; v_paid numeric;
begin
 if auth.uid() is null or not exists(select 1 from public.app_user_roles where user_id=auth.uid() and role in ('registro','admin')) then raise exception 'Esta cuenta no tiene permiso para editar clientes.'; end if;
 v_name:=lower(regexp_replace(trim(coalesce(p_name,'')),'[^[:alnum:]]','','g'));
 v_phone:=regexp_replace(coalesce(p_phone,''),'[^0-9]','','g'); v_phone2:=regexp_replace(coalesce(p_phone2,''),'[^0-9]','','g');
 v_policy:=lower(regexp_replace(trim(coalesce(p_policy_number,'')),'[^[:alnum:]]','','g'));
 if coalesce(trim(p_name),'')='' or coalesce(trim(p_clinic),'')='' or coalesce(trim(p_address),'')='' or coalesce(trim(p_phone),'')='' or coalesce(trim(p_policy_type),'')='' or coalesce(trim(p_policy_number),'')='' or p_first_payment_date is null or p_assigned_manager_id is null or coalesce(trim(p_observations),'')='' then raise exception 'Completa todos los campos obligatorios.'; end if;
 if length(v_phone)<10 or length(v_phone)>15 then raise exception 'El teléfono debe contener entre 10 y 15 dígitos.'; end if;
 if coalesce(trim(p_phone2),'')<>'' and (length(v_phone2)<10 or length(v_phone2)>15) then raise exception 'El segundo teléfono debe contener entre 10 y 15 dígitos.'; end if;
 if coalesce(p_total,0)<=0 or coalesce(p_installment_amount,0)<=0 or coalesce(p_installments,0)<1 or p_installments>240 then raise exception 'Revisa el total, el pago quincenal y el número de quincenas.'; end if;
 if not exists(select 1 from public.collection_managers where id=p_assigned_manager_id and active=true) then raise exception 'El gestor seleccionado ya no está activo.'; end if;
 if not exists(select 1 from public.patients where id=p_patient_id) then raise exception 'No se encontró el expediente a editar.'; end if;
 if exists(select 1 from public.patients p where p.id<>p_patient_id and lower(regexp_replace(trim(coalesce(p.name,'')),'[^[:alnum:]]','','g'))=v_name and (regexp_replace(coalesce(p.phone,''),'[^0-9]','','g')=v_phone or (v_policy<>'' and lower(regexp_replace(trim(coalesce(p.policy_number,'')),'[^[:alnum:]]','','g'))=v_policy))) then raise exception 'Posible duplicado: otro paciente ya usa ese nombre y teléfono o número de póliza.'; end if;
 update public.patients set name=trim(p_name),clinic=trim(p_clinic),address=trim(p_address),phone=trim(p_phone),phone2=coalesce(trim(p_phone2),''),policy_type=trim(p_policy_type),policy_number=trim(p_policy_number),total=p_total,installments=p_installments,installment_amount=p_installment_amount,first_payment_date=p_first_payment_date,assigned_manager_id=p_assigned_manager_id,observations=trim(p_observations),updated_at=now() where id=p_patient_id returning paid into v_paid;
 return p_patient_id;
end; $$;
revoke all on function public.update_dental_jg_patient(uuid,text,text,text,text,text,text,text,numeric,integer,numeric,date,uuid,text) from public,anon;
grant execute on function public.update_dental_jg_patient(uuid,text,text,text,text,text,text,text,numeric,integer,numeric,date,uuid,text) to authenticated;
