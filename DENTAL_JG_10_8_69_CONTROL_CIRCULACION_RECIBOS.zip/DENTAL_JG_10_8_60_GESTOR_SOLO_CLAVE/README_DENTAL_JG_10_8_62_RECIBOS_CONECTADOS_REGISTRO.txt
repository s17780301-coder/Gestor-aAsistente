DENTAL JG 10.8.62 - RECIBOS CONECTADOS A REGISTRO

BASE
Derivada del archivo DENTAL_JG_10_8_61_PANEL_CENTRAL_ACCESO.zip proporcionado como version de trabajo.

CAMBIOS
- Se agrega acceso visible a Recibos en el menu lateral del Panel Central.
- La pantalla de recibos permite elegir entre los 10 disenos existentes.
- El selector carga los clientes desde la tabla public.patients, alimentada por Registro de clientes.
- Al elegir cliente, el nombre, folio y numero de poliza se rellenan desde la base; los campos quedan bloqueados para evitar alteraciones accidentales.
- El recibo imprime el folio y el numero de poliza existentes; no genera un folio nuevo.
- Se conserva la impresion de cuatro recibos por hoja.
- Esta pantalla sigue siendo solo de vista previa e impresion; no registra pagos.

VALIDACION
Se reviso la estructura de los archivos y la sintaxis JavaScript con Node.js. No se ejecuto contra Supabase remoto ni se compilo APK.

NOTA
La lista de clientes respeta el filtro de clinica activo en el Panel Central. Para ver clientes de otra clinica, cambia primero el filtro superior.
