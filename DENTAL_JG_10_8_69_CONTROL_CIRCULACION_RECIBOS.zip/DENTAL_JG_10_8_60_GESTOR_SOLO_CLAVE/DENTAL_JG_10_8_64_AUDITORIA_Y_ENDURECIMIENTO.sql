-- DENTAL JG 10.8.64 - Endurecimiento incremental de recibos.
-- Revisar respaldo antes de ejecutar. No borra ni modifica pacientes ni pagos existentes.
-- Recomendado: ejecutar primero el bloque AUDITORÍA y revisar sus resultados.

-- 1) AUDITORÍA: pagos con más de un recibo (debe devolver 0 filas para índice único).
SELECT payment_id, count(*) AS recibos
FROM public.collection_receipts
WHERE payment_id IS NOT NULL
GROUP BY payment_id
HAVING count(*) > 1;

-- 2) AUDITORÍA: recibos con datos financieros sospechosos.
SELECT id, folio, payment_id, patient_id, payment_amount, tabulator, net_amount,
       previous_balance, new_balance, created_at
FROM public.collection_receipts
WHERE payment_amount <= 0
   OR tabulator < 0
   OR tabulator > payment_amount
   OR net_amount < 0
   OR previous_balance < 0
   OR new_balance < 0
ORDER BY created_at DESC;

-- 3) Índice único solo si no hay duplicados existentes. Si hay duplicados, no los borra:
-- primero hay que revisarlos y decidir cuál conservar.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.collection_receipts
    WHERE payment_id IS NOT NULL
    GROUP BY payment_id HAVING count(*) > 1
  ) THEN
    RAISE NOTICE 'No se creó el índice único: existen pagos con más de un recibo. Revisa la auditoría.';
  ELSE
    CREATE UNIQUE INDEX IF NOT EXISTS collection_receipts_payment_unique
      ON public.collection_receipts(payment_id)
      WHERE payment_id IS NOT NULL;
  END IF;
END $$;

-- 4) Sustituye la función para validar importes y evitar asignar un gestor ajeno.
CREATE OR REPLACE FUNCTION public.create_collection_receipt(
  p_payment_id uuid, p_patient_id uuid, p_patient_name text, p_clinic text,
  p_payment_amount numeric, p_previous_balance numeric, p_tabulator numeric,
  p_new_balance numeric, p_concept text, p_notes text, p_snapshot jsonb,
  p_manager_id uuid DEFAULT NULL
) RETURNS public.collection_receipts
LANGUAGE plpgsql SECURITY INVOKER SET search_path = public, pg_temp AS $$
DECLARE
  s public.collection_receipt_settings;
  r public.collection_receipts;
  v_folio text;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Inicia sesión para generar recibos.';
  END IF;
  IF p_payment_amount IS NULL OR p_payment_amount <= 0 OR p_payment_amount > 9999999999.99 THEN
    RAISE EXCEPTION 'El importe debe ser mayor que cero y estar dentro del límite permitido.';
  END IF;
  IF COALESCE(p_previous_balance,0) < 0 OR COALESCE(p_tabulator,0) < 0
     OR COALESCE(p_new_balance,0) < 0 THEN
    RAISE EXCEPTION 'Los importes no pueden ser negativos.';
  END IF;
  IF COALESCE(p_tabulator,0) > p_payment_amount THEN
    RAISE EXCEPTION 'El tabulador/descuento no puede superar el importe del recibo.';
  END IF;
  IF length(COALESCE(p_patient_name,'')) > 200 OR length(COALESCE(p_clinic,'')) > 200
     OR length(COALESCE(p_concept,'')) > 200 OR length(COALESCE(p_notes,'')) > 2000 THEN
    RAISE EXCEPTION 'Uno de los campos de texto supera el límite permitido.';
  END IF;
  IF p_snapshot IS NOT NULL AND jsonb_typeof(p_snapshot) <> 'object' THEN
    RAISE EXCEPTION 'Los datos de impresión del recibo no tienen un formato válido.';
  END IF;
  IF p_manager_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.collection_managers m
    WHERE m.id = p_manager_id AND m.created_by = auth.uid()
  ) THEN
    RAISE EXCEPTION 'El gestor seleccionado no pertenece a esta cuenta.';
  END IF;

  -- Bloqueo transaccional por usuario y pago: serializa intentos simultáneos.
  IF p_payment_id IS NOT NULL THEN
    PERFORM pg_advisory_xact_lock(hashtext(auth.uid()::text || ':' || p_payment_id::text));
    SELECT * INTO r FROM public.collection_receipts
      WHERE created_by = auth.uid() AND payment_id = p_payment_id
      LIMIT 1;
    IF FOUND THEN RETURN r; END IF;
  END IF;

  INSERT INTO public.collection_receipt_settings(user_id)
    VALUES(auth.uid()) ON CONFLICT(user_id) DO NOTHING;
  SELECT * INTO s FROM public.collection_receipt_settings
    WHERE user_id = auth.uid() FOR UPDATE;
  v_folio := COALESCE(s.folio_prefix,'JG-') ||
    lpad(s.next_folio::text, greatest(s.folio_digits, length(s.next_folio::text)), '0');
  UPDATE public.collection_receipt_settings
    SET next_folio = next_folio + 1, updated_at = now()
    WHERE user_id = auth.uid();

  INSERT INTO public.collection_receipts(
    created_by, folio, payment_id, patient_id, manager_id, patient_name, clinic,
    payment_amount, previous_balance, tabulator, net_amount, new_balance,
    concept, notes, receipt_snapshot
  ) VALUES (
    auth.uid(), v_folio, p_payment_id, p_patient_id, p_manager_id,
    COALESCE(p_patient_name,''), COALESCE(p_clinic,''), p_payment_amount,
    COALESCE(p_previous_balance,0), COALESCE(p_tabulator,0),
    p_payment_amount - COALESCE(p_tabulator,0), COALESCE(p_new_balance,0),
    COALESCE(p_concept,'Abono'), COALESCE(p_notes,''), COALESCE(p_snapshot,'{}'::jsonb)
  ) RETURNING * INTO r;
  RETURN r;
END;
$$;
REVOKE ALL ON FUNCTION public.create_collection_receipt(uuid,uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_collection_receipt(uuid,uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid) TO authenticated;

-- NOTA: la app debe seguir validando permisos/RLS en patients y payments.
-- Esta función no registra por sí misma un pago; solo genera un recibo asociado.
