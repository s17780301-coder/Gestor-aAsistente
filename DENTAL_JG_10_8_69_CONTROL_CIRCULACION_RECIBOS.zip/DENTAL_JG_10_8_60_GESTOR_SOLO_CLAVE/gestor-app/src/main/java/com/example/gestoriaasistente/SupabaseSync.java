package com.example.gestoriaasistente;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Sincroniza la caché local de DENTAL JG con las mismas tablas usadas por el panel web. */
public final class SupabaseSync {
    public static final String BASE = "https://nfwhymppyzoriihdwlyc.supabase.co";
    public static final String ANON = "sb_publishable_4n5cK2gQeEbTtdYKHAWVVQ_C1Gzl88O";
    private static final String PREF = "dentaljg_cloud";
    private final Context context;
    public SupabaseSync(Context c) { context = c.getApplicationContext(); }
    public String token() { return ""; } // La app Gestor no utiliza sesiones personales de Supabase.
    public String email() { return managerName(); } // Compatibilidad con el texto de estado de la interfaz.
    public boolean connected() { return !managerKey().isEmpty() && !managerId().isEmpty(); }
    public String managerId() { return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("manager_id", ""); }
    public String managerName() { return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("manager_name", ""); }
    private String managerKey() { return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("manager_key", ""); }
    public void verifyManagerKey(String key) throws Exception {
        if (key == null || key.trim().length() < 4) throw new Exception("Escribe la clave de gestor asignada por Administración.");
        JSONObject body = new JSONObject(); body.put("p_manager_key", key.trim());
        JSONArray result = requestArray("POST", "/rest/v1/rpc/dental_jg_manager_by_key", body, null, null);
        if (result.length() == 0) throw new Exception("Clave de gestor incorrecta o gestor inactivo. Pide a Administración que la revise.");
        JSONObject manager = result.getJSONObject(0);
        String id = manager.optString("id", "");
        if (id.isEmpty()) throw new Exception("Supabase no devolvió un gestor válido.");
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("manager_id", id).putString("manager_name", manager.optString("full_name", "Gestor"))
                .putString("manager_key", key.trim()).remove("access_token").remove("refresh_token").remove("email").apply();
    }
    public void logout() { context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply(); }

    public void sync(CustomerDbHelper db) throws Exception {
        String key = managerKey();
        if (key.isEmpty() || managerId().isEmpty()) throw new Exception("Primero inicia sesión con la clave de gestor asignada por Administración.");
        SQLiteDatabase local = db.getWritableDatabase();

        JSONArray remotePatients = managerRpcArray("dental_jg_manager_patients", key, null);
        Cursor unsynced = local.rawQuery("SELECT id,nombre,telefono,tratamiento,total,pagado,remote_id,clinica,quincenas,pago_quincenal,numero_poliza FROM pacientes WHERE remote_id IS NULL OR remote_id=''", null);
        try { while (unsynced.moveToNext()) {
            String localName = blank(unsynced.getString(1), "");
            String localPhone = digits(unsynced.getString(2));
            String matchedRemoteId = "";
            if (!localPhone.isEmpty()) {
                for (int i = 0; i < remotePatients.length(); i++) {
                    JSONObject candidate = remotePatients.getJSONObject(i);
                    if (localPhone.equals(digits(candidate.optString("phone", "")))
                            && localName.equalsIgnoreCase(blank(candidate.optString("name", ""), ""))) {
                        matchedRemoteId = candidate.optString("id", "");
                        if (!matchedRemoteId.isEmpty()) break;
                    }
                }
            }
            if (!matchedRemoteId.isEmpty()) {
                db.setRemotePatientId(unsynced.getLong(0), matchedRemoteId);
                continue;
            }
            JSONObject patient = new JSONObject();
            patient.put("name", localName); patient.put("phone", unsynced.getString(2));
            patient.put("treatment", unsynced.getString(3)); patient.put("total", unsynced.getDouble(4));
            patient.put("paid", unsynced.getDouble(5)); patient.put("clinic", blank(unsynced.getString(7), "DENTAL JG"));
            patient.put("installments", unsynced.getInt(8)); patient.put("installment_amount", unsynced.getDouble(9));
            patient.put("policy_number", blank(unsynced.getString(10), "")); patient.put("source_device", "DENTAL JG APK");
            JSONObject wrapper = new JSONObject(); wrapper.put("p_patient", patient);
            JSONArray saved = managerRpcArray("dental_jg_manager_insert_patient", key, wrapper);
            if (saved.length() > 0) db.setRemotePatientId(unsynced.getLong(0), saved.getJSONObject(0).optString("id", ""));
        }} finally { unsynced.close(); }

        remotePatients = managerRpcArray("dental_jg_manager_patients", key, null);
        for (int i=0;i<remotePatients.length();i++) db.upsertRemotePatient(remotePatients.getJSONObject(i));

        Cursor localPayments = local.rawQuery("SELECT pa.id,pa.paciente_id,pa.monto,pa.fecha,pa.nota,p.nombre,p.remote_id,pa.remote_id FROM pagos pa JOIN pacientes p ON p.id=pa.paciente_id WHERE pa.remote_id IS NULL OR pa.remote_id=''", null);
        try { while(localPayments.moveToNext()) {
            String patientRemote = localPayments.getString(6);
            if (patientRemote == null || patientRemote.isEmpty()) continue;
            JSONObject payment = new JSONObject();
            payment.put("patient_id", patientRemote); payment.put("patient_name", localPayments.getString(5));
            payment.put("amount", localPayments.getDouble(2)); payment.put("concept", blank(localPayments.getString(4), "Abono"));
            payment.put("reference", blank(localPayments.getString(4), "")); payment.put("source_device", "DENTAL JG APK");
            // Stable key: same local payment re-sent after timeout must resolve to the same remote row.
            payment.put("source_payment_key", "gestor:" + managerId() + ":pago:" + localPayments.getLong(0));
            JSONObject wrapper = new JSONObject(); wrapper.put("p_payment", payment);
            JSONArray saved = managerRpcArray("dental_jg_manager_insert_payment", key, wrapper);
            if (saved.length() > 0) {
                db.setRemotePaymentId(localPayments.getLong(0), saved.getJSONObject(0).optString("id", ""));
                Cursor amountCursor = local.rawQuery("SELECT pagado FROM pacientes WHERE id=?", new String[]{String.valueOf(localPayments.getLong(1))});
                double localPaid = 0; if (amountCursor.moveToFirst()) localPaid = amountCursor.getDouble(0); amountCursor.close();
                JSONObject paidBody = new JSONObject(); paidBody.put("p_patient_id", patientRemote); paidBody.put("p_new_paid", localPaid);
                managerRpcArray("dental_jg_manager_sync_patient_paid", key, paidBody);
            }
        }} finally { localPayments.close(); }

        JSONArray remotePayments = managerRpcArray("dental_jg_manager_payments", key, null);
        for (int i=0;i<remotePayments.length();i++) db.upsertRemotePayment(remotePayments.getJSONObject(i));
        remotePatients = managerRpcArray("dental_jg_manager_patients", key, null);
        for (int i=0;i<remotePatients.length();i++) db.upsertRemotePatient(remotePatients.getJSONObject(i));
    }

    private JSONArray managerRpcArray(String function, String key, JSONObject extra) throws Exception {
        JSONObject body = extra == null ? new JSONObject() : new JSONObject(extra.toString());
        body.put("p_manager_key", key);
        return requestArray("POST", "/rest/v1/rpc/" + function, body, null, null);
    }
    private static String blank(String s,String fallback){return s==null||s.trim().isEmpty()?fallback:s.trim();}
    private static String digits(String s){return s==null?"":s.replaceAll("[^0-9]", "");}
    private JSONObject request(String method,String path,JSONObject body,String jwt,String prefer) throws Exception {
        HttpURLConnection c=open(method,path,jwt,prefer); if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode(); String response=read(code>=200&&code<400?c.getInputStream():c.getErrorStream()); c.disconnect();
        if(code<200||code>=300) throw new Exception(explain(response,code)); return new JSONObject(response.isEmpty()?"{}":response);
    }
    private JSONArray requestArray(String method,String path,JSONObject body,String jwt,String prefer) throws Exception {
        HttpURLConnection c=open(method,path,jwt,prefer); if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode(); String response=read(code>=200&&code<400?c.getInputStream():c.getErrorStream()); c.disconnect();
        if(code<200||code>=300) throw new Exception(explain(response,code)); return new JSONArray(response.isEmpty()?"[]":response);
    }
    private HttpURLConnection open(String method,String path,String jwt,String prefer) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(BASE+path).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestProperty("apikey",ANON); c.setRequestProperty("Authorization","Bearer "+(jwt==null?ANON:jwt)); c.setRequestProperty("Accept","application/json"); if(prefer!=null)c.setRequestProperty("Prefer",prefer); return c;
    }
    private String read(InputStream in) throws Exception { if(in==null)return ""; try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder s=new StringBuilder();String line;while((line=r.readLine())!=null)s.append(line);return s.toString();} }
    private String explain(String response,int code){try{JSONObject j=new JSONObject(response);String m=j.optString("message",j.optString("msg",j.optString("error_description",response)));if(code==401)return "La sesión venció. Vuelve a iniciar sesión. "+m;if(code==403)return "Supabase bloqueó el acceso. Revisa las políticas RLS. "+m;return m;}catch(Exception e){return "Error de Supabase ("+code+"): "+response;}}
}
