-- DENTAL JG 10.8.61 — soporte de roles para el acceso al Panel Central.
-- Ejecutar en Supabase SQL Editor tras hacer respaldo. No asigna roles automáticamente.
create table if not exists public.app_user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('registro','cobranza','gestor','admin')),
  created_at timestamptz not null default now(),
  primary key (user_id, role)
);

alter table public.app_user_roles enable row level security;
revoke all on table public.app_user_roles from anon;
revoke insert, update, delete on table public.app_user_roles from authenticated;
grant select on table public.app_user_roles to authenticated;

drop policy if exists "users view own app roles" on public.app_user_roles;
create policy "users view own app roles"
  on public.app_user_roles for select to authenticated
  using (user_id = auth.uid());

-- Asigna los roles manualmente después de crear las cuentas en Authentication > Users.
-- Reemplaza el UUID de ejemplo por el UUID real de la cuenta y descomenta la línea adecuada:
-- insert into public.app_user_roles(user_id, role) values ('UUID-REAL', 'admin') on conflict do nothing;
-- insert into public.app_user_roles(user_id, role) values ('UUID-REAL', 'cobranza') on conflict do nothing;
-- insert into public.app_user_roles(user_id, role) values ('UUID-REAL', 'registro') on conflict do nothing;
-- No agregues 'gestor' para permitir acceso al panel: el rol gestor por sí solo no está autorizado.
