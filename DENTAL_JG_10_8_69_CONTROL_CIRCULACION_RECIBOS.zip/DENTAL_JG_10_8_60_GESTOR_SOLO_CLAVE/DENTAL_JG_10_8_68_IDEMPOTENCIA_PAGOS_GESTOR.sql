-- DENTAL JG 10.8.68 — IDEMPOTENCIA DE PAGOS DEL GESTOR
-- Ejecutar en Supabase SQL Editor antes de instalar la APK parcheada.
-- No borra pagos ni recibos. Filas antiguas conservan source_payment_key = NULL.
-- La clave debe ser estable para cada pago local y se valida contra gestor, paciente e importe.

ALTER TABLE public.payments
  ADD COLUMN IF NOT EXISTS source_payment_key text;

CREATE UNIQUE INDEX IF NOT EXISTS payments_source_payment_key_unique
  ON public.payments(source_payment_key)
  WHERE source_payment_key IS NOT NULL AND source_payment_key <> '';

CREATE OR REPLACE FUNCTION public.dental_jg_manager_insert_payment(p_manager_key text, p_payment jsonb)
RETURNS SETOF jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_manager uuid;
  v_patient public.patients;
  v_payment public.payments;
  v_key text;
  v_amount numeric;
BEGIN
  SELECT m.id INTO v_manager
  FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false
    AND m.manager_key = btrim(coalesce(p_manager_key, ''))
    AND length(btrim(coalesce(p_manager_key, ''))) >= 4
  LIMIT 1;

  IF v_manager IS NULL THEN
    RAISE EXCEPTION 'Clave de gestor incorrecta o gestor inactivo.';
  END IF;

  IF coalesce(p_payment->>'patient_id', '') = '' THEN
    RAISE EXCEPTION 'Falta el identificador del paciente.';
  END IF;
  IF coalesce(p_payment->>'amount', '') !~ '^[0-9]+([.][0-9]{1,2})?$' THEN
    RAISE EXCEPTION 'El importe del abono no es válido.';
  END IF;
  v_amount := (p_payment->>'amount')::numeric;
  IF v_amount <= 0 OR v_amount > 9999999999.99 THEN
    RAISE EXCEPTION 'El importe del abono debe ser mayor que cero y estar dentro del límite permitido.';
  END IF;

  SELECT p.* INTO v_patient
  FROM public.patients p
  WHERE p.id = (p_payment->>'patient_id')::uuid
    AND p.assigned_manager_id = v_manager;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'El paciente no pertenece a este gestor.';
  END IF;

  v_key := nullif(btrim(coalesce(p_payment->>'source_payment_key', '')), '');
  IF v_key IS NOT NULL THEN
    IF length(v_key) > 200 THEN RAISE EXCEPTION 'La clave de pago es demasiado larga.'; END IF;
    -- El bloqueo evita que dos reintentos concurrentes inserten el mismo pago.
    PERFORM pg_advisory_xact_lock(hashtextextended(v_key, 0));
    SELECT * INTO v_payment FROM public.payments py
    WHERE py.source_payment_key = v_key LIMIT 1;
    IF FOUND THEN
      IF v_payment.patient_id IS DISTINCT FROM v_patient.id
         OR round(v_payment.amount::numeric, 2) <> round(v_amount, 2) THEN
        RAISE EXCEPTION 'La clave de pago ya existe con otro paciente o importe. No se duplicó el pago.';
      END IF;
      RETURN NEXT to_jsonb(v_payment);
      RETURN;
    END IF;
  END IF;

  INSERT INTO public.payments(
    patient_id, patient_name, amount, concept, reference, source_device, source_payment_key
  ) VALUES (
    v_patient.id,
    left(coalesce(nullif(p_payment->>'patient_name', ''), v_patient.name), 200),
    v_amount,
    left(coalesce(nullif(p_payment->>'concept', ''), 'Abono'), 200),
    left(coalesce(p_payment->>'reference', ''), 500),
    left(coalesce(nullif(p_payment->>'source_device', ''), 'DENTAL JG APK'), 100),
    v_key
  ) RETURNING * INTO v_payment;

  RETURN NEXT to_jsonb(v_payment);
EXCEPTION
  WHEN unique_violation THEN
    -- Última barrera ante una carrera de concurrencia. Releer por clave y devolver el pago existente.
    IF v_key IS NOT NULL THEN
      SELECT * INTO v_payment FROM public.payments py
      WHERE py.source_payment_key = v_key LIMIT 1;
      IF FOUND AND v_payment.patient_id = v_patient.id
         AND round(v_payment.amount::numeric, 2) = round(v_amount, 2) THEN
        RETURN NEXT to_jsonb(v_payment);
        RETURN;
      END IF;
    END IF;
    RAISE;
END;
$$;

REVOKE ALL ON FUNCTION public.dental_jg_manager_insert_payment(text, jsonb) FROM PUBLIC, authenticated;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_insert_payment(text, jsonb) TO anon;

-- Comprobación posterior: debe existir la columna y el índice único parcial.
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_schema='public' AND table_name='payments' AND column_name='source_payment_key';
SELECT indexname, indexdef FROM pg_indexes
WHERE schemaname='public' AND tablename='payments' AND indexname='payments_source_payment_key_unique';
