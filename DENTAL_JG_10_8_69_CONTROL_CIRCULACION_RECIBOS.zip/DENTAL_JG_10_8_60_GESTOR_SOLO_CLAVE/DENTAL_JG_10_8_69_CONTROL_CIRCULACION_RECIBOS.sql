-- DENTAL JG 10.8.69 — CONTROL DE CIRCULACIÓN DE RECIBOS
-- Migración aditiva: no borra pagos ni recibos, no registra pagos y no modifica saldos.
-- Revisar primero en un entorno de prueba. Ejecutar con el SQL Editor de Supabase.

BEGIN;

-- Cada recibo conserva su folio y cantidad individual. La circulación no equivale a cobro.
ALTER TABLE public.collection_receipts
  ADD COLUMN IF NOT EXISTS circulation_status text NOT NULL DEFAULT 'in_circulation',
  ADD COLUMN IF NOT EXISTS delivered_at timestamptz,
  ADD COLUMN IF NOT EXISTS delivered_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS returned_at timestamptz,
  ADD COLUMN IF NOT EXISTS cancelled_at timestamptz,
  ADD COLUMN IF NOT EXISTS cancellation_reason text;

-- Los recibos que ya están vinculados a un pago real se marcan como cobrados.
-- Los recibos sin pago asociado permanecen en circulación; no se crea ningún pago.
UPDATE public.collection_receipts
SET circulation_status = CASE
  WHEN payment_id IS NOT NULL THEN 'paid'
  WHEN circulation_status NOT IN ('returned','cancelled') THEN 'in_circulation'
  ELSE circulation_status
END
WHERE (payment_id IS NOT NULL AND circulation_status <> 'paid')
   OR (payment_id IS NULL AND circulation_status IS NULL);

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid='public.collection_receipts'::regclass
      AND conname='collection_receipts_circulation_status_check'
  ) THEN
    ALTER TABLE public.collection_receipts
      ADD CONSTRAINT collection_receipts_circulation_status_check
      CHECK (circulation_status IN ('generated','in_circulation','paid','returned','cancelled'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS collection_receipts_circulation_manager_status_idx
  ON public.collection_receipts(manager_id, circulation_status, created_at DESC);
CREATE INDEX IF NOT EXISTS collection_receipts_circulation_patient_idx
  ON public.collection_receipts(patient_id, circulation_status, created_at DESC);

-- Historial inmutable de cambios importantes de circulación.
CREATE TABLE IF NOT EXISTS public.collection_receipt_circulation_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  receipt_id uuid NOT NULL REFERENCES public.collection_receipts(id) ON DELETE RESTRICT,
  receipt_folio text NOT NULL,
  manager_id uuid REFERENCES public.collection_managers(id) ON DELETE SET NULL,
  actor_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  event_type text NOT NULL CHECK (event_type IN ('created','delivered','marked_paid','returned','cancelled','reprinted')),
  previous_status text,
  new_status text,
  amount numeric(12,2) NOT NULL DEFAULT 0 CHECK (amount >= 0),
  reason text,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS collection_receipt_circulation_events_receipt_idx
  ON public.collection_receipt_circulation_events(receipt_id, created_at DESC);
CREATE INDEX IF NOT EXISTS collection_receipt_circulation_events_manager_idx
  ON public.collection_receipt_circulation_events(manager_id, created_at DESC);

REVOKE INSERT, UPDATE, DELETE ON public.collection_receipt_circulation_events FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.collection_receipt_circulation_events TO authenticated;

ALTER TABLE public.collection_receipt_circulation_events ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public' AND tablename='collection_receipt_circulation_events'
      AND policyname='collection_receipt_circulation_events_read_own'
  ) THEN
    CREATE POLICY collection_receipt_circulation_events_read_own
      ON public.collection_receipt_circulation_events FOR SELECT TO authenticated
      USING (
        actor_user_id = auth.uid()
        OR EXISTS (
          SELECT 1 FROM public.collection_receipts r
          WHERE r.id = receipt_id AND r.created_by = auth.uid()
        )
      );
  END IF;
END $$;

-- La app puede registrar una acción de circulación por RPC; no cambia pagos ni saldos.
CREATE OR REPLACE FUNCTION public.dental_jg_set_receipt_circulation(
  p_receipt_id uuid,
  p_action text,
  p_reason text DEFAULT NULL
) RETURNS public.collection_receipts
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  r public.collection_receipts;
  v_old text;
  v_new text;
  v_event text;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Inicia sesión para actualizar la circulación de recibos.';
  END IF;

  SELECT * INTO r
  FROM public.collection_receipts
  WHERE id = p_receipt_id
  FOR UPDATE;

  IF NOT FOUND THEN RAISE EXCEPTION 'No se encontró el recibo.'; END IF;
  IF r.created_by <> auth.uid() THEN
    RAISE EXCEPTION 'Solo la cuenta que administra este recibo puede cambiar su estado.';
  END IF;

  v_old := r.circulation_status;
  v_new := v_old;

  CASE lower(btrim(coalesce(p_action,'')))
    WHEN 'deliver' THEN
      IF r.payment_id IS NOT NULL OR v_old IN ('paid','cancelled','returned') THEN
        RAISE EXCEPTION 'Este recibo no se puede entregar en su estado actual.';
      END IF;
      v_new := 'in_circulation'; v_event := 'delivered';
      UPDATE public.collection_receipts SET delivered_at=coalesce(delivered_at,now()), delivered_by=auth.uid(), circulation_status=v_new WHERE id=r.id RETURNING * INTO r;
    WHEN 'return' THEN
      IF r.payment_id IS NOT NULL OR v_old IN ('paid','cancelled') THEN
        RAISE EXCEPTION 'No se puede devolver un recibo ya cobrado o cancelado.';
      END IF;
      v_new := 'returned'; v_event := 'returned';
      UPDATE public.collection_receipts SET returned_at=now(), circulation_status=v_new WHERE id=r.id RETURNING * INTO r;
    WHEN 'cancel' THEN
      IF r.payment_id IS NOT NULL OR v_old='paid' THEN
        RAISE EXCEPTION 'No se puede cancelar un recibo vinculado a un pago real.';
      END IF;
      IF length(btrim(coalesce(p_reason,''))) < 3 THEN
        RAISE EXCEPTION 'Escribe el motivo de la cancelación.';
      END IF;
      v_new := 'cancelled'; v_event := 'cancelled';
      UPDATE public.collection_receipts SET cancelled_at=now(), cancellation_reason=left(btrim(p_reason),500), circulation_status=v_new WHERE id=r.id RETURNING * INTO r;
    WHEN 'reprint' THEN
      v_event := 'reprinted';
    ELSE
      RAISE EXCEPTION 'Acción no válida. Usa deliver, return, cancel o reprint.';
  END CASE;

  INSERT INTO public.collection_receipt_circulation_events(
    receipt_id, receipt_folio, manager_id, actor_user_id, event_type,
    previous_status, new_status, amount, reason, details
  ) VALUES (
    r.id, r.folio, r.manager_id, auth.uid(), v_event,
    v_old, r.circulation_status, coalesce(r.payment_amount,0), nullif(left(coalesce(p_reason,''),500),''),
    jsonb_build_object('payment_id',r.payment_id,'patient_id',r.patient_id)
  );
  RETURN r;
END;
$$;
REVOKE ALL ON FUNCTION public.dental_jg_set_receipt_circulation(uuid,text,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.dental_jg_set_receipt_circulation(uuid,text,text) TO authenticated;

-- Todo recibo nace en circulación si no está ligado a un pago; los ligados a pagos quedan paid.
-- También cubre el caso en que un recibo programado se vincule después con un pago real.
CREATE OR REPLACE FUNCTION public.dental_jg_receipt_circulation_sync_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_old text;
  v_new text;
  v_event text;
BEGIN
  v_old := CASE WHEN TG_OP='UPDATE' THEN OLD.circulation_status ELSE NULL END;
  v_new := CASE WHEN NEW.payment_id IS NOT NULL THEN 'paid'
                WHEN NEW.circulation_status='paid' THEN 'in_circulation'
                ELSE coalesce(NEW.circulation_status,'in_circulation') END;
  NEW.circulation_status := v_new;

  IF TG_OP='INSERT' THEN
    v_event := CASE WHEN NEW.payment_id IS NOT NULL THEN 'marked_paid' ELSE 'created' END;
    INSERT INTO public.collection_receipt_circulation_events(
      receipt_id,receipt_folio,manager_id,actor_user_id,event_type,previous_status,new_status,amount,details
    ) VALUES (NEW.id,NEW.folio,NEW.manager_id,auth.uid(),v_event,NULL,v_new,coalesce(NEW.payment_amount,0),
      jsonb_build_object('payment_id',NEW.payment_id,'patient_id',NEW.patient_id));
  ELSIF NEW.payment_id IS DISTINCT FROM OLD.payment_id AND NEW.payment_id IS NOT NULL THEN
    v_event := 'marked_paid';
    INSERT INTO public.collection_receipt_circulation_events(
      receipt_id,receipt_folio,manager_id,actor_user_id,event_type,previous_status,new_status,amount,details
    ) VALUES (NEW.id,NEW.folio,NEW.manager_id,auth.uid(),v_event,v_old,v_new,coalesce(NEW.payment_amount,0),
      jsonb_build_object('payment_id',NEW.payment_id,'patient_id',NEW.patient_id));
  END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS dental_jg_receipt_circulation_sync ON public.collection_receipts;
CREATE TRIGGER dental_jg_receipt_circulation_sync
BEFORE INSERT OR UPDATE OF payment_id, circulation_status ON public.collection_receipts
FOR EACH ROW EXECUTE FUNCTION public.dental_jg_receipt_circulation_sync_trigger();

-- Vista de resumen: cada fila de recibo cuenta una sola vez. No suma como cobro los no pagados.
CREATE OR REPLACE VIEW public.dental_jg_receipt_circulation_summary WITH (security_invoker = true) AS
SELECT
  r.manager_id,
  COALESCE(m.full_name, 'Sin gestor asignado') AS manager_name,
  count(*) FILTER (WHERE r.circulation_status IN ('generated','in_circulation')) AS receipts_in_circulation,
  count(*) FILTER (WHERE r.circulation_status='generated') AS receipts_generated_not_delivered,
  count(*) FILTER (WHERE r.circulation_status='in_circulation') AS receipts_delivered_unpaid,
  count(*) FILTER (WHERE r.circulation_status='paid' OR r.payment_id IS NOT NULL) AS receipts_paid,
  count(*) FILTER (WHERE r.circulation_status='returned') AS receipts_returned,
  count(*) FILTER (WHERE r.circulation_status='cancelled') AS receipts_cancelled,
  COALESCE(sum(r.payment_amount) FILTER (WHERE r.circulation_status IN ('generated','in_circulation')),0)::numeric(12,2) AS amount_in_circulation,
  COALESCE(sum(r.payment_amount) FILTER (WHERE r.circulation_status='paid' OR r.payment_id IS NOT NULL),0)::numeric(12,2) AS amount_paid_receipts
FROM public.collection_receipts r
LEFT JOIN public.collection_managers m ON m.id=r.manager_id
GROUP BY r.manager_id, m.full_name;

COMMIT;

-- Verificación posterior (los resultados se muestran en SQL Editor):
SELECT circulation_status, count(*) AS recibos, COALESCE(sum(payment_amount),0) AS importe
FROM public.collection_receipts GROUP BY circulation_status ORDER BY circulation_status;
SELECT * FROM public.dental_jg_receipt_circulation_summary ORDER BY manager_name;
