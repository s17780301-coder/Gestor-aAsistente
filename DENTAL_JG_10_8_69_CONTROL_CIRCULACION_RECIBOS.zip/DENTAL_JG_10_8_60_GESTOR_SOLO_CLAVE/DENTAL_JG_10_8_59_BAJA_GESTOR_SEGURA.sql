-- DENTAL JG 10.8.59 — evita perder asignaciones e historial al borrar gestores.
-- Ejecutar manualmente en Supabase SQL Editor después de las migraciones base.
-- Esta migración NO borra ni modifica datos existentes.

begin;
create or replace function public.dental_jg_prevent_manager_delete_with_history()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  has_refs boolean := false;
begin
  if to_regclass('public.patients') is not null then
    execute 'select exists(select 1 from public.patients where assigned_manager_id = $1)' into has_refs using OLD.id;
    if has_refs then
      raise exception 'No se puede eliminar este gestor: tiene pacientes asignados. Desactívalo para conservar el historial.';
    end if;
  end if;
  if to_regclass('public.collection_receipts') is not null then
    execute 'select exists(select 1 from public.collection_receipts where manager_id = $1)' into has_refs using OLD.id;
    if has_refs then
      raise exception 'No se puede eliminar este gestor: tiene recibos asociados. Desactívalo para conservar el historial.';
    end if;
  end if;
  if to_regclass('public.collection_quincena_reports') is not null then
    execute 'select exists(select 1 from public.collection_quincena_reports where manager_id = $1)' into has_refs using OLD.id;
    if has_refs then
      raise exception 'No se puede eliminar este gestor: tiene reportes quincenales asociados. Desactívalo para conservar el historial.';
    end if;
  end if;
  return OLD;
end;
$$;

drop trigger if exists dental_jg_prevent_manager_delete_with_history on public.collection_managers;
create trigger dental_jg_prevent_manager_delete_with_history
before delete on public.collection_managers
for each row execute function public.dental_jg_prevent_manager_delete_with_history();
commit;
