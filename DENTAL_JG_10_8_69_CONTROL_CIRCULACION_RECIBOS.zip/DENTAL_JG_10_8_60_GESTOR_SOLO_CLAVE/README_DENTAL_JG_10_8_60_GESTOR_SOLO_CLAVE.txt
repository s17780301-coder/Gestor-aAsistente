DENTAL JG 10.8.60 — GESTOR CON ACCESO SOLO POR CLAVE

QUÉ CAMBIÓ
- La app Gestor ya no solicita correo ni contraseña personal de Supabase.
- Si no existe sesión, pide la clave del gestor al abrir la app. Al salir de la sesión vuelve a pedir la clave.
- La sincronización usa funciones RPC que validan la clave y limitan pacientes y pagos al gestor correspondiente.
- No se añadió service_role ni contraseña administrativa a la APK.

PASO OBLIGATORIO
Antes de utilizar esta versión, haz respaldo de Supabase y ejecuta completo el archivo DENTAL_JG_10_8_60_LOGIN_SOLO_CLAVE_GESTOR.sql en SQL Editor. Comprueba que los gestores activos tengan manager_key único. Usa claves largas, únicas y no compartidas.

PRUEBAS
La entrega es de código fuente. No se generó APK ni se ejecutó la migración contra el Supabase remoto. Debes probar clave válida/incorrecta, aislamiento entre dos gestores, altas de pacientes y sincronización de pagos en un entorno de prueba antes de distribuir.
