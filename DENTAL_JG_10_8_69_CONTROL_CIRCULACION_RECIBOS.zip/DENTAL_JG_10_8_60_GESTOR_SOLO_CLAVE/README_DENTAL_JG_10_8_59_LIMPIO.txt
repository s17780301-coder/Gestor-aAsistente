DENTAL JG 10.8.59 — LIMPIO Y CORREGIDO

Contenido:
- gestor-app: aplicación Android de gestores.
- panel-apk: aplicación Android de administración.
- cobranza-app: aplicación Android de cobranza y recibos.
- registro-app: aplicación Android de registro de clientes.
- SQL de migración: se conservan los scripts necesarios para configurar y actualizar Supabase.

Correcciones incluidas en esta limpieza:
1. Al sincronizar un paciente local nuevo desde la aplicación Gestor, se envía assigned_manager_id con el gestor autenticado/validado para conservar su asignación.
2. Se actualizó la versión de caché de los service workers y el parámetro de actualización a 10.8.59 para reducir la posibilidad de cargar archivos web antiguos.
3. Se añadió DENTAL_JG_10_8_59_BAJA_GESTOR_SEGURA.sql, una migración opcional que bloquea la eliminación física de gestores con pacientes, recibos o reportes asociados. Debe ejecutarse manualmente en Supabase; no se ejecutó desde este paquete.
4. Se retiraron notas y registros de versiones históricas que no participan en la ejecución. Se conservaron las migraciones SQL y los recursos referenciados por las aplicaciones.

IMPORTANTE:
- El ZIP es código fuente; no contiene APK nuevas compiladas.
- La migración SQL nueva no se ejecuta automáticamente. Haz una copia de seguridad y revisa las migraciones antes de ejecutarla en producción.
- No se cambiaron applicationId ni versionCode para evitar que las apps se traten como instalaciones distintas y se pongan en riesgo los datos locales.
- Las comprobaciones automáticas de archivos no sustituyen una compilación Android ni una prueba con una cuenta real de Supabase y una impresora.


ACTUALIZACIÓN 10.8.60 — INICIO DE SESIÓN GESTOR
- La app Gestor solicita solo la clave de gestor; ya no solicita correo/contraseña Supabase.
- La sincronización usa RPC limitados por clave de gestor. La migración DENTAL_JG_10_8_60_LOGIN_SOLO_CLAVE_GESTOR.sql debe ejecutarse en Supabase antes de usar esta versión.
- No se incorpora service_role ni contraseña administrativa a la APK.
