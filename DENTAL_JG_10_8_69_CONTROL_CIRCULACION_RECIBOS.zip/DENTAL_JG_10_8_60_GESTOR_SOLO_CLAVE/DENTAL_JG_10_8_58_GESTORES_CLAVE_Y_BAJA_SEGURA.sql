-- DENTAL JG 10.8.58: permisos para editar nombre, teléfono, clave y estado de gestores.
-- Ejecutar en Supabase SQL Editor con una cuenta propietaria del proyecto.
begin;
grant select, insert, update, delete on public.collection_managers to authenticated;
drop policy if exists "admin manages shared collection managers" on public.collection_managers;
create policy "admin manages shared collection managers" on public.collection_managers
for all to authenticated
using (exists (select 1 from public.app_user_roles r where r.user_id = auth.uid() and r.role = 'admin'))
with check (exists (select 1 from public.app_user_roles r where r.user_id = auth.uid() and r.role = 'admin'));
commit;
