-- DENTAL JG 10.8.60: inicio de sesión Gestor solo con clave de gestor.
-- Ejecutar en Supabase SQL Editor después de respaldar la base.
-- No usar service_role ni credenciales de administrador dentro de la APK.

alter table public.collection_managers add column if not exists manager_key text;
alter table public.collection_managers add column if not exists active boolean not null default true;
alter table public.patients add column if not exists assigned_manager_id uuid references public.collection_managers(id) on delete set null;
create unique index if not exists collection_managers_manager_key_unique
  on public.collection_managers(manager_key)
  where manager_key is not null and btrim(manager_key) <> '';

create or replace function public.dental_jg_manager_by_key(p_manager_key text)
returns table(id uuid, full_name text)
language sql
security definer
set search_path = public
as $$
  select m.id, m.full_name
  from public.collection_managers m
  where m.active is distinct from false
    and m.manager_key = trim(coalesce(p_manager_key, ''))
    and length(trim(coalesce(p_manager_key, ''))) >= 4
  limit 1;
$$;

create or replace function public.dental_jg_manager_patients(p_manager_key text)
returns setof jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_manager uuid;
begin
  select m.id into v_manager from public.collection_managers m
  where m.active is distinct from false and m.manager_key=trim(coalesce(p_manager_key,''))
    and length(trim(coalesce(p_manager_key,''))) >= 4 limit 1;
  if v_manager is null then raise exception 'Clave de gestor incorrecta o gestor inactivo.'; end if;
  return query select to_jsonb(p) from public.patients p
    where p.assigned_manager_id=v_manager order by p.created_at desc;
end;
$$;

create or replace function public.dental_jg_manager_insert_patient(p_manager_key text, p_patient jsonb)
returns setof jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_manager uuid; v_patient public.patients;
begin
  select m.id into v_manager from public.collection_managers m
  where m.active is distinct from false and m.manager_key=trim(coalesce(p_manager_key,''))
    and length(trim(coalesce(p_manager_key,''))) >= 4 limit 1;
  if v_manager is null then raise exception 'Clave de gestor incorrecta o gestor inactivo.'; end if;
  if coalesce(trim(p_patient->>'name'),'')='' then raise exception 'El paciente requiere nombre.'; end if;
  insert into public.patients(name,phone,treatment,total,paid,installments,installment_amount,policy_number,clinic,source_device,assigned_manager_id)
  values(coalesce(p_patient->>'name','Paciente'),coalesce(p_patient->>'phone',''),coalesce(p_patient->>'treatment',''),
    greatest(0,coalesce((p_patient->>'total')::numeric,0)),greatest(0,coalesce((p_patient->>'paid')::numeric,0)),
    greatest(0,coalesce((p_patient->>'installments')::integer,0)),greatest(0,coalesce((p_patient->>'installment_amount')::numeric,0)),
    coalesce(p_patient->>'policy_number',''),coalesce(p_patient->>'clinic','DENTAL JG'),
    coalesce(p_patient->>'source_device','DENTAL JG APK'),v_manager)
  returning * into v_patient;
  return next to_jsonb(v_patient);
end;
$$;

create or replace function public.dental_jg_manager_payments(p_manager_key text)
returns setof jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_manager uuid;
begin
  select m.id into v_manager from public.collection_managers m
  where m.active is distinct from false and m.manager_key=trim(coalesce(p_manager_key,''))
    and length(trim(coalesce(p_manager_key,''))) >= 4 limit 1;
  if v_manager is null then raise exception 'Clave de gestor incorrecta o gestor inactivo.'; end if;
  return query select to_jsonb(pay) from public.payments pay
    join public.patients p on p.id=pay.patient_id
    where p.assigned_manager_id=v_manager order by pay.paid_at desc;
end;
$$;

create or replace function public.dental_jg_manager_insert_payment(p_manager_key text, p_payment jsonb)
returns setof jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_manager uuid; v_patient public.patients; v_payment public.payments;
begin
  select m.id into v_manager from public.collection_managers m
  where m.active is distinct from false and m.manager_key=trim(coalesce(p_manager_key,''))
    and length(trim(coalesce(p_manager_key,''))) >= 4 limit 1;
  if v_manager is null then raise exception 'Clave de gestor incorrecta o gestor inactivo.'; end if;
  select p.* into v_patient from public.patients p
  where p.id=(p_payment->>'patient_id')::uuid and p.assigned_manager_id=v_manager;
  if not found then raise exception 'El paciente no pertenece a este gestor.'; end if;
  if coalesce((p_payment->>'amount')::numeric,0)<=0 then raise exception 'El importe del abono debe ser mayor que cero.'; end if;
  insert into public.payments(patient_id,patient_name,amount,concept,reference,source_device)
  values(v_patient.id,coalesce(p_payment->>'patient_name',v_patient.name),(p_payment->>'amount')::numeric,
    coalesce(p_payment->>'concept','Abono'),coalesce(p_payment->>'reference',''),coalesce(p_payment->>'source_device','DENTAL JG APK'))
  returning * into v_payment;
  return next to_jsonb(v_payment);
end;
$$;

create or replace function public.dental_jg_manager_sync_patient_paid(p_manager_key text, p_patient_id uuid, p_new_paid numeric)
returns setof jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_manager uuid; v_paid numeric(12,2);
begin
  select m.id into v_manager from public.collection_managers m
  where m.active is distinct from false and m.manager_key=trim(coalesce(p_manager_key,''))
    and length(trim(coalesce(p_manager_key,''))) >= 4 limit 1;
  if v_manager is null then raise exception 'Clave de gestor incorrecta o gestor inactivo.'; end if;
  update public.patients set paid=greatest(coalesce(paid,0),greatest(coalesce(p_new_paid,0),0)),updated_at=now()
  where id=p_patient_id and assigned_manager_id=v_manager returning paid into v_paid;
  if not found then raise exception 'El paciente no pertenece a este gestor.'; end if;
  return next jsonb_build_object('paid',v_paid);
end;
$$;

-- La clave de gestor es el único dato que introduce el usuario de esta APK.
-- Los RPC comprueban la clave y limitan todas las operaciones al gestor asociado.
revoke all on function public.dental_jg_manager_by_key(text) from public, authenticated;
revoke all on function public.dental_jg_manager_patients(text) from public, authenticated;
revoke all on function public.dental_jg_manager_insert_patient(text,jsonb) from public, authenticated;
revoke all on function public.dental_jg_manager_payments(text) from public, authenticated;
revoke all on function public.dental_jg_manager_insert_payment(text,jsonb) from public, authenticated;
revoke all on function public.dental_jg_manager_sync_patient_paid(text,uuid,numeric) from public, authenticated;
grant execute on function public.dental_jg_manager_by_key(text) to anon;
grant execute on function public.dental_jg_manager_patients(text) to anon;
grant execute on function public.dental_jg_manager_insert_patient(text,jsonb) to anon;
grant execute on function public.dental_jg_manager_payments(text) to anon;
grant execute on function public.dental_jg_manager_insert_payment(text,jsonb) to anon;
grant execute on function public.dental_jg_manager_sync_patient_paid(text,uuid,numeric) to anon;
