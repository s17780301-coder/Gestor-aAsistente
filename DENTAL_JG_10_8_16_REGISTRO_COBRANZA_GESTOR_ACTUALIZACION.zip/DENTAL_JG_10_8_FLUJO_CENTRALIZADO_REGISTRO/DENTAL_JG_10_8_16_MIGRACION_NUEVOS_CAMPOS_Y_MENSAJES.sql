-- DENTAL JG 10.8.16 — migración de forma de pago y mensajería interna.
-- Ejecutar en Supabase SQL Editor una sola vez después de hacer respaldo.

-- DENTAL JG 10.8.14: datos de titular y condiciones de pago sincronizadas con Cobranza.
-- Ejecutar en Supabase SQL Editor antes de usar los nuevos campos.
alter table public.patients add column if not exists holder_name text not null default '';
alter table public.patients add column if not exists payment_mode text not null default 'quincenal';
alter table public.patients add column if not exists tabulator numeric(12,2) not null default 0;
alter table public.patients add column if not exists first_payment_date date;
alter table public.patients add column if not exists payment_method text not null default 'efectivo';
update public.patients set payment_method='efectivo' where payment_method is null or payment_method not in ('efectivo','transferencia');

-- Mantener compatibilidad de los datos existentes sin modificar sus folios.
update public.patients set holder_name=coalesce(nullif(holder_name,''), first_names, name, '') where coalesce(holder_name,'')='';
update public.patients set payment_mode='quincenal' where payment_mode is null or payment_mode not in ('quincenal','mensual');

-- Reemplaza la función de alta por una versión que guarda las condiciones completas de pago.
drop function if exists public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text);
drop function if exists public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,text,text,numeric,date);
drop function if exists public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,text,text,numeric,date,text);
create or replace function public.register_dental_jg_patient(
 p_name text, p_phone text, p_treatment text, p_total numeric,
 p_installments integer, p_installment_amount numeric, p_policy_number text, p_clinic text,
 p_first_names text, p_surnames text, p_address text, p_phone2 text, p_observations text,
 p_holder_name text, p_payment_mode text, p_tabulator numeric, p_first_payment_date date, p_payment_method text default 'efectivo'
) returns uuid language plpgsql security definer set search_path=public as $$
declare new_id uuid; new_folio text;
begin
 if auth.uid() is null then raise exception 'Inicia sesión para registrar clientes.'; end if;
 if not exists(select 1 from public.app_user_roles where user_id=auth.uid() and role in ('registro','admin')) then raise exception 'Esta cuenta no tiene permiso para registrar clientes.'; end if;
 if length(trim(coalesce(p_holder_name,'')))=0 or length(trim(coalesce(p_first_names,p_name,'')))=0  or length(trim(coalesce(p_clinic,'')))=0 or length(trim(coalesce(p_policy_number,'')))=0 or length(trim(coalesce(p_address,'')))=0 or length(trim(coalesce(p_phone,'')))=0 then raise exception 'Completa todos los campos obligatorios.'; end if;
 if coalesce(p_payment_mode,'') not in ('quincenal','mensual') then raise exception 'Selecciona periodicidad quincenal o mensual.'; end if;
 if coalesce(p_payment_method,'') not in ('efectivo','transferencia') then raise exception 'Selecciona forma de pago efectivo o transferencia.'; end if;
 if coalesce(p_total,0)<=0 or coalesce(p_installments,0)<1 or coalesce(p_installment_amount,0)<=0 or coalesce(p_tabulator,0)<0 or p_first_payment_date is null then raise exception 'Verifica monto total, cantidad por pago, número de pagos, tabulador y fecha del primer pago.'; end if;
 new_folio:='JG-'||lpad(nextval('public.dental_jg_patient_folio_seq')::text,6,'0');
 insert into public.patients(folio,holder_name,first_names,surnames,address,phone2,observations,name,phone,treatment,total,paid,installments,installment_amount,policy_number,clinic,source_device,created_at,updated_at,payment_mode,tabulator,first_payment_date,payment_method)
 values(new_folio,trim(p_holder_name),trim(coalesce(p_first_names,p_name)),trim(coalesce(p_surnames,'')),trim(coalesce(p_address,'')),trim(coalesce(p_phone2,'')),trim(coalesce(p_observations,'')),trim(p_name),trim(p_phone),trim(coalesce(p_observations,p_treatment,'')),p_total,0,p_installments,p_installment_amount,trim(p_policy_number),trim(p_clinic),'DENTAL JG Registro',now(),now(),p_payment_mode,p_tabulator,p_first_payment_date,p_payment_method) returning id into new_id;
 return new_id;
end; $$;
revoke all on function public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,text,text,numeric,date,text) from public, anon;
grant execute on function public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,text,text,numeric,date,text) to authenticated;


-- Mensajería interna (sin volver a crear la antigua función de registro de clientes).
create table if not exists public.app_internal_messages (
 id uuid primary key default gen_random_uuid(), sender_id uuid not null references auth.users(id) on delete cascade,
 recipient_id uuid not null references auth.users(id) on delete cascade, sender_app text not null, recipient_app text not null,
 subject text not null default '', body text not null, created_at timestamptz not null default now(), read_at timestamptz
);
alter table public.app_internal_messages enable row level security;
grant select,insert,update on public.app_internal_messages to authenticated;
drop policy if exists "messages visible to sender or recipient" on public.app_internal_messages;
create policy "messages visible to sender or recipient" on public.app_internal_messages for select to authenticated using(auth.uid()=sender_id or auth.uid()=recipient_id);
drop policy if exists "users send internal messages" on public.app_internal_messages;
create policy "users send internal messages" on public.app_internal_messages for insert to authenticated with check(auth.uid()=sender_id);
drop policy if exists "recipients mark messages read" on public.app_internal_messages;
create policy "recipients mark messages read" on public.app_internal_messages for update to authenticated using(auth.uid()=recipient_id) with check(auth.uid()=recipient_id);
create index if not exists app_internal_messages_recipient_created_idx on public.app_internal_messages(recipient_id,created_at desc);
do $$ begin if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='app_internal_messages') then alter publication supabase_realtime add table public.app_internal_messages; end if; end $$;
create or replace function public.send_dental_jg_internal_message(p_recipient_role text,p_sender_app text,p_subject text,p_body text)
returns integer language plpgsql security definer set search_path=public as $$
declare n integer;
begin
 if auth.uid() is null then raise exception 'Inicia sesión para enviar mensajes.'; end if;
 if coalesce(trim(p_body),'')='' then raise exception 'Escribe el mensaje.'; end if;
 insert into public.app_internal_messages(sender_id,recipient_id,sender_app,recipient_app,subject,body)
 select auth.uid(),r.user_id,coalesce(nullif(trim(p_sender_app),''),'DENTAL JG'),p_recipient_role,coalesce(trim(p_subject),''),trim(p_body)
 from public.app_user_roles r where r.role=p_recipient_role and r.user_id<>auth.uid();
 get diagnostics n = row_count;
 return n;
end; $$;
revoke all on function public.send_dental_jg_internal_message(text,text,text,text) from public,anon;
grant execute on function public.send_dental_jg_internal_message(text,text,text,text) to authenticated;

-- Permite borrar mensajes propios: enviados o recibidos.
grant delete on public.app_internal_messages to authenticated;
drop policy if exists "sender or recipient delete messages" on public.app_internal_messages;
create policy "sender or recipient delete messages" on public.app_internal_messages for delete to authenticated using(auth.uid()=sender_id or auth.uid()=recipient_id);
