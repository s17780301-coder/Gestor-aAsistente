DENTAL JG 10.8.16 — cambios solicitados

INCLUYE
- Registro: elimina los campos separados de nombre y apellidos del paciente; usa el nombre del titular como nombre visible del expediente.
- Registro: agrega forma de pago efectivo/transferencia; el tabulador no muestra símbolo de moneda; monto por pago y total de póliza muestran el signo $; el total se calcula automáticamente como cantidad por pago × número de pagos.
- Registro: el campo Número de quincenas/mensualidades se conserva porque es un dato necesario para el cálculo automático del total. La petición original también pedía quitarlo, pero sin ese dato no se puede calcular el total a partir de cantidad por pago × número de pagos.
- Mensajes: añade messages.js a las carpetas web donde el HTML ya lo invocaba; permite borrar mensajes enviados o recibidos.
- Cobranza: el recibo muestra FORMA DE PAGO: TRANSFERENCIA cuando así está configurado el cliente.
- Gestor: quita la barra duplicada de Ingresar recibos/pagos, añade una sección de clientes por transferencia, recordatorios de quincena y selector de tonos del teléfono.
- Android: aumenta versionCode manteniendo applicationId para permitir actualización si se firma con la misma clave que la versión instalada.

PASOS ANTES DE USAR
1. Haz una copia de seguridad de Supabase.
2. Ejecuta DENTAL_JG_10_8_16_MIGRACION_NUEVOS_CAMPOS_Y_MENSAJES.sql en Supabase SQL Editor.
3. Publica los archivos web actualizados en los mismos directorios de cada aplicación.
4. Para APK, compila e instala desde Android Studio. Para actualizar sobre la instalación existente, firma con el MISMO keystore/clave que se usó en la APK anterior. Subir versionCode no resuelve un conflicto de firma. Si no tienes la clave original, Android exigirá desinstalar la app anterior; no es posible evitarlo desde el código.

VALIDACIÓN
- Se revisó sintaxis JavaScript con node --check.
- Se revisó que los XML sean válidos.
- No se ejecutó la migración en tu proyecto Supabase ni se compiló la APK en un entorno Android con SDK, por lo que debe probarse antes de producción.
