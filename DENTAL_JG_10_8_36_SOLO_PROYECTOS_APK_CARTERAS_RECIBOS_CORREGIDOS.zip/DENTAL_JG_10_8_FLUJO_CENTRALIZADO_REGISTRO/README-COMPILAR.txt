DENTAL JG 10.8.35 — SOLO PROYECTOS ANDROID PARA GENERAR APK

Este paquete conserva los cuatro proyectos Android y los archivos SQL/notas necesarios para compilar y configurar las aplicaciones. Se eliminaron las versiones web independientes y el paquete de aplicación para Windows.

APLICACIONES ANDROID
- gestor-app: aplicación Gestor
- panel-apk: aplicación Panel administrativo
- cobranza-app: aplicación Cobranza y recibos
- registro-app: aplicación Registro de clientes

COMPILACIÓN
1. Sube el contenido de este ZIP a tu repositorio GitHub.
2. Abre Actions y ejecuta el flujo de compilación incluido en .github/workflows/main.yml (o espera a que se ejecute al subir cambios a main/master).
3. Descarga el artefacto DENTAL-JG-Cuatro-Apps-Android. Incluye las cuatro APK.

IMPORTANTE
- Este paquete contiene proyectos fuente, no APK ya compiladas.
- No se eliminaron los recursos web que están dentro de los módulos Android, porque algunas APK los necesitan para funcionar. Solo se quitaron las aplicaciones web independientes.
- Conserva y ejecuta en Supabase los archivos SQL que correspondan a las funciones que vas a utilizar. Revisa los archivos LEEME y de migración antes de aplicar cambios en la base de datos.
- La compilación y el funcionamiento real deben verificarse con el flujo de GitHub Actions y probando las APK en Android.
