-- DENTAL JG 10.8 — Asignar permiso a la cuenta de Registro de Clientes.
-- Ejecutar en Supabase > SQL Editor con una cuenta administradora del proyecto.
-- IMPORTANTE: reemplaza el correo por el correo exacto que usas para iniciar sesión.
-- Este script NO crea usuarios ni concede permisos de administrador; solo asigna 'registro'.
DO $$
DECLARE
  correo_objetivo text := 'CAMBIA_POR_EL_CORREO_REAL';
  usuario_objetivo uuid;
BEGIN
  IF correo_objetivo = 'CAMBIA_POR_EL_CORREO_REAL' OR position('@' in correo_objetivo) = 0 THEN
    RAISE EXCEPTION 'Edita correo_objetivo y escribe el correo real antes de ejecutar este script.';
  END IF;

  SELECT id INTO usuario_objetivo
  FROM auth.users
  WHERE lower(email) = lower(correo_objetivo)
  LIMIT 1;

  IF usuario_objetivo IS NULL THEN
    RAISE EXCEPTION 'No existe una cuenta Auth con ese correo en este proyecto de Supabase. Verifica el proyecto y el correo.';
  END IF;

  INSERT INTO public.app_user_roles(user_id, role)
  VALUES (usuario_objetivo, 'registro')
  ON CONFLICT (user_id, role) DO NOTHING;

  RAISE NOTICE 'Rol registro asignado o ya existente para %', correo_objetivo;
END $$;

-- Verificación: debe aparecer una fila con role = registro.
-- Sustituye el correo aquí también antes de ejecutar esta consulta por separado.
SELECT u.email, r.role
FROM auth.users u
JOIN public.app_user_roles r ON r.user_id = u.id
WHERE lower(u.email) = lower('CAMBIA_POR_EL_CORREO_REAL');
