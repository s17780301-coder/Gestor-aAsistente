-- AVISO DENTAL JG 1.0.6: SCRIPT HISTÓRICO / SUPERSEDIDO PARA LA MIGRACIÓN INTEGRADA.
-- No ejecutar después de DENTAL_JG_1_0_6_MIGRACION_SQL_INTEGRADA.sql: puede recrear
-- firmas antiguas de funciones, políticas RLS o permisos que esta versión restringe.
-- Conservar solo como referencia histórica.

-- DENTAL JG - Fase 8: una cartera por clínica y gestor asignado.
-- No elimina pacientes, pagos, recibos ni reportes históricos.
-- Respaldar Supabase antes de ejecutar.

BEGIN;

ALTER TABLE public.collection_portfolios
  ADD COLUMN IF NOT EXISTS manager_id uuid;

-- La clave anterior solo permitía una cartera por clínica y no separaba gestores.
ALTER TABLE public.collection_portfolios
  DROP CONSTRAINT IF EXISTS collection_portfolios_created_by_clinic_name_key;
DROP INDEX IF EXISTS public.collection_portfolios_created_by_clinic_name_key;

CREATE UNIQUE INDEX IF NOT EXISTS collection_portfolios_created_clinic_manager_uq
  ON public.collection_portfolios (created_by, clinic_name, manager_id);
CREATE INDEX IF NOT EXISTS collection_portfolios_manager_idx
  ON public.collection_portfolios (manager_id);

-- Reparte las asignaciones existentes según el gestor realmente guardado en cada paciente.
-- No asigna pacientes sin assigned_manager_id ni sobrescribe un gestor existente.
DO $$
DECLARE
  old_portfolio record;
  grp record;
  new_portfolio_id uuid;
  manager_name text;
BEGIN
  FOR old_portfolio IN
    SELECT p.id, p.created_by, p.clinic_name
    FROM public.collection_portfolios p
    WHERE p.manager_id IS NULL
  LOOP
    FOR grp IN
      SELECT DISTINCT pt.assigned_manager_id AS manager_id
      FROM public.collection_portfolio_patients cpp
      JOIN public.patients pt ON pt.id = cpp.patient_id
      WHERE cpp.portfolio_id = old_portfolio.id
        AND pt.assigned_manager_id IS NOT NULL
    LOOP
      SELECT cm.full_name INTO manager_name
      FROM public.collection_managers cm
      WHERE cm.id = grp.manager_id AND cm.active IS DISTINCT FROM false;

      IF manager_name IS NULL THEN
        CONTINUE;
      END IF;

      INSERT INTO public.collection_portfolios(created_by, clinic_name, name, manager_id, updated_at)
      VALUES (old_portfolio.created_by, old_portfolio.clinic_name,
              'Cartera - ' || old_portfolio.clinic_name || ' - ' || manager_name,
              grp.manager_id, now())
      ON CONFLICT (created_by, clinic_name, manager_id)
      DO UPDATE SET name = EXCLUDED.name, updated_at = now()
      RETURNING id INTO new_portfolio_id;

      INSERT INTO public.collection_portfolio_patients(created_by, portfolio_id, patient_id)
      SELECT cpp.created_by, new_portfolio_id, cpp.patient_id
      FROM public.collection_portfolio_patients cpp
      JOIN public.patients pt ON pt.id = cpp.patient_id
      WHERE cpp.portfolio_id = old_portfolio.id
        AND pt.assigned_manager_id = grp.manager_id
      ON CONFLICT (portfolio_id, patient_id) DO NOTHING;

      DELETE FROM public.collection_portfolio_patients cpp
      USING public.patients pt
      WHERE cpp.portfolio_id = old_portfolio.id
        AND pt.id = cpp.patient_id
        AND pt.assigned_manager_id = grp.manager_id;
    END LOOP;
  END LOOP;
END;
$$;

COMMIT;

-- Verificación de solo lectura:
-- SELECT clinic_name, manager_id, count(*)
-- FROM public.collection_portfolios GROUP BY clinic_name, manager_id ORDER BY clinic_name;
-- SELECT count(*) AS pacientes_sin_gestor FROM public.patients WHERE assigned_manager_id IS NULL;
