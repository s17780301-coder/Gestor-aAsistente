-- AVISO DENTAL JG 1.0.6: SCRIPT HISTÓRICO / SUPERSEDIDO PARA LA MIGRACIÓN INTEGRADA.
-- No ejecutar después de DENTAL_JG_1_0_6_MIGRACION_SQL_INTEGRADA.sql: puede recrear
-- firmas antiguas de funciones, políticas RLS o permisos que esta versión restringe.
-- Conservar solo como referencia histórica.

-- DENTAL JG 10.8 — registro centralizado y control quincenal. Migración aditiva.
-- Revisar políticas existentes antes de ejecutar en producción. No elimina clientes ni pagos.
create extension if not exists pgcrypto;

create table if not exists public.app_user_roles (
 user_id uuid not null references auth.users(id) on delete cascade,
 role text not null check (role in ('registro','cobranza','gestor','admin')),
 created_at timestamptz not null default now(),
 primary key(user_id, role)
);
alter table public.app_user_roles enable row level security;
grant select on public.app_user_roles to authenticated;
drop policy if exists "users view own app roles" on public.app_user_roles;
create policy "users view own app roles" on public.app_user_roles for select to authenticated using(user_id=auth.uid());
revoke insert, update, delete on public.app_user_roles from anon, authenticated;

-- Bloquea altas directas por API; los clientes nuevos se crean mediante función protegida.
-- Elimina todas las políticas antiguas de patients para evitar que una política permisiva
-- siga autorizando INSERT por OR aunque tenga otro nombre.
do $$ declare pol record; begin
 for pol in select policyname from pg_policies where schemaname='public' and tablename='patients' loop
   execute format('drop policy if exists %I on public.patients', pol.policyname);
 end loop;
end $$;
create policy "authenticated users view patients" on public.patients for select to authenticated using(true);
-- Mantiene la lectura de pacientes para las apps que trabajan con carteras. No se concede INSERT directo.
revoke insert on public.patients from anon, authenticated;
grant select on public.patients to authenticated;

create or replace function public.register_dental_jg_patient(
 p_name text, p_phone text default '', p_treatment text default '', p_total numeric default 0,
 p_installments integer default 0, p_installment_amount numeric default 0, p_policy_number text default '', p_clinic text default ''
) returns uuid language plpgsql security definer set search_path=public as $$
declare new_id uuid;
begin
 if auth.uid() is null then raise exception 'Inicia sesión para registrar clientes.'; end if;
 if not exists(select 1 from public.app_user_roles where user_id=auth.uid() and role in ('registro','admin')) then raise exception 'Esta cuenta no tiene permiso para registrar clientes.'; end if;
 if length(trim(coalesce(p_name,'')))=0 or length(trim(coalesce(p_clinic,'')))=0 then raise exception 'Nombre y clínica son obligatorios.'; end if;
 if coalesce(p_total,0)<0 or coalesce(p_installment_amount,0)<0 or coalesce(p_installments,0)<0 then raise exception 'Los importes y número de pagos no pueden ser negativos.'; end if;
 insert into public.patients(name,phone,treatment,total,paid,installments,installment_amount,policy_number,clinic,source_device,created_at,updated_at)
 values(trim(p_name),coalesce(trim(p_phone),''),coalesce(trim(p_treatment),''),coalesce(p_total,0),0,coalesce(p_installments,0),coalesce(p_installment_amount,0),coalesce(trim(p_policy_number),''),trim(p_clinic),'DENTAL JG Registro',now(),now()) returning id into new_id;
 return new_id;
end; $$;
revoke all on function public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text) from public, anon;
grant execute on function public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text) to authenticated;

-- Libro de cartera por periodo: conserva historial y evita sobrescribir quincenas anteriores.
create table if not exists public.collection_periods (
 id uuid primary key default gen_random_uuid(),
 period_date date not null,
 label text not null,
 status text not null default 'open' check(status in ('open','closed')),
 created_by uuid not null default auth.uid() references auth.users(id),
 created_at timestamptz not null default now(),
 unique(period_date)
);
create table if not exists public.collection_period_patients (
 id uuid primary key default gen_random_uuid(),
 period_id uuid not null references public.collection_periods(id) on delete cascade,
 patient_id uuid not null references public.patients(id) on delete restrict,
 status text not null default 'pending' check(status in ('pending','paid','partial','excluded')),
 expected_amount numeric(12,2) not null default 0 check(expected_amount>=0),
 payment_id uuid references public.payments(id) on delete set null,
 receipt_id uuid references public.collection_receipts(id) on delete set null,
 paid_at timestamptz,
 notes text not null default '',
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 unique(period_id,patient_id)
);
create index if not exists collection_period_patients_status_idx on public.collection_period_patients(period_id,status);
create index if not exists collection_period_patients_patient_idx on public.collection_period_patients(patient_id);
alter table public.collection_periods enable row level security;
alter table public.collection_period_patients enable row level security;
grant select,insert,update on public.collection_periods to authenticated;
grant select,insert,update on public.collection_period_patients to authenticated;
drop policy if exists "authorized users manage collection periods" on public.collection_periods;
create policy "authorized users manage collection periods" on public.collection_periods for all to authenticated using(exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('cobranza','admin'))) with check(exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('cobranza','admin')));
drop policy if exists "authorized users manage collection period patients" on public.collection_period_patients;
create policy "authorized users manage collection period patients" on public.collection_period_patients for all to authenticated using(exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('cobranza','gestor','admin'))) with check(exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('cobranza','gestor','admin')));

-- Crea un periodo y toma una fotografía de los clientes activos con saldo pendiente.
-- Una persona que pagó la quincena anterior puede volver a entrar en la nueva si aún debe saldo.
create or replace function public.generate_dental_jg_collection_period(p_period_date date) returns uuid
language plpgsql security definer set search_path=public as $$
declare v_period_id uuid; v_label text;
begin
 if auth.uid() is null or not exists(select 1 from public.app_user_roles where user_id=auth.uid() and role in ('cobranza','admin')) then raise exception 'No tienes permiso para generar carteras.'; end if;
 if extract(day from p_period_date) not in (15,28,29,30) then raise exception 'La fecha debe corresponder a una quincena válida (15 o fin de mes).'; end if;
 v_label := 'Quincena '||to_char(p_period_date,'DD/MM/YYYY');
 insert into public.collection_periods(period_date,label,created_by) values(p_period_date,v_label,auth.uid()) on conflict(period_date) do nothing returning id into v_period_id;
 if v_period_id is null then select id into v_period_id from public.collection_periods where period_date=p_period_date; end if;
 insert into public.collection_period_patients(period_id,patient_id,expected_amount)
 select v_period_id,p.id,greatest(0,coalesce(p.installment_amount,0)) from public.patients p
 where greatest(0,coalesce(p.total,0)-coalesce(p.paid,0))>0
 on conflict(period_id,patient_id) do nothing;
 return v_period_id;
end; $$;
revoke all on function public.generate_dental_jg_collection_period(date) from public, anon;
grant execute on function public.generate_dental_jg_collection_period(date) to authenticated;

-- EJEMPLO: después de crear el usuario de Registro en Auth, sustituye el correo por el correcto y ejecuta como administrador SQL.
-- insert into public.app_user_roles(user_id,role) select id,'registro' from auth.users where email='registro@tu-dominio.com' on conflict do nothing;
-- Repite con role='cobranza' o role='gestor' para los usuarios correspondientes.
