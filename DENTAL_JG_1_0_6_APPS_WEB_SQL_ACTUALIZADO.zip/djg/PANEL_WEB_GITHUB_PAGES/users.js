// Compatibilidad con el flujo de despliegue de GitHub Pages.
// La administración de usuarios está integrada en app.js en esta versión.
