DENTAL JG — PANEL WEB TURQUESA 1.0.6

Esta carpeta contiene el panel web y la función Edge que se usa para administrar usuarios.
No contiene secretos; config.js usa la clave pública de Supabase.

IMPORTANTE: el panel ya no registra clientes directamente en patients. El alta corresponde a Registro de Clientes.

Para publicar en GitHub Pages: copia el contenido de esta carpeta (index.html, styles.css, app.js, config.js, users.js, logo-dental-jg.png, además de los demás archivos y la carpeta supabase/) a la raíz del repositorio DENTAL-JG-ADMIN y ejecuta el workflow Publicar panel DENTAL JG.

La publicación de Pages y el despliegue de la función Edge son tareas distintas: confirma en Actions que Pages terminó correctamente y, si la función requiere cambios, que el job de Supabase también terminó.
