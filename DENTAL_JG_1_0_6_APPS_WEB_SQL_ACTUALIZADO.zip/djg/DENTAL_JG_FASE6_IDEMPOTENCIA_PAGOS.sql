-- AVISO DENTAL JG 1.0.6: SCRIPT HISTÓRICO / SUPERSEDIDO PARA LA MIGRACIÓN INTEGRADA.
-- No ejecutar después de DENTAL_JG_1_0_6_MIGRACION_SQL_INTEGRADA.sql: puede recrear
-- firmas antiguas de funciones, políticas RLS o permisos que esta versión restringe.
-- Conservar solo como referencia histórica.

-- DENTAL JG - Fase 6: idempotencia de pagos y saldo consistente.
-- Requiere desplegar las APK revisadas para que Gestor envíe client_operation_id.
-- No borra pagos ni recalcula saldos históricos al instalarse.
-- Respaldar Supabase antes de ejecutar.

BEGIN;

ALTER TABLE public.payments
  ADD COLUMN IF NOT EXISTS client_operation_id text;

-- UUID persistente generado una sola vez por cada pago local.
-- Varios NULL siguen permitidos para conservar compatibilidad con registros/APK antiguos.
CREATE UNIQUE INDEX IF NOT EXISTS payments_client_operation_id_uq
  ON public.payments (client_operation_id);

-- Actualiza el saldo solo por la diferencia real de la fila insertada/modificada/eliminada.
-- No recalcula ni sobrescribe el saldo histórico completo.
CREATE OR REPLACE FUNCTION public.dental_jg_apply_payment_balance_delta()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.patient_id IS NOT NULL THEN
      UPDATE public.patients
         SET paid = GREATEST(0, COALESCE(paid, 0) + COALESCE(NEW.amount, 0)),
             updated_at = now()
       WHERE id = NEW.patient_id;
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    IF OLD.patient_id IS NOT NULL THEN
      UPDATE public.patients
         SET paid = GREATEST(0, COALESCE(paid, 0) - COALESCE(OLD.amount, 0)),
             updated_at = now()
       WHERE id = OLD.patient_id;
    END IF;
    RETURN OLD;
  ELSE
    IF OLD.patient_id IS DISTINCT FROM NEW.patient_id THEN
      IF OLD.patient_id IS NOT NULL THEN
        UPDATE public.patients
           SET paid = GREATEST(0, COALESCE(paid, 0) - COALESCE(OLD.amount, 0)),
               updated_at = now()
         WHERE id = OLD.patient_id;
      END IF;
      IF NEW.patient_id IS NOT NULL THEN
        UPDATE public.patients
           SET paid = GREATEST(0, COALESCE(paid, 0) + COALESCE(NEW.amount, 0)),
               updated_at = now()
         WHERE id = NEW.patient_id;
      END IF;
    ELSIF OLD.amount IS DISTINCT FROM NEW.amount AND NEW.patient_id IS NOT NULL THEN
      UPDATE public.patients
         SET paid = GREATEST(0, COALESCE(paid, 0) - COALESCE(OLD.amount, 0) + COALESCE(NEW.amount, 0)),
             updated_at = now()
       WHERE id = NEW.patient_id;
    END IF;
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_dental_jg_payment_balance_delta ON public.payments;
CREATE TRIGGER trg_dental_jg_payment_balance_delta
AFTER INSERT OR UPDATE OF patient_id, amount OR DELETE
ON public.payments
FOR EACH ROW
EXECUTE FUNCTION public.dental_jg_apply_payment_balance_delta();

-- Compatibilidad con APK anteriores que llamaban esta RPC después de sincronizar.
-- El saldo ya lo mantiene el trigger; no se vuelve a sumar ni se fuerza a un máximo.
CREATE OR REPLACE FUNCTION public.sync_patient_paid(p_patient_id uuid, p_new_paid numeric)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE v_paid numeric(12,2);
BEGIN
  SELECT paid INTO v_paid
  FROM public.patients
  WHERE id = p_patient_id;

  IF v_paid IS NULL THEN
    RAISE EXCEPTION 'Paciente no encontrado o sin permisos.';
  END IF;

  RETURN jsonb_build_object('ok', true, 'paid', v_paid,
    'message', 'El saldo se mantiene mediante los movimientos de payments.');
END;
$$;

COMMIT;

-- Verificación de solo lectura:
-- SELECT column_name FROM information_schema.columns
-- WHERE table_schema='public' AND table_name='payments' AND column_name='client_operation_id';
-- SELECT indexname FROM pg_indexes WHERE schemaname='public' AND tablename='payments'
--   AND indexname='payments_client_operation_id_uq';
-- SELECT tgname FROM pg_trigger WHERE tgrelid='public.payments'::regclass AND NOT tgisinternal;
