-- DENTAL JG 1.0.6 — MIGRACIÓN SQL INTEGRADA CORREGIDA
-- ATÓMICA: si falla cualquier comprobación o cambio SQL, PostgreSQL revierte los cambios transaccionales de la migración completa.
-- Conserva el archivo inmediato de cuentas liquidadas y hace idempotentes reintentos usando el snapshot archivado.
-- Respaldar Supabase antes de ejecutar. Ejecutar TODO el archivo una sola vez en el proyecto correcto.
-- No ejecutar por fragmentos. No modifica pagos históricos ni recalcula automáticamente los saldos existentes.
-- Nota: la secuencia de folios puede avanzar aunque la transacción se revierta; esto solo puede dejar saltos de folio, nunca duplicarlos.

BEGIN;

-- DENTAL JG 1.0.6 — MIGRACIÓN SQL INTEGRADA
-- Respaldar Supabase. Ejecutar el archivo completo una sola vez en el proyecto correcto.
-- Endurece RLS y fuerza el alta de pacientes por la RPC protegida, únicamente para el rol registro. El panel Admon no debe insertar pacientes directamente.

-- Preflight: si el esquema no corresponde a DENTAL JG, detenerse antes de modificar datos.
DO $$
DECLARE v_missing text;
BEGIN
  WITH required(table_name,column_name) AS (VALUES
    ('payments','id'),('payments','patient_id'),('payments','amount'),('payments','patient_name'),('payments','concept'),('payments','reference'),('payments','paid_at'),('payments','source_device'),
    ('patients','id'),('patients','name'),('patients','first_names'),('patients','surnames'),('patients','holder_name'),('patients','address'),('patients','phone'),('patients','phone2'),('patients','observations'),('patients','treatment'),('patients','total'),('patients','paid'),('patients','installments'),('patients','installment_amount'),('patients','assigned_manager_id'),('patients','policy_number'),('patients','policy_type'),('patients','clinic'),('patients','source_device'),('patients','created_at'),('patients','updated_at'),('patients','payment_mode'),('patients','tabulator'),('patients','first_payment_date'),('patients','payment_method'),('patients','folio'),
    ('collection_managers','id'),('collection_managers','created_by'),('collection_managers','full_name'),('collection_managers','phone'),('collection_managers','active'),('collection_managers','manager_key'),('collection_managers','created_at'),('collection_managers','updated_at'),
    ('collection_portfolios','id'),('collection_portfolios','created_by'),('collection_portfolios','clinic_name'),('collection_portfolios','name'),('collection_portfolios','manager_id'),('collection_portfolios','updated_at'),
    ('collection_portfolio_patients','id'),('collection_portfolio_patients','created_by'),('collection_portfolio_patients','portfolio_id'),('collection_portfolio_patients','patient_id'),
    ('collection_receipts','id'),('collection_receipts','created_by'),('collection_receipts','folio'),('collection_receipts','payment_id'),('collection_receipts','patient_id'),('collection_receipts','manager_id'),('collection_receipts','scheduled_for'),('collection_receipts','patient_name'),('collection_receipts','clinic'),('collection_receipts','payment_amount'),('collection_receipts','previous_balance'),('collection_receipts','tabulator'),('collection_receipts','net_amount'),('collection_receipts','new_balance'),('collection_receipts','concept'),('collection_receipts','notes'),('collection_receipts','receipt_snapshot'),
    ('collection_receipt_settings','user_id'),('collection_receipt_settings','folio_prefix'),('collection_receipt_settings','next_folio'),('collection_receipt_settings','folio_digits'),('collection_receipt_settings','updated_at'),
    ('app_user_roles','user_id'),('app_user_roles','role'),('clinics','id'),('clinics','name')
  )
  SELECT string_agg(r.table_name||'.'||r.column_name, ', ' ORDER BY r.table_name,r.column_name)
    INTO v_missing
  FROM required r
  WHERE NOT EXISTS (
    SELECT 1 FROM information_schema.columns c
    WHERE c.table_schema='public' AND c.table_name=r.table_name AND c.column_name=r.column_name
  );
  IF v_missing IS NOT NULL THEN
    RAISE EXCEPTION 'DENTAL JG 1.0.6: esquema incompatible; faltan columnas: %. No se aplicó ninguna modificación de este preflight.', v_missing;
  END IF;

  -- No crear índices únicos destruyendo la ejecución en una fase tardía:
  -- comprobar primero si ya existen recibos duplicados para un mismo pago o programación.
  IF EXISTS (
    SELECT 1 FROM public.collection_receipts
    WHERE payment_id IS NOT NULL
    GROUP BY payment_id HAVING count(*) > 1
  ) THEN
    RAISE EXCEPTION 'DENTAL JG: hay pagos con más de un recibo asociado. Concilia esos duplicados antes de aplicar la migración; no se modificó el esquema.';
  END IF;
  IF EXISTS (
    SELECT 1 FROM public.collection_receipts
    WHERE payment_id IS NULL AND scheduled_for IS NOT NULL AND patient_id IS NOT NULL
    GROUP BY created_by, patient_id, scheduled_for HAVING count(*) > 1
  ) THEN
    RAISE EXCEPTION 'DENTAL JG: hay recibos programados duplicados para la misma cuenta, cliente y fecha. Concilia esos duplicados antes de aplicar la migración; no se modificó el esquema.';
  END IF;
END;
$$;

-- Compatibilidad con el archivo inmediato actualmente instalado.
-- El trigger auto-archive está diseñado para archivar y retirar de las tablas activas
-- al cliente cuando el pago liquida la cuenta; se conserva ese comportamiento.
-- Se comprueba que su función de archivo y la tabla de archivo existan antes de seguir.
DO $$
DECLARE v_trigger text; v_function text;
BEGIN
  SELECT t.tgname, p.proname INTO v_trigger, v_function
  FROM pg_trigger t JOIN pg_proc p ON p.oid=t.tgfoid
  WHERE t.tgrelid='public.patients'::regclass AND NOT t.tgisinternal
    AND (t.tgname ILIKE '%auto_archive%settled%' OR p.proname ILIKE '%auto_archive%settled%')
  LIMIT 1;
  IF v_trigger IS NOT NULL AND (
    to_regclass('public.patient_account_archive') IS NULL OR
    to_regprocedure('public.archive_dental_jg_settled_patient(uuid,numeric)') IS NULL
  ) THEN
    RAISE EXCEPTION 'DENTAL JG: existe el trigger % (función %), pero falta la tabla o función de archivo que necesita. Corrige el subsistema de archivo antes de continuar; no se aplicó la migración.', v_trigger, v_function;
  END IF;
END;
$$;

-- DENTAL JG - Fase 6: idempotencia de pagos y saldo consistente.
-- Requiere desplegar las APK revisadas para que Gestor envíe client_operation_id.
-- No borra pagos ni recalcula saldos históricos al instalarse.
-- Respaldar Supabase antes de ejecutar.


ALTER TABLE public.payments
  ADD COLUMN IF NOT EXISTS client_operation_id text;

-- Normaliza identificadores vacíos antiguos a NULL; no elimina pagos.
UPDATE public.payments SET client_operation_id = NULL
WHERE client_operation_id IS NOT NULL AND btrim(client_operation_id) = '';

DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM public.payments WHERE client_operation_id IS NOT NULL
             GROUP BY client_operation_id HAVING count(*) > 1) THEN
    RAISE EXCEPTION 'Hay client_operation_id duplicados existentes en payments. No se creó el índice; concilia esos identificadores antes de continuar.';
  END IF;
END; $$;

-- UUID persistente generado una sola vez por cada pago local.
-- Varios NULL siguen permitidos para conservar compatibilidad con registros/APK antiguos.
CREATE UNIQUE INDEX IF NOT EXISTS payments_client_operation_id_uq
  ON public.payments (client_operation_id);

-- Actualiza el saldo solo por la diferencia real de la fila insertada/modificada/eliminada.
-- No recalcula ni sobrescribe el saldo histórico completo.
CREATE OR REPLACE FUNCTION public.dental_jg_apply_payment_balance_delta()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  -- La RPC de Gestor difiere el ajuste de saldo hasta que termina el INSERT de payments.
  -- Así el archivo inmediato puede retirar ese pago después sin borrar la fila durante su propio INSERT.
  IF TG_OP = 'INSERT' AND COALESCE(current_setting('dental_jg.skip_payment_balance_trigger', true),'0') = '1' THEN
    RETURN NEW;
  END IF;
  IF TG_OP = 'INSERT' THEN
    IF NEW.patient_id IS NOT NULL THEN
      UPDATE public.patients
         SET paid = GREATEST(0, COALESCE(paid, 0) + COALESCE(NEW.amount, 0)),
             updated_at = now()
       WHERE id = NEW.patient_id;
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    IF OLD.patient_id IS NOT NULL THEN
      UPDATE public.patients
         SET paid = GREATEST(0, COALESCE(paid, 0) - COALESCE(OLD.amount, 0)),
             updated_at = now()
       WHERE id = OLD.patient_id;
    END IF;
    RETURN OLD;
  ELSE
    IF OLD.patient_id IS DISTINCT FROM NEW.patient_id THEN
      IF OLD.patient_id IS NOT NULL THEN
        UPDATE public.patients
           SET paid = GREATEST(0, COALESCE(paid, 0) - COALESCE(OLD.amount, 0)),
               updated_at = now()
         WHERE id = OLD.patient_id;
      END IF;
      IF NEW.patient_id IS NOT NULL THEN
        UPDATE public.patients
           SET paid = GREATEST(0, COALESCE(paid, 0) + COALESCE(NEW.amount, 0)),
               updated_at = now()
         WHERE id = NEW.patient_id;
      END IF;
    ELSIF OLD.amount IS DISTINCT FROM NEW.amount AND NEW.patient_id IS NOT NULL THEN
      UPDATE public.patients
         SET paid = GREATEST(0, COALESCE(paid, 0) - COALESCE(OLD.amount, 0) + COALESCE(NEW.amount, 0)),
             updated_at = now()
       WHERE id = NEW.patient_id;
    END IF;
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_dental_jg_payment_balance_delta ON public.payments;
CREATE TRIGGER trg_dental_jg_payment_balance_delta
AFTER INSERT OR UPDATE OF patient_id, amount OR DELETE
ON public.payments
FOR EACH ROW
EXECUTE FUNCTION public.dental_jg_apply_payment_balance_delta();

-- Compatibilidad con APK anteriores que llamaban esta RPC después de sincronizar.
-- El saldo ya lo mantiene el trigger; no se vuelve a sumar ni se fuerza a un máximo.
CREATE OR REPLACE FUNCTION public.sync_patient_paid(p_patient_id uuid, p_new_paid numeric)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = pg_catalog, public
AS $$
DECLARE v_paid numeric(12,2);
BEGIN
  SELECT paid INTO v_paid
  FROM public.patients
  WHERE id = p_patient_id;

  IF v_paid IS NULL THEN
    RAISE EXCEPTION 'Paciente no encontrado o sin permisos.';
  END IF;

  RETURN jsonb_build_object('ok', true, 'paid', v_paid,
    'message', 'El saldo se mantiene mediante los movimientos de payments.');
END;
$$;


-- Verificación de solo lectura:
-- SELECT column_name FROM information_schema.columns
-- WHERE table_schema='public' AND table_name='payments' AND column_name='client_operation_id';
-- SELECT indexname FROM pg_indexes WHERE schemaname='public' AND tablename='payments'
--   AND indexname='payments_client_operation_id_uq';
-- SELECT tgname FROM pg_trigger WHERE tgrelid='public.payments'::regclass AND NOT tgisinternal;


-- DENTAL JG - Fase 7: guardar Tratamiento y Observaciones en sus campos correctos.
-- Migración aditiva: no modifica pacientes existentes, pagos ni saldos.
-- Ejecutar en Supabase después de respaldar y antes de usar la APK/web de Registro corregida.

-- Retira las firmas antiguas que permitían registrar pacientes con menos controles
-- (incluidas versiones que aceptaban admin o no exigían gestor). La app Registro actual
-- usa la firma de 20 argumentos incluida abajo; actualiza Registro antes de aplicar.
DROP FUNCTION IF EXISTS public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text);
DROP FUNCTION IF EXISTS public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text);
DROP FUNCTION IF EXISTS public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,text,text,numeric,date);
DROP FUNCTION IF EXISTS public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,text,text,numeric,date,text);

CREATE SEQUENCE IF NOT EXISTS public.dental_jg_patient_folio_seq;
DO $$
DECLARE v_max bigint; v_last bigint; v_called boolean;
BEGIN
  SELECT max((substring(folio from '[0-9]+$'))::bigint) INTO v_max
  FROM public.patients WHERE folio ~ '[0-9]+$';
  IF coalesce(v_max, 0) > 0 THEN
    SELECT last_value, is_called INTO v_last, v_called FROM public.dental_jg_patient_folio_seq;
    IF NOT v_called OR v_last < v_max THEN PERFORM setval('public.dental_jg_patient_folio_seq', v_max, true); END IF;
  END IF;
END; $$;


CREATE OR REPLACE FUNCTION public.register_dental_jg_patient(
 p_name text, p_phone text, p_treatment text, p_total numeric,
 p_installments integer, p_installment_amount numeric, p_policy_number text, p_clinic text,
 p_first_names text, p_surnames text, p_address text, p_phone2 text, p_observations text,
 p_holder_name text, p_payment_mode text, p_tabulator numeric, p_first_payment_date date,
 p_payment_method text DEFAULT 'efectivo', p_policy_type text DEFAULT NULL,
 p_assigned_manager_id uuid DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  new_id uuid;
  new_folio text;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Inicia sesión para registrar clientes.';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.app_user_roles
    WHERE user_id = auth.uid() AND lower(role) = 'registro'
  ) THEN
    RAISE EXCEPTION 'Esta cuenta no tiene permiso para registrar clientes.';
  END IF;

  IF length(trim(coalesce(p_holder_name, ''))) = 0
     OR length(trim(coalesce(p_first_names, p_name, ''))) = 0
     OR length(trim(coalesce(p_surnames, ''))) = 0
     OR length(trim(coalesce(p_clinic, ''))) = 0
     OR length(trim(coalesce(p_policy_number, ''))) = 0
     OR length(trim(coalesce(p_address, ''))) = 0
     OR length(trim(coalesce(p_phone, ''))) = 0 THEN
    RAISE EXCEPTION 'Completa todos los campos obligatorios.';
  END IF;

  IF coalesce(p_treatment, '') NOT IN ('Básico', 'Basic', 'Orto', 'VIP', 'Damon') THEN
    RAISE EXCEPTION 'Selecciona un tratamiento válido.';
  END IF;

  IF p_assigned_manager_id IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.collection_managers
    WHERE id = p_assigned_manager_id AND coalesce(active, true)
  ) THEN
    RAISE EXCEPTION 'Selecciona un gestor activo.';
  END IF;

  IF coalesce(p_payment_mode, '') NOT IN ('quincenal', 'mensual') THEN
    RAISE EXCEPTION 'Selecciona periodicidad quincenal o mensual.';
  END IF;
  IF coalesce(p_payment_method, '') NOT IN ('efectivo', 'transferencia') THEN
    RAISE EXCEPTION 'Selecciona forma de pago efectivo o transferencia.';
  END IF;
  IF coalesce(p_total, 0) <= 0 OR coalesce(p_installments, 0) < 1
     OR coalesce(p_installment_amount, 0) <= 0 OR coalesce(p_tabulator, 0) < 0
     OR p_first_payment_date IS NULL THEN
    RAISE EXCEPTION 'Verifica monto total, cantidad por pago, número de pagos, tabulador y fecha del primer pago.';
  END IF;

  new_folio := 'JG-' || lpad(nextval('public.dental_jg_patient_folio_seq')::text, 6, '0');

  INSERT INTO public.patients(
    folio, holder_name, first_names, surnames, address, phone2, observations,
    name, phone, treatment, total, paid, installments, installment_amount,
    policy_number, policy_type, assigned_manager_id, clinic, source_device,
    created_at, updated_at, payment_mode, tabulator, first_payment_date, payment_method
  ) VALUES (
    new_folio, trim(p_holder_name), trim(coalesce(p_first_names, p_name)),
    trim(coalesce(p_surnames, '')), trim(coalesce(p_address, '')),
    trim(coalesce(p_phone2, '')), trim(coalesce(p_observations, '')),
    trim(p_name), trim(p_phone), trim(p_treatment), p_total, 0,
    p_installments, p_installment_amount, trim(p_policy_number),
    nullif(trim(coalesce(p_policy_type, '')), ''), p_assigned_manager_id,
    trim(p_clinic), 'DENTAL JG Registro', now(), now(), p_payment_mode,
    p_tabulator, p_first_payment_date, p_payment_method
  ) RETURNING id INTO new_id;

  RETURN new_id;
END;
$$;

REVOKE ALL ON FUNCTION public.register_dental_jg_patient(
 text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,
 text,text,numeric,date,text,text,uuid
) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.register_dental_jg_patient(
 text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,
 text,text,numeric,date,text,text,uuid
) TO authenticated;



-- DENTAL JG - Fase 8: una cartera por clínica y gestor asignado.
-- No elimina pacientes, pagos, recibos ni reportes históricos.
-- Respaldar Supabase antes de ejecutar.


ALTER TABLE public.collection_portfolios
  ADD COLUMN IF NOT EXISTS manager_id uuid;

-- La clave anterior solo permitía una cartera por clínica y no separaba gestores.
ALTER TABLE public.collection_portfolios
  DROP CONSTRAINT IF EXISTS collection_portfolios_created_by_clinic_name_key;
DROP INDEX IF EXISTS public.collection_portfolios_created_by_clinic_name_key;

CREATE UNIQUE INDEX IF NOT EXISTS collection_portfolios_created_clinic_manager_uq
  ON public.collection_portfolios (created_by, clinic_name, manager_id);
CREATE INDEX IF NOT EXISTS collection_portfolios_manager_idx
  ON public.collection_portfolios (manager_id);

-- Reparte las asignaciones existentes según el gestor realmente guardado en cada paciente.
-- No asigna pacientes sin assigned_manager_id ni sobrescribe un gestor existente.
DO $$
DECLARE
  old_portfolio record;
  grp record;
  new_portfolio_id uuid;
  manager_name text;
BEGIN
  FOR old_portfolio IN
    SELECT p.id, p.created_by, p.clinic_name
    FROM public.collection_portfolios p
    WHERE p.manager_id IS NULL
  LOOP
    FOR grp IN
      SELECT DISTINCT pt.assigned_manager_id AS manager_id
      FROM public.collection_portfolio_patients cpp
      JOIN public.patients pt ON pt.id = cpp.patient_id
      WHERE cpp.portfolio_id = old_portfolio.id
        AND pt.assigned_manager_id IS NOT NULL
    LOOP
      SELECT cm.full_name INTO manager_name
      FROM public.collection_managers cm
      WHERE cm.id = grp.manager_id AND cm.active IS DISTINCT FROM false;

      IF manager_name IS NULL THEN
        CONTINUE;
      END IF;

      INSERT INTO public.collection_portfolios(created_by, clinic_name, name, manager_id, updated_at)
      VALUES (old_portfolio.created_by, old_portfolio.clinic_name,
              'Cartera - ' || old_portfolio.clinic_name || ' - ' || manager_name,
              grp.manager_id, now())
      ON CONFLICT (created_by, clinic_name, manager_id)
      DO UPDATE SET name = EXCLUDED.name, updated_at = now()
      RETURNING id INTO new_portfolio_id;

      INSERT INTO public.collection_portfolio_patients(created_by, portfolio_id, patient_id)
      SELECT cpp.created_by, new_portfolio_id, cpp.patient_id
      FROM public.collection_portfolio_patients cpp
      JOIN public.patients pt ON pt.id = cpp.patient_id
      WHERE cpp.portfolio_id = old_portfolio.id
        AND pt.assigned_manager_id = grp.manager_id
      ON CONFLICT (portfolio_id, patient_id) DO NOTHING;

      DELETE FROM public.collection_portfolio_patients cpp
      USING public.patients pt
      WHERE cpp.portfolio_id = old_portfolio.id
        AND pt.id = cpp.patient_id
        AND pt.assigned_manager_id = grp.manager_id;
    END LOOP;
  END LOOP;
END;
$$;


-- Verificación de solo lectura:
-- SELECT clinic_name, manager_id, count(*)
-- FROM public.collection_portfolios GROUP BY clinic_name, manager_id ORDER BY clinic_name;
-- SELECT count(*) AS pacientes_sin_gestor FROM public.patients WHERE assigned_manager_id IS NULL;

-- Fase 9: una sola fila de recibo real por pago, incluso si lo intentan dos cuentas.
-- No elimina recibos. Si ya existen recibos duplicados para un mismo pago, se detiene
-- con un error para que se concilien manualmente en lugar de borrar datos a ciegas.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM public.collection_receipts
    WHERE payment_id IS NOT NULL
    GROUP BY payment_id
    HAVING count(*) > 1
  ) THEN
    RAISE EXCEPTION 'Hay pagos con más de un recibo asociado. No se creó el índice; concilia primero los duplicados sin borrar el historial.';
  END IF;
END;
$$;

CREATE UNIQUE INDEX IF NOT EXISTS collection_receipts_payment_unique
  ON public.collection_receipts (payment_id)
  WHERE payment_id IS NOT NULL;


-- DENTAL JG - Fase 10: acceso por roles y sincronización Gestor por RPC.
-- Elimina políticas permisivas conocidas en pacientes/pagos/clínicas/gestores.
-- Gestor solo puede consultar y registrar movimientos del gestor validado por clave.

CREATE OR REPLACE FUNCTION public.dental_jg_manager_by_key(p_manager_key text)
RETURNS TABLE(id uuid, full_name text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog, public AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para validar al gestor.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('gestor','admin')) THEN RAISE EXCEPTION 'Esta cuenta no tiene permiso para usar la sincronización de Gestor.'; END IF;
  IF length(trim(coalesce(p_manager_key,''))) < 4 THEN RAISE EXCEPTION 'Clave de gestor no válida.'; END IF;
  RETURN QUERY SELECT m.id,m.full_name FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false AND m.manager_key=trim(p_manager_key) LIMIT 1;
END; $$;

CREATE OR REPLACE FUNCTION public.dental_jg_manager_patients(p_manager_key text)
RETURNS SETOF jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog, public AS $$
DECLARE v_manager uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para sincronizar pacientes.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('gestor','admin')) THEN RAISE EXCEPTION 'Esta cuenta no tiene permiso para usar la sincronización de Gestor.'; END IF;
  SELECT m.id INTO v_manager FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false AND m.manager_key=trim(coalesce(p_manager_key,''))
    AND length(trim(coalesce(p_manager_key,''))) >= 4 LIMIT 1;
  IF v_manager IS NULL THEN RAISE EXCEPTION 'Clave de gestor incorrecta o gestor inactivo.'; END IF;
  RETURN QUERY SELECT to_jsonb(p) FROM public.patients p
  WHERE p.assigned_manager_id=v_manager ORDER BY p.created_at DESC;
END; $$;

CREATE OR REPLACE FUNCTION public.dental_jg_manager_payments(p_manager_key text)
RETURNS SETOF jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog, public AS $$
DECLARE v_manager uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para sincronizar pagos.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('gestor','admin')) THEN RAISE EXCEPTION 'Esta cuenta no tiene permiso para usar la sincronización de Gestor.'; END IF;
  SELECT m.id INTO v_manager FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false AND m.manager_key=trim(coalesce(p_manager_key,''))
    AND length(trim(coalesce(p_manager_key,''))) >= 4 LIMIT 1;
  IF v_manager IS NULL THEN RAISE EXCEPTION 'Clave de gestor incorrecta o gestor inactivo.'; END IF;
  RETURN QUERY SELECT to_jsonb(py) FROM public.payments py
  JOIN public.patients pt ON pt.id=py.patient_id
  WHERE pt.assigned_manager_id=v_manager ORDER BY py.paid_at DESC;
END; $$;

CREATE OR REPLACE FUNCTION public.dental_jg_manager_insert_payment(p_manager_key text,p_payment jsonb)
RETURNS SETOF jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog, public AS $$
DECLARE
  v_manager uuid;
  v_patient public.patients;
  v_payment public.payments;
  v_operation_id text;
  v_amount numeric;
  v_requested_patient uuid;
  v_archived_patient_id uuid;
  v_archived_manager_id uuid;
  v_archived_payment jsonb;
  v_assigned_manager_id uuid;
  v_existing_payment boolean := false;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para registrar pagos.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('gestor','admin')) THEN
    RAISE EXCEPTION 'Esta cuenta no tiene permiso para usar la sincronización de Gestor.';
  END IF;
  SELECT m.id INTO v_manager FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false AND m.manager_key=trim(coalesce(p_manager_key,''))
    AND length(trim(coalesce(p_manager_key,''))) >= 4 LIMIT 1;
  IF v_manager IS NULL THEN RAISE EXCEPTION 'Clave de gestor incorrecta o gestor inactivo.'; END IF;

  v_operation_id:=trim(coalesce(p_payment->>'client_operation_id',''));
  IF v_operation_id='' THEN RAISE EXCEPTION 'El pago no incluye identificador único. Actualiza la aplicación Gestor.'; END IF;
  v_amount:=(p_payment->>'amount')::numeric;
  IF v_amount IS NULL OR v_amount<=0 OR v_amount>9999999999.99 THEN
    RAISE EXCEPTION 'El importe debe ser mayor que cero y estar dentro del límite permitido.';
  END IF;
  v_requested_patient:=nullif(trim(coalesce(p_payment->>'patient_id','')),'')::uuid;
  IF v_requested_patient IS NULL THEN RAISE EXCEPTION 'El pago no incluye un cliente válido.'; END IF;

  -- Serializa reintentos del mismo pago antes de buscar al paciente: la última cuota puede
  -- haber activado el archivo inmediato y retirado ya al cliente de patients.
  PERFORM pg_advisory_xact_lock(hashtext('dentaljg-payment-operation:'||v_operation_id));
  SELECT * INTO v_payment FROM public.payments WHERE client_operation_id=v_operation_id LIMIT 1;
  v_existing_payment:=FOUND;
  IF v_existing_payment THEN
    IF (v_payment.patient_id IS NOT NULL AND v_payment.patient_id IS DISTINCT FROM v_requested_patient)
       OR round(v_payment.amount::numeric,2) IS DISTINCT FROM round(v_amount,2) THEN
      RAISE EXCEPTION 'El identificador de operación ya existe con datos diferentes. No se registró otro pago.';
    END IF;
  END IF;

  -- Si el pago liquidó la cuenta, el trigger de archivo conserva el pago dentro de
  -- patient_account_archive.archive_data y elimina la fila operativa de payments.
  -- Se consulta ese snapshot para que un reintento offline siga siendo idempotente.
  IF to_regclass('public.patient_account_archive') IS NOT NULL THEN
    EXECUTE $archive_query$
      SELECT a.original_patient_id,
             NULLIF(a.archive_data->'patient'->>'assigned_manager_id','')::uuid,
             e.value
      FROM public.patient_account_archive a
      CROSS JOIN LATERAL jsonb_array_elements(COALESCE(a.archive_data->'payments','[]'::jsonb)) AS e(value)
      WHERE e.value->>'client_operation_id'=$1
      ORDER BY a.archived_at DESC
      LIMIT 1
    $archive_query$
    INTO v_archived_patient_id, v_archived_manager_id, v_archived_payment
    USING v_operation_id;
  END IF;

  IF v_archived_payment IS NOT NULL THEN
    IF v_archived_patient_id IS DISTINCT FROM v_requested_patient
       OR v_archived_manager_id IS DISTINCT FROM v_manager
       OR round((v_archived_payment->>'amount')::numeric,2) IS DISTINCT FROM round(v_amount,2) THEN
      RAISE EXCEPTION 'El identificador de operación ya existe en el archivo con datos diferentes o pertenece a otro gestor.';
    END IF;
    IF v_existing_payment THEN
      RETURN NEXT to_jsonb(v_payment);
    ELSE
      RETURN NEXT v_archived_payment;
    END IF;
    RETURN;
  END IF;

  IF v_existing_payment THEN
    SELECT p.assigned_manager_id INTO v_assigned_manager_id
    FROM public.patients p WHERE p.id=v_requested_patient;
    IF v_assigned_manager_id IS DISTINCT FROM v_manager THEN
      RAISE EXCEPTION 'El identificador de operación existe, pero no se pudo validar la cuenta activa o su expediente archivado.';
    END IF;
    RETURN NEXT to_jsonb(v_payment);
    RETURN;
  END IF;

  SELECT p.* INTO v_patient FROM public.patients p
  WHERE p.id=v_requested_patient AND p.assigned_manager_id=v_manager
  FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'El paciente no pertenece a este gestor o ya fue archivado.'; END IF;
  IF v_amount > GREATEST(COALESCE(v_patient.total,0)-COALESCE(v_patient.paid,0),0) + 0.009 THEN
    RAISE EXCEPTION 'El pago supera el saldo pendiente actual. Sincroniza el paciente y revisa el historial antes de reintentar.';
  END IF;

  -- Primero guarda el movimiento; el trigger de payments omite solo este INSERT.
  -- El INSERT ya concluyó cuando se actualiza el saldo, de modo que el archivo inmediato
  -- puede copiar y retirar el pago sin interferir con la sentencia que lo creó.
  PERFORM set_config('dental_jg.skip_payment_balance_trigger','1',true);
  INSERT INTO public.payments(patient_id,patient_name,amount,concept,reference,paid_at,source_device,client_operation_id)
  VALUES(v_patient.id,
    coalesce(nullif(trim(concat_ws(' ',nullif(v_patient.first_names,''),nullif(v_patient.surnames,''))),''),v_patient.name),
    v_amount,coalesce(nullif(trim(p_payment->>'concept'),''),'Abono'),coalesce(p_payment->>'reference',''),
    coalesce(nullif(p_payment->>'paid_at','')::timestamptz,now()),
    coalesce(nullif(p_payment->>'source_device',''),'DENTAL JG APK'),v_operation_id)
  RETURNING * INTO v_payment;
  PERFORM set_config('dental_jg.skip_payment_balance_trigger','0',true);
  UPDATE public.patients
     SET paid=GREATEST(0,COALESCE(paid,0)+v_amount), updated_at=now()
   WHERE id=v_patient.id;
  RETURN NEXT to_jsonb(v_payment);
END; $$;

REVOKE ALL ON FUNCTION public.dental_jg_manager_by_key(text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.dental_jg_manager_patients(text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.dental_jg_manager_payments(text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.dental_jg_manager_insert_payment(text,jsonb) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_by_key(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_patients(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_payments(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_insert_payment(text,jsonb) TO authenticated;

DO $$ DECLARE pol record; BEGIN
  FOR pol IN SELECT tablename,policyname FROM pg_policies WHERE schemaname='public'
    AND tablename IN ('patients','payments','clinics','collection_managers') LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I',pol.policyname,pol.tablename);
  END LOOP;
END; $$;

ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clinics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.collection_managers ENABLE ROW LEVEL SECURITY;

CREATE POLICY dental_jg_staff_read_patients ON public.patients FOR SELECT TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','registro','cobranza')));
CREATE POLICY dental_jg_staff_update_patients ON public.patients FOR UPDATE TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza'))) WITH CHECK (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza')));
CREATE POLICY dental_jg_staff_delete_patients ON public.patients FOR DELETE TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin'));
REVOKE ALL ON public.patients FROM PUBLIC,anon,authenticated;
GRANT SELECT,UPDATE,DELETE ON public.patients TO authenticated;

-- RPC de eliminación permanente: reservada al administrador y transaccional.
CREATE OR REPLACE FUNCTION public.delete_patient_permanently(p_patient_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  p public.patients%rowtype;
  v_payments integer := 0;
  v_receipts integer := 0;
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.app_user_roles r
    WHERE r.user_id=auth.uid() AND lower(r.role)='admin'
  ) THEN
    RAISE EXCEPTION 'Solo un administrador puede eliminar definitivamente clientes.';
  END IF;
  SELECT * INTO p FROM public.patients WHERE id=p_patient_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'No se encontró el cliente.'; END IF;

  DELETE FROM public.collection_portfolio_patients WHERE patient_id=p.id;
  IF to_regclass('public.collection_period_patients') IS NOT NULL THEN
    EXECUTE 'DELETE FROM public.collection_period_patients WHERE patient_id=$1' USING p.id;
  END IF;
  DELETE FROM public.collection_receipts WHERE patient_id=p.id;
  GET DIAGNOSTICS v_receipts = ROW_COUNT;
  DELETE FROM public.payments WHERE patient_id=p.id;
  GET DIAGNOSTICS v_payments = ROW_COUNT;
  DELETE FROM public.patients WHERE id=p.id;
  RETURN jsonb_build_object('success',true,'patient_id',p.id,
    'payments_deleted',v_payments,'receipts_deleted',v_receipts);
END;
$$;
REVOKE ALL ON FUNCTION public.delete_patient_permanently(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.delete_patient_permanently(uuid) TO authenticated;

CREATE POLICY dental_jg_staff_read_payments ON public.payments FOR SELECT TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza')));
REVOKE ALL ON public.payments FROM PUBLIC,anon,authenticated;
GRANT SELECT ON public.payments TO authenticated;

CREATE POLICY dental_jg_authenticated_read_clinics ON public.clinics FOR SELECT TO authenticated USING (true);
CREATE POLICY dental_jg_admin_manage_clinics ON public.clinics FOR ALL TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin')) WITH CHECK (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin'));
REVOKE ALL ON public.clinics FROM PUBLIC,anon,authenticated;
GRANT SELECT,INSERT,UPDATE,DELETE ON public.clinics TO authenticated;

REVOKE ALL ON public.collection_managers FROM PUBLIC,anon,authenticated;
REVOKE SELECT(manager_key) ON public.collection_managers FROM PUBLIC,anon,authenticated;
GRANT SELECT(id,created_by,full_name,phone,active,created_at,updated_at) ON public.collection_managers TO authenticated;
GRANT INSERT(created_by,full_name,phone,manager_key) ON public.collection_managers TO authenticated;
GRANT UPDATE(full_name,phone,manager_key,active,updated_at) ON public.collection_managers TO authenticated;
GRANT DELETE ON public.collection_managers TO authenticated;
CREATE POLICY dental_jg_staff_read_managers ON public.collection_managers FOR SELECT TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','registro','cobranza')));
CREATE POLICY dental_jg_admin_manage_managers ON public.collection_managers FOR ALL TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin')) WITH CHECK (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin'));

-- Reportes quincenales usados por Cobranza y consultados por Administración.
CREATE TABLE IF NOT EXISTS public.collection_quincena_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_by uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  quincena_date date NOT NULL,
  manager_id uuid NOT NULL REFERENCES public.collection_managers(id) ON DELETE RESTRICT,
  manager_name text NOT NULL DEFAULT '',
  report_rows jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(created_by,quincena_date,manager_id)
);
ALTER TABLE public.collection_quincena_reports ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.collection_quincena_reports FROM PUBLIC, anon, authenticated;
GRANT SELECT,INSERT,UPDATE,DELETE ON public.collection_quincena_reports TO authenticated;
DO $$ DECLARE pol record; BEGIN
  FOR pol IN SELECT policyname FROM pg_policies
    WHERE schemaname='public' AND tablename='collection_quincena_reports'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.collection_quincena_reports',pol.policyname);
  END LOOP;
END; $$;
CREATE POLICY dental_jg_quincena_reports_role_access ON public.collection_quincena_reports
FOR ALL TO authenticated
USING (created_by=auth.uid() OR EXISTS(SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin'))
WITH CHECK ((created_by=auth.uid() AND EXISTS(SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza','gestor'))) OR EXISTS(SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin'));
CREATE INDEX IF NOT EXISTS collection_quincena_reports_date_idx ON public.collection_quincena_reports(quincena_date DESC);
CREATE INDEX IF NOT EXISTS collection_quincena_reports_manager_idx ON public.collection_quincena_reports(manager_id,quincena_date DESC);

-- Acceso controlado a recibos: lectura para Administración/Cobranza, edición propia,
-- y altas exclusivamente mediante RPCs validadas (no INSERT directo desde el cliente).
ALTER TABLE public.collection_receipts ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.collection_receipts FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.collection_receipts TO authenticated;
DO $$ DECLARE pol record; BEGIN
  FOR pol IN SELECT policyname FROM pg_policies
    WHERE schemaname='public' AND tablename='collection_receipts'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.collection_receipts',pol.policyname);
  END LOOP;
END; $$;
CREATE POLICY dental_jg_receipts_read_role ON public.collection_receipts FOR SELECT TO authenticated
USING (EXISTS(SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza')));
-- No hay UPDATE directo desde el cliente: la edición pasa por una RPC validada más abajo.
CREATE UNIQUE INDEX IF NOT EXISTS collection_receipts_payment_id_uq
  ON public.collection_receipts(payment_id) WHERE payment_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS collection_receipts_scheduled_patient_date_uq
  ON public.collection_receipts(created_by,patient_id,scheduled_for)
  WHERE payment_id IS NULL AND scheduled_for IS NOT NULL;

-- Los ajustes del folio pertenecen a cada cuenta; el RPC corre con permisos de propietario.
ALTER TABLE public.collection_receipt_settings ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.collection_receipt_settings FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON public.collection_receipt_settings TO authenticated;
DO $$ DECLARE pol record; BEGIN
  FOR pol IN SELECT policyname FROM pg_policies
    WHERE schemaname='public' AND tablename='collection_receipt_settings'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.collection_receipt_settings',pol.policyname);
  END LOOP;
END; $$;
CREATE POLICY dental_jg_receipt_settings_own ON public.collection_receipt_settings FOR ALL TO authenticated
USING (user_id=auth.uid()) WITH CHECK (user_id=auth.uid());

-- Fase 11: validar recibos contra el paciente/pago real y aceptar gestores compartidos.
-- Elimina la firma antigua de 11 argumentos que no imponía el nuevo control de rol.
-- Cobranza actualizado llama la versión de 12 argumentos que sigue a este bloque.
DROP FUNCTION IF EXISTS public.create_collection_receipt(uuid,uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb);

-- Corrige el rechazo de gestores creados por Administración pero seleccionados en Cobranza.
CREATE OR REPLACE FUNCTION public.create_collection_receipt(
  p_payment_id uuid,
  p_patient_id uuid,
  p_patient_name text,
  p_clinic text,
  p_payment_amount numeric,
  p_previous_balance numeric,
  p_tabulator numeric,
  p_new_balance numeric,
  p_concept text,
  p_notes text,
  p_snapshot jsonb,
  p_manager_id uuid DEFAULT NULL::uuid
) RETURNS public.collection_receipts
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  s public.collection_receipt_settings;
  r public.collection_receipts;
  v_folio text;
  v_payment_patient uuid;
  v_payment_amount numeric;
  v_canonical_patient_name text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para generar recibos.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles ar WHERE ar.user_id=auth.uid() AND lower(ar.role) IN ('admin','cobranza')) THEN
    RAISE EXCEPTION 'Esta cuenta no tiene permiso para generar recibos.';
  END IF;
  IF p_payment_amount IS NULL OR p_payment_amount <= 0 OR p_payment_amount > 9999999999.99 THEN
    RAISE EXCEPTION 'El importe debe ser mayor que cero y estar dentro del límite permitido.';
  END IF;
  IF COALESCE(p_previous_balance,0) < 0 OR COALESCE(p_tabulator,0) < 0 OR COALESCE(p_new_balance,0) < 0 THEN
    RAISE EXCEPTION 'Los importes no pueden ser negativos.';
  END IF;
  IF p_patient_id IS NULL THEN RAISE EXCEPTION 'Selecciona el cliente al que corresponde el recibo.'; END IF;
  IF p_payment_amount > COALESCE(p_previous_balance,0) + 0.009 THEN RAISE EXCEPTION 'El recibo no puede superar el saldo pendiente.'; END IF;
  IF COALESCE(p_tabulator,0) > p_payment_amount THEN RAISE EXCEPTION 'El tabulador/descuento no puede superar el importe del recibo.'; END IF;
  IF length(COALESCE(p_patient_name,'')) > 200 OR length(COALESCE(p_clinic,'')) > 200 OR length(COALESCE(p_concept,'')) > 200 OR length(COALESCE(p_notes,'')) > 2000 THEN
    RAISE EXCEPTION 'Uno de los campos de texto supera el límite permitido.';
  END IF;
  IF p_snapshot IS NOT NULL AND jsonb_typeof(p_snapshot) <> 'object' THEN RAISE EXCEPTION 'Los datos de impresión no tienen un formato válido.'; END IF;

  IF p_patient_id IS NOT NULL THEN
    SELECT COALESCE(NULLIF(trim(concat_ws(' ',NULLIF(trim(pt.first_names),''),NULLIF(trim(pt.surnames),''))),''),NULLIF(trim(pt.name),''))
      INTO v_canonical_patient_name
      FROM public.patients pt WHERE pt.id=p_patient_id;
    IF NOT FOUND THEN RAISE EXCEPTION 'El paciente no existe o no tienes permiso para consultarlo.'; END IF;
    IF COALESCE(v_canonical_patient_name,'') <> '' THEN p_patient_name := v_canonical_patient_name; END IF;
  END IF;

  IF p_manager_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.collection_managers m WHERE m.id=p_manager_id AND m.active IS DISTINCT FROM false
  ) THEN RAISE EXCEPTION 'El gestor seleccionado no existe o está inactivo.'; END IF;

  IF p_payment_id IS NOT NULL THEN
    SELECT py.patient_id,py.amount INTO v_payment_patient,v_payment_amount
      FROM public.payments py WHERE py.id=p_payment_id;
    IF NOT FOUND THEN RAISE EXCEPTION 'El pago no existe o no tienes permiso para consultarlo.'; END IF;
    IF p_patient_id IS NULL OR v_payment_patient IS DISTINCT FROM p_patient_id THEN RAISE EXCEPTION 'El pago no corresponde al paciente seleccionado.'; END IF;
    IF round(v_payment_amount::numeric,2) <> round(p_payment_amount::numeric,2) THEN RAISE EXCEPTION 'El importe del recibo debe coincidir con el pago registrado.'; END IF;
    PERFORM pg_advisory_xact_lock(hashtext('dentaljg-payment:' || p_payment_id::text));
    SELECT * INTO r FROM public.collection_receipts WHERE payment_id=p_payment_id LIMIT 1;
    IF FOUND THEN
      IF r.created_by <> auth.uid() THEN RAISE EXCEPTION 'Este pago ya tiene un recibo asociado. Solicita acceso a la cuenta que lo generó.'; END IF;
      RETURN r;
    END IF;
  END IF;

  INSERT INTO public.collection_receipt_settings(user_id) VALUES(auth.uid()) ON CONFLICT(user_id) DO NOTHING;
  SELECT * INTO s FROM public.collection_receipt_settings WHERE user_id=auth.uid() FOR UPDATE;
  v_folio := COALESCE(s.folio_prefix,'JG-') || lpad(s.next_folio::text,greatest(s.folio_digits,length(s.next_folio::text)),'0');
  UPDATE public.collection_receipt_settings SET next_folio=next_folio+1,updated_at=now() WHERE user_id=auth.uid();
  INSERT INTO public.collection_receipts(created_by,folio,payment_id,patient_id,manager_id,patient_name,clinic,payment_amount,previous_balance,tabulator,net_amount,new_balance,concept,notes,receipt_snapshot)
  VALUES(auth.uid(),v_folio,p_payment_id,p_patient_id,p_manager_id,COALESCE(p_patient_name,''),COALESCE(p_clinic,''),p_payment_amount,COALESCE(p_previous_balance,0),COALESCE(p_tabulator,0),p_payment_amount-COALESCE(p_tabulator,0),GREATEST(0,COALESCE(p_previous_balance,0)-p_payment_amount),COALESCE(p_concept,'Abono'),COALESCE(p_notes,''),COALESCE(p_snapshot,'{}'::jsonb))
  RETURNING * INTO r;
  RETURN r;
END;
$$;

REVOKE ALL ON FUNCTION public.create_collection_receipt(uuid,uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.create_collection_receipt(uuid,uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid) TO authenticated;

-- La edición de recibos también pasa por servidor: impide desvincular un pago real,
-- asignar el importe de otro pago o editar recibos de otra cuenta.
CREATE OR REPLACE FUNCTION public.update_collection_receipt(
  p_receipt_id uuid,
  p_payment_id uuid,
  p_patient_id uuid,
  p_manager_id uuid,
  p_patient_name text,
  p_clinic text,
  p_payment_amount numeric,
  p_previous_balance numeric,
  p_tabulator numeric,
  p_new_balance numeric,
  p_concept text,
  p_notes text,
  p_snapshot jsonb
) RETURNS public.collection_receipts
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  r public.collection_receipts;
  v_payment_patient uuid;
  v_payment_amount numeric;
  v_canonical_patient_name text;
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.app_user_roles ar
    WHERE ar.user_id=auth.uid() AND lower(ar.role) IN ('admin','cobranza')
  ) THEN
    RAISE EXCEPTION 'Esta cuenta no tiene permiso para editar recibos.';
  END IF;
  SELECT * INTO r FROM public.collection_receipts
  WHERE id=p_receipt_id AND created_by=auth.uid() FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'El recibo no existe o no pertenece a esta cuenta.'; END IF;
  IF p_payment_amount IS NULL OR p_payment_amount<=0 OR p_payment_amount>9999999999.99 THEN
    RAISE EXCEPTION 'El importe debe ser mayor que cero y estar dentro del límite permitido.';
  END IF;
  IF COALESCE(p_previous_balance,0)<0 OR COALESCE(p_tabulator,0)<0 OR COALESCE(p_new_balance,0)<0 OR COALESCE(p_tabulator,0)>p_payment_amount THEN
    RAISE EXCEPTION 'Verifica saldo, tabulador e importe del recibo.';
  END IF;
  IF p_patient_id IS NULL THEN RAISE EXCEPTION 'Selecciona el cliente al que corresponde el recibo.'; END IF;
  IF p_payment_amount>COALESCE(p_previous_balance,0)+0.009 THEN RAISE EXCEPTION 'El recibo no puede superar el saldo pendiente.'; END IF;
  IF length(COALESCE(p_patient_name,''))>200 OR length(COALESCE(p_clinic,''))>200 OR length(COALESCE(p_concept,''))>200 OR length(COALESCE(p_notes,''))>2000 THEN
    RAISE EXCEPTION 'Uno de los campos de texto supera el límite permitido.';
  END IF;
  IF p_snapshot IS NOT NULL AND jsonb_typeof(p_snapshot)<>'object' THEN
    RAISE EXCEPTION 'Los datos de impresión no tienen un formato válido.';
  END IF;
  IF p_patient_id IS NOT NULL THEN
    SELECT COALESCE(NULLIF(trim(concat_ws(' ',NULLIF(trim(pt.first_names),''),NULLIF(trim(pt.surnames),''))),''),NULLIF(trim(pt.name),''))
      INTO v_canonical_patient_name FROM public.patients pt WHERE pt.id=p_patient_id;
    IF NOT FOUND THEN RAISE EXCEPTION 'El paciente no existe.'; END IF;
    IF COALESCE(v_canonical_patient_name,'')<>'' THEN p_patient_name:=v_canonical_patient_name; END IF;
  END IF;
  IF p_manager_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.collection_managers m WHERE m.id=p_manager_id AND m.active IS DISTINCT FROM false
  ) THEN RAISE EXCEPTION 'El gestor seleccionado no existe o está inactivo.'; END IF;
  IF p_payment_id IS NOT NULL THEN
    PERFORM pg_advisory_xact_lock(hashtext('dentaljg-payment:'||p_payment_id::text));
    SELECT py.patient_id,py.amount INTO v_payment_patient,v_payment_amount FROM public.payments py WHERE py.id=p_payment_id;
    IF NOT FOUND THEN RAISE EXCEPTION 'El pago seleccionado no existe.'; END IF;
    IF p_patient_id IS NULL OR v_payment_patient IS DISTINCT FROM p_patient_id THEN
      RAISE EXCEPTION 'El pago no corresponde al cliente seleccionado.';
    END IF;
    IF round(v_payment_amount::numeric,2)<>round(p_payment_amount::numeric,2) THEN
      RAISE EXCEPTION 'El importe del recibo debe coincidir con el pago registrado.';
    END IF;
    IF EXISTS (SELECT 1 FROM public.collection_receipts cr WHERE cr.payment_id=p_payment_id AND cr.id<>p_receipt_id) THEN
      RAISE EXCEPTION 'Este pago ya tiene otro recibo asociado.';
    END IF;
  END IF;
  UPDATE public.collection_receipts SET
    payment_id=p_payment_id, patient_id=p_patient_id, manager_id=p_manager_id,
    patient_name=COALESCE(p_patient_name,''), clinic=COALESCE(p_clinic,''),
    payment_amount=p_payment_amount, previous_balance=COALESCE(p_previous_balance,0),
    tabulator=COALESCE(p_tabulator,0), net_amount=p_payment_amount-COALESCE(p_tabulator,0),
    new_balance=GREATEST(0,COALESCE(p_previous_balance,0)-p_payment_amount), concept=COALESCE(p_concept,'Abono'),
    notes=COALESCE(p_notes,''), receipt_snapshot=COALESCE(p_snapshot,'{}'::jsonb)
  WHERE id=p_receipt_id AND created_by=auth.uid()
  RETURNING * INTO r;
  RETURN r;
END;
$$;
REVOKE ALL ON FUNCTION public.update_collection_receipt(uuid,uuid,uuid,uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.update_collection_receipt(uuid,uuid,uuid,uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb) TO authenticated;

-- Fase 12: proteger recibos programados y evitar nombres/gestores inconsistentes.
CREATE OR REPLACE FUNCTION public.create_scheduled_collection_receipt(
  p_patient_id uuid,
  p_patient_name text,
  p_clinic text,
  p_payment_amount numeric,
  p_previous_balance numeric,
  p_tabulator numeric,
  p_new_balance numeric,
  p_concept text,
  p_notes text,
  p_snapshot jsonb,
  p_manager_id uuid,
  p_scheduled_for date
) RETURNS public.collection_receipts
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  r public.collection_receipts;
  s public.collection_receipt_settings;
  v_folio text;
  v_canonical_patient_name text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para generar recibos.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles ar WHERE ar.user_id=auth.uid() AND lower(ar.role) IN ('admin','cobranza')) THEN
    RAISE EXCEPTION 'Esta cuenta no tiene permiso para generar recibos.';
  END IF;
  IF p_patient_id IS NULL OR p_scheduled_for IS NULL THEN RAISE EXCEPTION 'Falta el cliente o la fecha programada.'; END IF;
  IF COALESCE(p_payment_amount,0) <= 0 OR COALESCE(p_previous_balance,0) < 0 OR COALESCE(p_tabulator,0) < 0 OR COALESCE(p_new_balance,0) < 0 THEN
    RAISE EXCEPTION 'Verifica el importe, saldo y tabulador.';
  END IF;
  IF COALESCE(p_tabulator,0) > p_payment_amount THEN RAISE EXCEPTION 'El tabulador/descuento no puede superar el importe del recibo.'; END IF;
  IF p_payment_amount > COALESCE(p_previous_balance,0) + 0.009 THEN RAISE EXCEPTION 'El recibo programado no puede superar el saldo pendiente.'; END IF;
  SELECT COALESCE(NULLIF(trim(concat_ws(' ',NULLIF(trim(pt.first_names),''),NULLIF(trim(pt.surnames),''))),''),NULLIF(trim(pt.name),''))
    INTO v_canonical_patient_name FROM public.patients pt WHERE pt.id=p_patient_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'El paciente no existe o no tienes permiso para consultarlo.'; END IF;
  IF COALESCE(v_canonical_patient_name,'') <> '' THEN p_patient_name := v_canonical_patient_name; END IF;
  IF p_manager_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.collection_managers m WHERE m.id=p_manager_id AND m.active IS DISTINCT FROM false) THEN
    RAISE EXCEPTION 'El gestor seleccionado no existe o está inactivo.';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('dentaljg-scheduled-receipt:'||auth.uid()::text||':'||p_patient_id::text||':'||p_scheduled_for::text));
  SELECT * INTO r FROM public.collection_receipts
   WHERE created_by=auth.uid() AND patient_id=p_patient_id AND scheduled_for=p_scheduled_for AND payment_id IS NULL LIMIT 1;
  IF FOUND THEN RETURN r; END IF;

  INSERT INTO public.collection_receipt_settings(user_id) VALUES(auth.uid()) ON CONFLICT(user_id) DO NOTHING;
  SELECT * INTO s FROM public.collection_receipt_settings WHERE user_id=auth.uid() FOR UPDATE;
  v_folio := COALESCE(s.folio_prefix,'JG-') || lpad(s.next_folio::text,greatest(s.folio_digits,length(s.next_folio::text)),'0');
  UPDATE public.collection_receipt_settings SET next_folio=next_folio+1,updated_at=now() WHERE user_id=auth.uid();
  INSERT INTO public.collection_receipts(created_by,folio,payment_id,patient_id,manager_id,scheduled_for,patient_name,clinic,payment_amount,previous_balance,tabulator,net_amount,new_balance,concept,notes,receipt_snapshot)
  VALUES(auth.uid(),v_folio,NULL,p_patient_id,p_manager_id,p_scheduled_for,COALESCE(p_patient_name,''),COALESCE(p_clinic,''),p_payment_amount,COALESCE(p_previous_balance,0),COALESCE(p_tabulator,0),GREATEST(0,p_payment_amount-COALESCE(p_tabulator,0)),COALESCE(p_new_balance,0),COALESCE(p_concept,'Pago programado'),COALESCE(p_notes,''),COALESCE(p_snapshot,'{}'::jsonb))
  RETURNING * INTO r;
  RETURN r;
EXCEPTION WHEN unique_violation THEN
  SELECT * INTO r FROM public.collection_receipts WHERE created_by=auth.uid() AND patient_id=p_patient_id AND scheduled_for=p_scheduled_for AND payment_id IS NULL LIMIT 1;
  IF FOUND THEN RETURN r; END IF;
  RAISE;
END;
$$;

REVOKE ALL ON FUNCTION public.create_scheduled_collection_receipt(uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid,date) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.create_scheduled_collection_receipt(uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid,date) TO authenticated;

COMMIT;
