# DENTAL JG 1.0.4 — candidato de corrección

## Cambios incluidos

1. **Nombre del paciente en recibos de Cobranza**
   - Cuando el recibo tiene un paciente vinculado, se toma el nombre desde el registro del paciente (`first_names + surnames`, con compatibilidad de `patient_name`/`name`).
   - Se guarda ese nombre canónico en `collection_receipts.patient_name` y en el parámetro enviado a `create_collection_receipt`.
   - El titular sigue en el campo separado `receipt_snapshot.holder`; no se utiliza como sustituto automático del paciente.
   - El selector rápido de pacientes muestra nombre(s) y apellidos completos.

2. **Idempotencia de pagos en Gestor**
   - Cada pago local obtiene un UUID `client_operation_id` persistido en SQLite antes de sincronizar.
   - Los pagos existentes reciben un UUID durante la migración local.
   - La sincronización utiliza la clave única remota para evitar crear otro pago en un reintento. Si la operación ya existe, consulta su ID y vincula el pago local al existente.
   - El timestamp local se convierte a ISO-8601 UTC antes de enviarse a Supabase.
   - Gestor deja de dar de alta pacientes nuevos directamente: si no encuentra el paciente en Registro, detiene la sincronización y explica que debe registrarse primero en Registro de clientes.
   - Se eliminó la duplicación de la migración local de `payment_method` que podía provocar error de columna duplicada en ciertas actualizaciones.

## Orden obligatorio

1. Respaldar Supabase.
2. Ejecutar únicamente `DENTAL_JG_1_0_6_MIGRACION_SQL_INTEGRADA.sql` en el proyecto correcto de Supabase. Este archivo reúne Fases 6, 7 y 8 en orden; no ejecutes además las tres migraciones por separado.
3. Verificar que exista `payments.client_operation_id` y el índice único `payments_client_operation_id_uq`.
4. Compilar y probar las APK desde el proyecto actualizado.
5. Probar en datos de prueba: sincronización normal, reintento tras pérdida de conexión/respuesta, dos abonos legítimos iguales al mismo paciente, y paciente registrado exclusivamente desde Registro.
6. Verificar el recibo con paciente y titular distintos: el rótulo PACIENTE debe mostrar nombres + apellidos; TITULAR debe mostrar `holder_name`.

## Límites conocidos

- Este ZIP es un candidato integrado a partir del último archivo disponible `DENTAL_JG_1_0_3_CORREGIDO_NOMBRE_PACIENTE_TITULAR.zip`; no se ha publicado a GitHub ni ejecutado en Supabase.
- La sintaxis JavaScript de Cobranza se verificó con `node --check`.
- No se certificó compilación Android: el ZIP no contiene `gradlew` y no se ejecutó Gradle/Android Studio.
- La protección contra duplicados requiere que la migración SQL esté instalada antes de usar esta APK; si no, el servidor rechazará el campo nuevo.
- La sincronización del saldo sigue siendo una ruta independiente (`sync_patient_paid`, que actualmente conserva el mayor saldo mediante `greatest`). No debe considerarse resuelto el proceso completo de corrección/reversión de pagos hasta revisar esa función y probar el saldo de extremo a extremo.
- La migración de nombre de paciente con trigger obligatorio NO se incluye: podría rechazar actualizaciones de registros antiguos que no tengan `first_names` y `surnames`. La corrección incluida prioriza el registro vinculado en la app sin imponer esa restricción global.


## Correcciones adicionales en revisión (21-10-2026)

- Cobranza: el recibo programado prioriza `first_names + surnames` para el nombre del paciente, separado del titular.
- Cobranza: ya no genera recibos de todos los pacientes cuando el gestor no tiene pacientes asignados; tampoco asigna automáticamente todas las carteras sin gestor al gestor elegido.
- Registro: se agregó el selector obligatorio de Tratamiento (Básico, Orto, VIP, Damon) y se separó de Observaciones en la llamada RPC.
- Registro: la migración `DENTAL_JG_FASE7_TRATAMIENTO_REGISTRO.sql` reemplaza la función para guardar `p_treatment` en `patients.treatment` y `p_observations` en `patients.observations`.
- Cobranza y Administración: corregido el pie del recibo a “recibo no válido sin sello”. Administración conserva el alta centralizada exclusivamente en Registro de Clientes.
- La protección de pagos de Fase 6 solo agrega la clave idempotente y el índice único. No instala un trigger de saldo; la corrección completa de saldos/reversiones y las políticas RLS deben terminar de verificarse antes de liberar.


## Estado de compilación de esta revisión

Los ocho archivos JavaScript pasaron `node --check` y el ZIP pasó la comprobación de integridad. No se pudo ejecutar una compilación Android en este entorno porque el paquete no incluye `gradlew` y no hay instalación de Gradle disponible. Por ello, esta revisión todavía no debe tratarse como APK certificada para producción. La revisión de permisos RLS del proyecto vivo también sigue siendo requisito antes de cobros reales.


- La migración integrada también incluye Fase 10: reemplaza las políticas permisivas conocidas de pacientes/pagos/clínicas/gestores, evita exponer `manager_key` en lecturas de tabla y añade RPC de sincronización de Gestor por clave. La app Gestor guarda la clave cifrada con Android Keystore para las siguientes sincronizaciones.
