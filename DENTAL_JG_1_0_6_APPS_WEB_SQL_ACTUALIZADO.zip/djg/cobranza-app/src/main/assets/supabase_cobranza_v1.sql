-- AVISO DENTAL JG 1.0.6: SCRIPT HISTÓRICO / SUPERSEDIDO PARA LA MIGRACIÓN INTEGRADA.
-- No ejecutar después de DENTAL_JG_1_0_6_MIGRACION_SQL_INTEGRADA.sql: puede recrear
-- firmas antiguas de funciones, políticas RLS o permisos que esta versión restringe.
-- Conservar solo como referencia histórica.

-- DENTAL JG Cobranza: migración aditiva. No borra ni modifica pacientes ni pagos existentes.
create table if not exists public.collection_receipt_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  folio_prefix text not null default 'JG-',
  next_folio bigint not null default 1 check (next_folio > 0),
  folio_digits integer not null default 6 check (folio_digits between 1 and 12),
  receipt_title text not null default 'RECIBO DE COBRANZA',
  receipt_footer text not null default 'Gracias por su pago.',
  tabulator_default numeric(12,2) not null default 0 check (tabulator_default >= 0),
  updated_at timestamptz not null default now()
);
create table if not exists public.collection_receipts (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null default auth.uid() references auth.users(id),
  folio text not null,
  payment_id uuid references public.payments(id) on delete set null,
  patient_id uuid references public.patients(id) on delete set null,
  patient_name text not null default '',
  clinic text not null default '',
  payment_amount numeric(12,2) not null default 0,
  previous_balance numeric(12,2) not null default 0,
  tabulator numeric(12,2) not null default 0,
  net_amount numeric(12,2) not null default 0,
  new_balance numeric(12,2) not null default 0,
  concept text not null default 'Abono',
  notes text not null default '',
  receipt_snapshot jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(created_by, folio)
);
create index if not exists collection_receipts_created_idx on public.collection_receipts(created_at desc);
create index if not exists collection_receipts_payment_idx on public.collection_receipts(payment_id);
alter table public.collection_receipt_settings enable row level security;
alter table public.collection_receipts enable row level security;
grant select, insert, update on public.collection_receipt_settings to authenticated;
grant select, insert, update on public.collection_receipts to authenticated;
do $$ begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='collection_receipt_settings' and policyname='users manage own receipt settings') then
    create policy "users manage own receipt settings" on public.collection_receipt_settings for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='collection_receipts' and policyname='users view own receipts') then
    create policy "users view own receipts" on public.collection_receipts for select to authenticated using (created_by = auth.uid());
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='collection_receipts' and policyname='users insert own receipts') then
    create policy "users insert own receipts" on public.collection_receipts for insert to authenticated with check (created_by = auth.uid());
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='collection_receipts' and policyname='users update own receipts') then
    create policy "users update own receipts" on public.collection_receipts for update to authenticated using (created_by = auth.uid()) with check (created_by = auth.uid());
  end if;
end $$;
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='collection_receipts') then alter publication supabase_realtime add table public.collection_receipts; end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='patients') then alter publication supabase_realtime add table public.patients; end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='payments') then alter publication supabase_realtime add table public.payments; end if;
end $$;
create or replace function public.create_collection_receipt(
  p_payment_id uuid, p_patient_id uuid, p_patient_name text, p_clinic text,
  p_payment_amount numeric, p_previous_balance numeric, p_tabulator numeric,
  p_new_balance numeric, p_concept text, p_notes text, p_snapshot jsonb
) returns public.collection_receipts
language plpgsql security invoker set search_path=public as $$
declare s public.collection_receipt_settings; r public.collection_receipts; v_folio text;
begin
  if auth.uid() is null then raise exception 'Inicia sesión para generar recibos.'; end if;
  if coalesce(p_payment_amount,0) < 0 or coalesce(p_previous_balance,0) < 0 or coalesce(p_tabulator,0) < 0 then raise exception 'Los importes no pueden ser negativos.'; end if;
  -- Idempotencia: un pago sincronizado solo puede tener un recibo asociado por usuario.
  if p_payment_id is not null then
    select * into r from public.collection_receipts where created_by=auth.uid() and payment_id=p_payment_id limit 1;
    if found then return r; end if;
  end if;
  insert into public.collection_receipt_settings(user_id) values(auth.uid()) on conflict(user_id) do nothing;
  select * into s from public.collection_receipt_settings where user_id=auth.uid() for update;
  v_folio := coalesce(s.folio_prefix,'JG-') || lpad(s.next_folio::text, greatest(s.folio_digits, length(s.next_folio::text)), '0');
  update public.collection_receipt_settings set next_folio=next_folio+1, updated_at=now() where user_id=auth.uid();
  insert into public.collection_receipts(created_by,folio,payment_id,patient_id,patient_name,clinic,payment_amount,previous_balance,tabulator,net_amount,new_balance,concept,notes,receipt_snapshot)
  values(auth.uid(),v_folio,p_payment_id,p_patient_id,coalesce(p_patient_name,''),coalesce(p_clinic,''),coalesce(p_payment_amount,0),coalesce(p_previous_balance,0),coalesce(p_tabulator,0),greatest(0,coalesce(p_payment_amount,0)-coalesce(p_tabulator,0)),coalesce(p_new_balance,0),coalesce(p_concept,'Abono'),coalesce(p_notes,''),coalesce(p_snapshot,'{}'::jsonb)) returning * into r;
  return r;
end; $$;
grant execute on function public.create_collection_receipt(uuid,uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb) to authenticated;


-- Gestores y carteras de cobranza. Migración aditiva: no modifica pacientes ni pagos.
create table if not exists public.collection_managers (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null default auth.uid() references auth.users(id) on delete cascade,
  full_name text not null,
  phone text not null default '',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(created_by, full_name)
);

create table if not exists public.collection_portfolios (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  clinic_name text not null default 'Sin clínica',
  manager_id uuid references public.collection_managers(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(created_by, clinic_name)
);

create table if not exists public.collection_portfolio_patients (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null default auth.uid() references auth.users(id) on delete cascade,
  portfolio_id uuid not null references public.collection_portfolios(id) on delete cascade,
  patient_id uuid not null references public.patients(id) on delete cascade,
  assigned_at timestamptz not null default now(),
  unique(portfolio_id, patient_id)
);

create index if not exists collection_portfolios_manager_idx on public.collection_portfolios(manager_id);
create index if not exists collection_portfolio_patients_portfolio_idx on public.collection_portfolio_patients(portfolio_id);
create index if not exists collection_portfolio_patients_patient_idx on public.collection_portfolio_patients(patient_id);

alter table public.collection_managers enable row level security;
alter table public.collection_portfolios enable row level security;
alter table public.collection_portfolio_patients enable row level security;
grant select, insert, update, delete on public.collection_managers to authenticated;
grant select, insert, update, delete on public.collection_portfolios to authenticated;
grant select, insert, update, delete on public.collection_portfolio_patients to authenticated;

do $$ begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='collection_managers' and policyname='users manage own collection managers') then
    create policy "users manage own collection managers" on public.collection_managers for all to authenticated using (created_by = auth.uid()) with check (created_by = auth.uid());
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='collection_portfolios' and policyname='users manage own collection portfolios') then
    create policy "users manage own collection portfolios" on public.collection_portfolios for all to authenticated using (created_by = auth.uid()) with check (created_by = auth.uid());
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='collection_portfolio_patients' and policyname='users manage own portfolio patients') then
    create policy "users manage own portfolio patients" on public.collection_portfolio_patients for all to authenticated using (created_by = auth.uid()) with check (created_by = auth.uid());
  end if;
end $$;

do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='collection_managers') then alter publication supabase_realtime add table public.collection_managers; end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='collection_portfolios') then alter publication supabase_realtime add table public.collection_portfolios; end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='collection_portfolio_patients') then alter publication supabase_realtime add table public.collection_portfolio_patients; end if;
end $$;
