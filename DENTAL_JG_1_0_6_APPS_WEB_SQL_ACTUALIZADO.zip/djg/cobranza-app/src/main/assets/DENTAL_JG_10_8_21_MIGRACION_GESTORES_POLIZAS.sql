-- AVISO DENTAL JG 1.0.6: SCRIPT HISTÓRICO / SUPERSEDIDO PARA LA MIGRACIÓN INTEGRADA.
-- No ejecutar después de DENTAL_JG_1_0_6_MIGRACION_SQL_INTEGRADA.sql: puede recrear
-- firmas antiguas de funciones, políticas RLS o permisos que esta versión restringe.
-- Conservar solo como referencia histórica.

-- DENTAL JG 10.8.21: número de póliza, gestor asignado y clave de gestor.
-- Ejecutar en Supabase SQL Editor. Hacer respaldo antes de aplicar.
alter table public.patients add column if not exists policy_type text;
alter table public.patients add column if not exists assigned_manager_id uuid references public.collection_managers(id) on delete set null;
alter table public.collection_managers add column if not exists manager_key text;
create unique index if not exists collection_managers_manager_key_unique on public.collection_managers(manager_key) where manager_key is not null and btrim(manager_key) <> '';

-- La app Registro envía número de póliza y gestor asignado al crear el expediente.
drop function if exists public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,text,text,numeric,date,text);
create or replace function public.register_dental_jg_patient(
 p_name text, p_phone text, p_treatment text, p_total numeric,
 p_installments integer, p_installment_amount numeric, p_policy_number text, p_clinic text,
 p_first_names text, p_surnames text, p_address text, p_phone2 text, p_observations text,
 p_holder_name text, p_payment_mode text, p_tabulator numeric, p_first_payment_date date,
 p_payment_method text default 'efectivo', p_policy_type text default null,
 p_assigned_manager_id uuid default null
) returns uuid language plpgsql security definer set search_path=public as $$
declare new_id uuid; new_folio text;
begin
 if auth.uid() is null then raise exception 'Inicia sesión para registrar clientes.'; end if;
 if not exists(select 1 from public.app_user_roles where user_id=auth.uid() and role in ('registro','admin')) then raise exception 'Esta cuenta no tiene permiso para registrar clientes.'; end if;
 if length(trim(coalesce(p_holder_name,'')))=0 or length(trim(coalesce(p_first_names,p_name,'')))=0 or length(trim(coalesce(p_clinic,'')))=0 or length(trim(coalesce(p_policy_number,'')))=0 or length(trim(coalesce(p_address,'')))=0 or length(trim(coalesce(p_phone,'')))=0 then raise exception 'Completa todos los campos obligatorios.'; end if;
 if p_assigned_manager_id is null or not exists(select 1 from public.collection_managers where id=p_assigned_manager_id and coalesce(active,true)) then raise exception 'Selecciona un gestor activo.'; end if;
 if coalesce(p_payment_mode,'') not in ('quincenal','mensual') then raise exception 'Selecciona periodicidad quincenal o mensual.'; end if;
 if coalesce(p_payment_method,'') not in ('efectivo','transferencia') then raise exception 'Selecciona forma de pago efectivo o transferencia.'; end if;
 if coalesce(p_total,0)<=0 or coalesce(p_installments,0)<1 or coalesce(p_installment_amount,0)<=0 or coalesce(p_tabulator,0)<0 or p_first_payment_date is null then raise exception 'Verifica monto total, cantidad por pago, número de pagos, tabulador y fecha del primer pago.'; end if;
 new_folio:='JG-'||lpad(nextval('public.dental_jg_patient_folio_seq')::text,6,'0');
 insert into public.patients(folio,holder_name,first_names,surnames,address,phone2,observations,name,phone,treatment,total,paid,installments,installment_amount,policy_number,policy_type,assigned_manager_id,clinic,source_device,created_at,updated_at,payment_mode,tabulator,first_payment_date,payment_method)
 values(new_folio,trim(p_holder_name),trim(coalesce(p_first_names,p_name)),trim(coalesce(p_surnames,'')),trim(coalesce(p_address,'')),trim(coalesce(p_phone2,'')),trim(coalesce(p_observations,'')),trim(p_name),trim(p_phone),trim(coalesce(p_observations,p_treatment,'')),p_total,0,p_installments,p_installment_amount,trim(p_policy_number),nullif(trim(coalesce(p_policy_type,'')),''),p_assigned_manager_id,trim(p_clinic),'DENTAL JG Registro',now(),now(),p_payment_mode,p_tabulator,p_first_payment_date,p_payment_method) returning id into new_id;
 return new_id;
end; $$;
revoke all on function public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,text,text,numeric,date,text,text,uuid) from public, anon;
grant execute on function public.register_dental_jg_patient(text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,text,text,numeric,date,text,text,uuid) to authenticated;

-- RPC para que la app Gestor resuelva la clave sin exponer claves de otros gestores.
create or replace function public.dental_jg_manager_by_key(p_manager_key text)
returns table(id uuid, full_name text) language sql security definer set search_path=public as $$
 select m.id,m.full_name from public.collection_managers m
 where m.active is distinct from false and m.manager_key=trim(coalesce(p_manager_key,''))
 limit 1;
$$;
revoke all on function public.dental_jg_manager_by_key(text) from public, anon;
grant execute on function public.dental_jg_manager_by_key(text) to authenticated;
