-- AVISO DENTAL JG 1.0.6: SCRIPT HISTÓRICO / SUPERSEDIDO PARA LA MIGRACIÓN INTEGRADA.
-- No ejecutar después de DENTAL_JG_1_0_6_MIGRACION_SQL_INTEGRADA.sql: puede recrear
-- firmas antiguas de funciones, políticas RLS o permisos que esta versión restringe.
-- Conservar solo como referencia histórica.

-- DENTAL JG 10.8.38: generación de recibos programados antes del cobro.
-- Ejecutar una sola vez en Supabase SQL Editor. No borra pacientes, pagos ni recibos existentes.
alter table public.collection_receipts add column if not exists manager_id uuid references public.collection_managers(id) on delete set null;
alter table public.collection_receipts add column if not exists scheduled_for date;
create index if not exists collection_receipts_manager_idx on public.collection_receipts(manager_id);
create index if not exists collection_receipts_scheduled_idx on public.collection_receipts(created_by, patient_id, scheduled_for);
create unique index if not exists collection_receipts_scheduled_unique
  on public.collection_receipts(created_by, patient_id, scheduled_for)
  where payment_id is null and scheduled_for is not null;

-- Compatibilidad con el cliente actual: la versión web envía manager_id al crear recibos manuales.
create or replace function public.create_collection_receipt(
  p_payment_id uuid, p_patient_id uuid, p_patient_name text, p_clinic text,
  p_payment_amount numeric, p_previous_balance numeric, p_tabulator numeric,
  p_new_balance numeric, p_concept text, p_notes text, p_snapshot jsonb,
  p_manager_id uuid
) returns public.collection_receipts
language plpgsql security invoker set search_path=public as $$
declare r public.collection_receipts;
begin
  r := public.create_collection_receipt(p_payment_id,p_patient_id,p_patient_name,p_clinic,
    p_payment_amount,p_previous_balance,p_tabulator,p_new_balance,p_concept,p_notes,p_snapshot);
  update public.collection_receipts set manager_id=p_manager_id
   where id=r.id and created_by=auth.uid() returning * into r;
  return r;
end; $$;
grant execute on function public.create_collection_receipt(uuid,uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid) to authenticated;

create or replace function public.create_scheduled_collection_receipt(
  p_patient_id uuid, p_patient_name text, p_clinic text,
  p_payment_amount numeric, p_previous_balance numeric, p_tabulator numeric,
  p_new_balance numeric, p_concept text, p_notes text, p_snapshot jsonb,
  p_manager_id uuid, p_scheduled_for date
) returns public.collection_receipts
language plpgsql security invoker set search_path=public as $$
declare r public.collection_receipts; v_folio text; s public.collection_receipt_settings;
begin
  if auth.uid() is null then raise exception 'Inicia sesión para generar recibos.'; end if;
  if p_patient_id is null or p_scheduled_for is null then raise exception 'Falta el cliente o la fecha programada.'; end if;
  if coalesce(p_payment_amount,0) <= 0 or coalesce(p_previous_balance,0) < 0 or coalesce(p_tabulator,0) < 0 then raise exception 'Verifica el importe, saldo y tabulador.'; end if;
  -- Una cartera solo puede tener un recibo programado por cliente y fecha.
  select * into r from public.collection_receipts
   where created_by=auth.uid() and patient_id=p_patient_id and scheduled_for=p_scheduled_for and payment_id is null limit 1;
  if found then return r; end if;
  insert into public.collection_receipt_settings(user_id) values(auth.uid()) on conflict(user_id) do nothing;
  select * into s from public.collection_receipt_settings where user_id=auth.uid() for update;
  v_folio := coalesce(s.folio_prefix,'JG-') || lpad(s.next_folio::text,greatest(s.folio_digits,length(s.next_folio::text)),'0');
  update public.collection_receipt_settings set next_folio=next_folio+1,updated_at=now() where user_id=auth.uid();
  insert into public.collection_receipts(created_by,folio,payment_id,patient_id,manager_id,scheduled_for,patient_name,clinic,payment_amount,previous_balance,tabulator,net_amount,new_balance,concept,notes,receipt_snapshot)
  values(auth.uid(),v_folio,null,p_patient_id,p_manager_id,p_scheduled_for,coalesce(p_patient_name,''),coalesce(p_clinic,''),p_payment_amount,p_previous_balance,p_tabulator,greatest(0,p_payment_amount-p_tabulator),coalesce(p_new_balance,0),coalesce(p_concept,'Pago programado'),coalesce(p_notes,''),coalesce(p_snapshot,'{}'::jsonb))
  returning * into r;
  return r;
exception when unique_violation then
  select * into r from public.collection_receipts where created_by=auth.uid() and patient_id=p_patient_id and scheduled_for=p_scheduled_for and payment_id is null limit 1;
  if found then return r; end if;
  raise;
end; $$;
grant execute on function public.create_scheduled_collection_receipt(uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid,date) to authenticated;
