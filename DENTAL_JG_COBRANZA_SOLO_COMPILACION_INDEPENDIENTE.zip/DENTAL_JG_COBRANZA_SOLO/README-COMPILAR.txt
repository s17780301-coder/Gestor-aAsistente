DENTAL JG COBRANZA — PROYECTO INDEPENDIENTE
===========================================

Este ZIP contiene SOLAMENTE la tercera aplicación: DENTAL JG Cobranza y recibos.
No incluye Gestor ni Panel administrativo.

CONTENIDO
- app/: aplicación Android de Cobranza (WebView + interfaz local)
- cobranza-web/: versión web instalable para Windows mediante Edge/Chrome
- app/src/main/assets/supabase_cobranza_v1.sql: SQL para configurar tablas/folios
- .github/workflows/main.yml: compila únicamente la APK de Cobranza

GENERAR LA APK EN GITHUB
1. Crea un repositorio NUEVO para esta app, por ejemplo dental-jg-cobranza.
2. Descomprime este ZIP y sube el CONTENIDO de la carpeta, no la carpeta exterior.
3. Confirma que en la raíz del repositorio aparecen settings.gradle, build.gradle, app/ y .github/.
4. Entra en Actions. El flujo se llamará exactamente:
   "Compilar DENTAL JG Cobranza - Una APK"
5. Ejecuta el flujo o espera a que termine después del commit.
6. Abre la ejecución y descarga el artefacto:
   "DENTAL-JG-Cobranza-Recibos-APK"
7. Dentro encontrarás app-debug.apk.

WINDOWS
La carpeta cobranza-web es la versión PWA. Para instalarla como aplicación de Windows,
primero debe publicarse en un hosting HTTPS (por ejemplo GitHub Pages configurado para
servir cobranza-web, o un hosting web). Después abre su URL en Edge o Chrome y elige
Instalar aplicación.

SUPABASE
La app utiliza la configuración pública incluida en app/src/main/assets/config.js y
cobranza-web/config.js. Ejecuta el SQL incluido desde Supabase SQL Editor antes de usar
las funciones que dependen de las tablas de Cobranza. No publiques claves service_role.

IMPORTANTE
Este proyecto está separado para compilar solamente Cobranza. No se afirma que la APK
haya sido compilada aquí; el resultado real se confirma cuando termine GitHub Actions.
