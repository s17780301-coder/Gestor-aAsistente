# DENTAL JG · preparación para la tercera app

La app de gestoría registra cada abono localmente y `SupabaseSync` sincroniza cada movimiento en `public.payments`, relacionado con `public.patients` por `patient_id`. La futura tercera app deberá leer estos pagos desde la misma tabla autenticada, no depender de exportaciones manuales.

Contrato recomendado del reporte: `payment_id`, `patient_id`, `patient_name`, `amount`, `concept`, `reference`, `paid_at`, `source_device` y clínica del paciente. Cada abono debe conservar un identificador único para evitar duplicados. La app 3 todavía no se implementa ni se inventa un endpoint: se conectará cuando se definan sus pantallas, permisos y flujo.

Los avisos del gestor se programan a las 09:00 locales: días 13 y 28 (inicio de quincena en dos días), y días 4 y 19 (cierre). Android puede limitar alarmas en algunos dispositivos; hay que verificar notificaciones y permisos en un teléfono real.
