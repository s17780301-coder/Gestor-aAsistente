DENTAL JG V9.1 - correccion de compilacion

Se corrigio el nombre de la constante de Android para el campo de cantidad de pago: TYPE_NUMBER_FLAG_DECIMAL.

Para compilar desde GitHub:
1. Sube/reemplaza los archivos del ZIP en tu repositorio.
2. Abre la pestaña Actions.
3. Ejecuta "Compilar DENTAL JG V9.1".
4. Si termina en verde, abre la ejecucion y descarga el artefacto DentalJG-APK.

Este ZIP contiene el proyecto fuente; no es por si mismo una APK instalable.
