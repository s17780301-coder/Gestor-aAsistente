-- DENTAL JG 10.8.2 — campos de titular/paciente y permisos para eliminar recibos.
-- Ejecutar en Supabase SQL Editor. No borra pagos, clientes ni historial de carteras.
begin;
alter table public.patients add column if not exists patient_name text not null default '';
update public.patients set patient_name=name where coalesce(trim(patient_name),'')='';
grant select,insert,update on public.patients to authenticated;
-- Permitir que las aplicaciones autorizadas consulten recibos compartidos entre sí.
drop policy if exists "authorized apps view shared receipts" on public.collection_receipts;
create policy "authorized apps view shared receipts" on public.collection_receipts for select to authenticated using (exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('registro','admin','cobranza','gestor')));
-- Permitir eliminar recibos propios; la app siempre pide confirmación.
grant delete on public.collection_receipts to authenticated;
drop policy if exists "users delete own receipts" on public.collection_receipts;
create policy "users delete own receipts" on public.collection_receipts for delete to authenticated using (created_by=auth.uid());
-- Datos históricos se conservan: la cartera de la quincena anterior no se borra automáticamente,
-- para evitar pérdida de saldos, pagos reportados y trazabilidad. La vista de cartera debe filtrarse por quincena.

-- Cartera de cada quincena: instantánea identificada por fecha y paciente.
create table if not exists public.collection_quincena_cartera (
 id uuid primary key default gen_random_uuid(),
 created_by uuid not null references auth.users(id) on delete cascade,
 quincena_date date not null,
 patient_id uuid not null references public.patients(id) on delete cascade,
 titular_name text not null default '', patient_name text not null default '',
 clinic text not null default '', policy_number text not null default '',
 manager_id uuid references public.collection_managers(id) on delete set null,
 balance_net numeric(12,2) not null default 0,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 unique(created_by,quincena_date,patient_id)
);
alter table public.collection_quincena_cartera enable row level security;
grant select,insert,update on public.collection_quincena_cartera to authenticated;
drop policy if exists "authorized users manage own quincena portfolio" on public.collection_quincena_cartera;
create policy "authorized users manage own quincena portfolio" on public.collection_quincena_cartera for all to authenticated using(created_by=auth.uid() and exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('registro','admin','cobranza','gestor'))) with check(created_by=auth.uid() and exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('registro','admin','cobranza','gestor')));
create or replace function public.generate_dental_jg_quincena_portfolio(p_quincena_date date)
returns integer language plpgsql security invoker set search_path=public as $$
declare v_count integer;
begin
 if auth.uid() is null or not exists(select 1 from public.app_user_roles where user_id=auth.uid() and role in ('admin','cobranza','registro')) then raise exception 'No tienes permiso para generar carteras.'; end if;
 insert into public.collection_quincena_cartera(created_by,quincena_date,patient_id,titular_name,patient_name,clinic,policy_number,manager_id,balance_net,updated_at)
 select auth.uid(),p_quincena_date,p.id,p.name,coalesce(nullif(p.patient_name,''),p.name),coalesce(p.clinic,''),coalesce(p.policy_number,''),p.manager_id,greatest(0,coalesce(p.total,0)-coalesce(p.paid,0)),now()
 from public.patients p
 on conflict(created_by,quincena_date,patient_id) do update set titular_name=excluded.titular_name,patient_name=excluded.patient_name,clinic=excluded.clinic,policy_number=excluded.policy_number,manager_id=excluded.manager_id,balance_net=excluded.balance_net,updated_at=now();
 get diagnostics v_count=row_count;
 return v_count;
end; $$;
grant execute on function public.generate_dental_jg_quincena_portfolio(date) to authenticated;

commit;
