-- DENTAL JG 10.8.5: modalidad de pago por transferencia, compartida entre Registro y Gestor.
begin;
alter table public.patients add column if not exists payment_method text not null default 'quincenal';
update public.patients set payment_method='quincenal' where payment_method is null or payment_method not in ('quincenal','transferencia');
alter table public.patients drop constraint if exists patients_payment_method_check;
alter table public.patients add constraint patients_payment_method_check check (payment_method in ('quincenal','transferencia'));

-- Compatibilidad con los RPC actuales: los nuevos aceptan la modalidad desde el formulario.
create or replace function public.register_dental_jg_patient_v2(
 p_name text,p_phone text,p_treatment text,p_total numeric,p_installments integer,p_installment_amount numeric,p_policy_number text,p_clinic text,
 p_address text,p_phone2 text,p_policy_type text,p_first_payment_date date,p_manager_id uuid,p_observations text,p_payment_method text
) returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
 if p_payment_method not in ('quincenal','transferencia') or p_payment_method is null then raise exception 'Selecciona una modalidad de pago válida.'; end if;
 v_id := public.register_dental_jg_patient_v2(p_name,p_phone,p_treatment,p_total,p_installments,p_installment_amount,p_policy_number,p_clinic,p_address,p_phone2,p_policy_type,p_first_payment_date,p_manager_id,p_observations);
 update public.patients set payment_method=p_payment_method,updated_at=now() where id=v_id;
 return v_id;
end; $$;
revoke all on function public.register_dental_jg_patient_v2(text,text,text,numeric,integer,numeric,text,text,text,text,text,date,uuid,text,text) from public,anon;
grant execute on function public.register_dental_jg_patient_v2(text,text,text,numeric,integer,numeric,text,text,text,text,text,date,uuid,text,text) to authenticated;

create or replace function public.update_dental_jg_patient_v2(
 p_patient_id uuid,p_name text,p_phone text,p_treatment text,p_total numeric,p_installments integer,p_installment_amount numeric,p_policy_number text,p_clinic text,
 p_address text,p_phone2 text,p_policy_type text,p_first_payment_date date,p_manager_id uuid,p_observations text,p_payment_method text
) returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
 if p_payment_method not in ('quincenal','transferencia') or p_payment_method is null then raise exception 'Selecciona una modalidad de pago válida.'; end if;
 v_id := public.update_dental_jg_patient_v2(p_patient_id,p_name,p_phone,p_treatment,p_total,p_installments,p_installment_amount,p_policy_number,p_clinic,p_address,p_phone2,p_policy_type,p_first_payment_date,p_manager_id,p_observations);
 update public.patients set payment_method=p_payment_method,updated_at=now() where id=v_id;
 return v_id;
end; $$;
revoke all on function public.update_dental_jg_patient_v2(uuid,text,text,text,numeric,integer,numeric,text,text,text,text,text,date,uuid,text,text) from public,anon;
grant execute on function public.update_dental_jg_patient_v2(uuid,text,text,text,numeric,integer,numeric,text,text,text,text,text,date,uuid,text,text) to authenticated;

-- Gestor o administrador pueden cambiar solo la modalidad de pago, no el saldo ni los recibos.
create or replace function public.set_dental_jg_payment_method(p_patient_id uuid,p_payment_method text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is null or not exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('gestor','admin')) then raise exception 'Solo Gestor o Administración pueden cambiar la modalidad de pago.'; end if;
 if p_payment_method not in ('quincenal','transferencia') or p_payment_method is null then raise exception 'Modalidad de pago inválida.'; end if;
 update public.patients set payment_method=p_payment_method,updated_at=now() where id=p_patient_id;
 if not found then raise exception 'No se encontró el cliente.'; end if;
end; $$;
revoke all on function public.set_dental_jg_payment_method(uuid,text) from public,anon;
grant execute on function public.set_dental_jg_payment_method(uuid,text) to authenticated;
commit;
