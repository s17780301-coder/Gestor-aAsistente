package com.example.gestoriaasistente;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Sincroniza la caché local de DENTAL JG con las mismas tablas usadas por el panel web. */
public final class SupabaseSync {
    public static final String BASE = "https://nfwhymppyzoriihdwlyc.supabase.co";
    public static final String ANON = "sb_publishable_4n5cK2gQeEbTtdYKHAWVVQ_C1Gzl88O";
    private static final String PREF = "dentaljg_cloud";
    private final Context context;
    public SupabaseSync(Context c) { context = c.getApplicationContext(); }
    public String token() { return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("access_token", ""); }
    public String email() { return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("email", ""); }
    public boolean connected() { return !token().isEmpty(); }

    public String login(String email, String password) throws Exception {
        JSONObject body = new JSONObject(); body.put("email", email); body.put("password", password);
        JSONObject result = request("POST", "/auth/v1/token?grant_type=password", body, null, null);
        String access = result.optString("access_token", "");
        if (access.isEmpty()) throw new Exception("Supabase no devolvió una sesión válida.");
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("access_token", access).putString("refresh_token", result.optString("refresh_token", "")).putString("email", email).apply();
        return access;
    }
    public void logout() { context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply(); }


    public String currentUserId() throws Exception {
        JSONObject me=request("GET","/auth/v1/user",null,token(),null);
        return me.optString("id","");
    }
    public JSONArray currentRoles() throws Exception {
        String uid=currentUserId();
        return requestArray("GET","/rest/v1/app_user_roles?select=role&user_id=eq."+uid,null,token(),null);
    }
    public JSONArray messages() throws Exception {
        return requestArray("GET","/rest/v1/app_messages?select=id,sender_user_id,sender_app,target_app,subject,body,created_at,recipient_user_id&order=created_at.desc&limit=100",null,token(),null);
    }
    public JSONArray messageReads(String userId) throws Exception {
        return requestArray("GET","/rest/v1/app_message_reads?select=message_id&user_id=eq."+userId,null,token(),null);
    }
    public void markMessageRead(String messageId,String userId) throws Exception {
        JSONObject body=new JSONObject();body.put("message_id",messageId);body.put("user_id",userId);
        requestArray("POST","/rest/v1/app_message_reads",body,token(),"resolution=ignore-duplicates,return=minimal");
    }
    public void sendMessage(String userId,String senderRole,String targetRole,String subject,String bodyText) throws Exception {
        JSONObject body=new JSONObject();body.put("sender_user_id",userId);body.put("sender_app",senderRole);body.put("target_app",targetRole);body.put("recipient_user_id",JSONObject.NULL);body.put("subject",subject==null?"":subject.trim());body.put("body",bodyText==null?"":bodyText.trim());
        requestArray("POST","/rest/v1/app_messages",body,token(),"return=minimal");
    }
    public void setPaymentMethod(String patientId,String paymentMethod) throws Exception {
        JSONObject body=new JSONObject();body.put("p_patient_id",patientId);body.put("p_payment_method",paymentMethod);
        request("POST","/rest/v1/rpc/set_dental_jg_payment_method",body,token(),null);
    }

    public void sync(CustomerDbHelper db) throws Exception {
        String jwt = token(); if (jwt.isEmpty()) throw new Exception("Primero inicia sesión con el mismo correo y contraseña del panel administrativo.");
        SQLiteDatabase local = db.getWritableDatabase();
        // Leer primero la nube. Si un paciente ya existe en ambos lados, enlazarlo por teléfono + nombre
        // antes de subirlo para evitar crear un duplicado.
        JSONArray remotePatients = requestArray("GET", "/rest/v1/patients?select=*&order=created_at.desc", null, jwt, null);
        Cursor unsynced = local.rawQuery("SELECT id,nombre,telefono,tratamiento,total,pagado,remote_id,clinica,quincenas,pago_quincenal,numero_poliza,payment_method FROM pacientes WHERE remote_id IS NULL OR remote_id=''", null);
        try { while (unsynced.moveToNext()) {
            String localName = blank(unsynced.getString(1), "");
            String localPhone = digits(unsynced.getString(2));
            String matchedRemoteId = "";
            if (!localPhone.isEmpty()) {
                for (int i = 0; i < remotePatients.length(); i++) {
                    JSONObject candidate = remotePatients.getJSONObject(i);
                    if (localPhone.equals(digits(candidate.optString("phone", "")))
                            && localName.equalsIgnoreCase(blank(candidate.optString("name", ""), ""))) {
                        matchedRemoteId = candidate.optString("id", "");
                        if (!matchedRemoteId.isEmpty()) break;
                    }
                }
            }
            if (!matchedRemoteId.isEmpty()) {
                db.setRemotePatientId(unsynced.getLong(0), matchedRemoteId);
                continue;
            }
            JSONObject p = new JSONObject(); p.put("name", localName); p.put("phone", unsynced.getString(2)); p.put("treatment", unsynced.getString(3));
            p.put("total", unsynced.getDouble(4)); p.put("paid", unsynced.getDouble(5)); p.put("clinic", blank(unsynced.getString(7), "DENTAL JG"));
            p.put("installments", unsynced.getInt(8)); p.put("installment_amount", unsynced.getDouble(9)); p.put("policy_number", blank(unsynced.getString(10), "")); p.put("payment_method", blank(unsynced.getString(11), "quincenal")); p.put("source_device", "DENTAL JG APK");
            JSONArray saved = requestArray("POST", "/rest/v1/patients", p, jwt, "return=representation");
            if (saved.length() > 0) db.setRemotePatientId(unsynced.getLong(0), saved.getJSONObject(0).getString("id"));
        }} finally { unsynced.close(); }

        // 2) Descargar pacientes del panel y actualizar la copia local sin duplicarlos.
        remotePatients = requestArray("GET", "/rest/v1/patients?select=*&order=created_at.desc", null, jwt, null);
        for (int i=0;i<remotePatients.length();i++) { JSONObject p=remotePatients.getJSONObject(i); db.upsertRemotePatient(p); }

        // 3) Subir abonos locales aún no sincronizados, con el UUID real del paciente.
        Cursor localPayments = local.rawQuery("SELECT pa.id,pa.paciente_id,pa.monto,pa.fecha,pa.nota,p.nombre,p.remote_id,pa.remote_id FROM pagos pa JOIN pacientes p ON p.id=pa.paciente_id WHERE pa.remote_id IS NULL OR pa.remote_id=''", null);
        try { while(localPayments.moveToNext()) {
            String patientRemote=localPayments.getString(6); if(patientRemote==null || patientRemote.isEmpty()) continue;
            JSONObject pay=new JSONObject(); pay.put("patient_id",patientRemote); pay.put("patient_name",localPayments.getString(5)); pay.put("amount",localPayments.getDouble(2));
            pay.put("concept",blank(localPayments.getString(4),"Abono")); pay.put("reference",blank(localPayments.getString(4),"")); pay.put("source_device","DENTAL JG APK");
            JSONArray saved=requestArray("POST","/rest/v1/payments",pay,jwt,"return=representation");
            if(saved.length()>0) { db.setRemotePaymentId(localPayments.getLong(0),saved.getJSONObject(0).getString("id")); Cursor amountCursor=local.rawQuery("SELECT pagado FROM pacientes WHERE id=?",new String[]{String.valueOf(localPayments.getLong(1))}); double localPaid=0; if(amountCursor.moveToFirst())localPaid=amountCursor.getDouble(0); amountCursor.close(); JSONArray cloudPatient=requestArray("GET","/rest/v1/patients?id=eq."+patientRemote+"&select=paid",null,jwt,null); double cloudPaid=cloudPatient.length()>0?cloudPatient.getJSONObject(0).optDouble("paid",0):0; if(localPaid>cloudPaid){JSONObject update=new JSONObject();update.put("p_patient_id",patientRemote);update.put("p_new_paid",localPaid);request("POST","/rest/v1/rpc/sync_patient_paid",update,jwt,null);} }
        }} finally { localPayments.close(); }

        // 4) Descargar pagos del panel; remote_id evita insertar dos veces el mismo abono.
        JSONArray remotePayments=requestArray("GET","/rest/v1/payments?select=*&order=paid_at.desc",null,jwt,null);
        for(int i=0;i<remotePayments.length();i++) db.upsertRemotePayment(remotePayments.getJSONObject(i));
        // Releer la lista de pacientes para incluir los cambios de saldo que guardó el panel.
        remotePatients=requestArray("GET","/rest/v1/patients?select=*&order=created_at.desc",null,jwt,null);
        for(int i=0;i<remotePatients.length();i++) db.upsertRemotePatient(remotePatients.getJSONObject(i));
    }
    private static String blank(String s,String fallback){return s==null||s.trim().isEmpty()?fallback:s.trim();}
    private static String digits(String s){return s==null?"":s.replaceAll("[^0-9]", "");}
    private JSONObject request(String method,String path,JSONObject body,String jwt,String prefer) throws Exception {
        HttpURLConnection c=open(method,path,jwt,prefer); if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode(); String response=read(code>=200&&code<400?c.getInputStream():c.getErrorStream()); c.disconnect();
        if(code<200||code>=300) throw new Exception(explain(response,code)); return new JSONObject(response.isEmpty()?"{}":response);
    }
    private JSONArray requestArray(String method,String path,JSONObject body,String jwt,String prefer) throws Exception {
        HttpURLConnection c=open(method,path,jwt,prefer); if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode(); String response=read(code>=200&&code<400?c.getInputStream():c.getErrorStream()); c.disconnect();
        if(code<200||code>=300) throw new Exception(explain(response,code)); return new JSONArray(response.isEmpty()?"[]":response);
    }
    private HttpURLConnection open(String method,String path,String jwt,String prefer) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(BASE+path).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestProperty("apikey",ANON); c.setRequestProperty("Authorization","Bearer "+(jwt==null?ANON:jwt)); c.setRequestProperty("Accept","application/json"); if(prefer!=null)c.setRequestProperty("Prefer",prefer); return c;
    }
    private String read(InputStream in) throws Exception { if(in==null)return ""; try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder s=new StringBuilder();String line;while((line=r.readLine())!=null)s.append(line);return s.toString();} }
    private String explain(String response,int code){try{JSONObject j=new JSONObject(response);String m=j.optString("message",j.optString("msg",j.optString("error_description",response)));if(code==401)return "La sesión venció. Vuelve a iniciar sesión. "+m;if(code==403)return "Supabase bloqueó el acceso. Revisa las políticas RLS. "+m;return m;}catch(Exception e){return "Error de Supabase ("+code+"): "+response;}}
}
