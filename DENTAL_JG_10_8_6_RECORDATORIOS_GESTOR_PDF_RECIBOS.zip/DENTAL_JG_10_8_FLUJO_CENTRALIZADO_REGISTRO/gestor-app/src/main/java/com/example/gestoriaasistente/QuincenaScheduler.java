package com.example.gestoriaasistente;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;

/** Agenda avisos de quincena y notificaciones personales para preparar mensajes de transferencia. */
public final class QuincenaScheduler {
  private QuincenaScheduler() {}
  public static void scheduleAll(Context context) {
    scheduleNext(context, 13, 101, "Inicio de quincena en dos días: prepara la cobranza para el día 15.", false, false);
    scheduleNext(context, 28, 102, "Inicio de quincena en dos días: prepara la cobranza para el día 30.", false, false);
    scheduleNext(context, 4, 103, "Aviso de cierre: revisa y cierra la cobranza del periodo.", false, false);
    scheduleNext(context, 19, 104, "Aviso de cierre: revisa y cierra la cobranza del periodo.", false, false);
    // Recordatorio al gestor para preparar y enviar manualmente mensajes de WhatsApp.
    scheduleNext(context, 14, 105, "Hoy prepara los mensajes de WhatsApp para clientes por transferencia de la quincena del 15.", true, false);
    scheduleTransferMonthEnd(context);
  }
  private static void scheduleNext(Context c, int day, int id, String message, boolean transferReminder, boolean secondFortnight) {
    Calendar now=Calendar.getInstance(), target=Calendar.getInstance();
    target.set(Calendar.HOUR_OF_DAY,9);target.set(Calendar.MINUTE,0);target.set(Calendar.SECOND,0);target.set(Calendar.MILLISECOND,0);
    target.set(Calendar.DAY_OF_MONTH,Math.min(day,target.getActualMaximum(Calendar.DAY_OF_MONTH)));
    if(!target.after(now)){target.add(Calendar.MONTH,1);target.set(Calendar.DAY_OF_MONTH,Math.min(day,target.getActualMaximum(Calendar.DAY_OF_MONTH)));}
    schedule(c,target,id,message,transferReminder,secondFortnight);
  }
  private static void scheduleTransferMonthEnd(Context c) {
    Calendar now=Calendar.getInstance(), target=Calendar.getInstance();
    target.set(Calendar.HOUR_OF_DAY,9);target.set(Calendar.MINUTE,0);target.set(Calendar.SECOND,0);target.set(Calendar.MILLISECOND,0);
    setMonthEndReminderDay(target);
    if(!target.after(now)){target.add(Calendar.MONTH,1);setMonthEndReminderDay(target);}
    schedule(c,target,106,"Hoy prepara los mensajes de WhatsApp para clientes por transferencia de la quincena de fin de mes.",true,true);
  }
  private static void setMonthEndReminderDay(Calendar target) {
    int month=target.get(Calendar.MONTH);
    int last=target.getActualMaximum(Calendar.DAY_OF_MONTH);
    // Para febrero, avisar el día anterior al 28 o 29; los demás meses, el día 29.
    int day=(month==Calendar.FEBRUARY)?last-1:29;
    target.set(Calendar.DAY_OF_MONTH,Math.max(1,Math.min(day,last)));
  }
  private static void schedule(Context c,Calendar target,int id,String message,boolean transferReminder,boolean secondFortnight) {
    Intent i=new Intent(c,QuincenaReceiver.class).putExtra("message",message).putExtra("schedule_id",id)
      .putExtra("transfer_reminder",transferReminder).putExtra("second_fortnight",secondFortnight);
    PendingIntent pi=PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
    if(am!=null){if(android.os.Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,target.getTimeInMillis(),pi);else am.set(AlarmManager.RTC_WAKEUP,target.getTimeInMillis(),pi);}
  }
}
