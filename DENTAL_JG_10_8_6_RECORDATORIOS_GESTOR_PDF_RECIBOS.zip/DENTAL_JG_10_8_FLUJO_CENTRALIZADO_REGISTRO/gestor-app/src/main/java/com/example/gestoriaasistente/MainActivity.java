package com.example.gestoriaasistente;

import android.app.Activity;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.graphics.Typeface;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private CustomerDbHelper db;
    private SupabaseSync cloud;
    private SharedPreferences prefs;
    private TextView collectedValue, pendingValue, patientCount;
    private LinearLayout root;
    private boolean dark;
    private boolean introShown = false;
    private volatile boolean cloudSyncRunning = false;
    private final int navy=Color.rgb(11,87,51), teal=Color.rgb(53,196,119), ink=Color.rgb(27,39,54), muted=Color.rgb(111,129,149);
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},701);
        db=new CustomerDbHelper(this); cloud=new SupabaseSync(this); prefs=getSharedPreferences("dentaljg",MODE_PRIVATE); dark=prefs.getBoolean("dark",false);
        collectedValue=findViewById(R.id.collectedValue); pendingValue=findViewById(R.id.pendingValue); patientCount=findViewById(R.id.patientCount); root=findViewById(R.id.rootLayout);
        findViewById(R.id.btnAddPatient).setOnClickListener(v->choosePatientForPayment());
        findViewById(R.id.btnRegisterPatient).setOnClickListener(v->addPatient());
        findViewById(R.id.btnPatients).setOnClickListener(v->showPatients());
        findViewById(R.id.btnReports).setOnClickListener(v->showReports());
        findViewById(R.id.btnSettings).setOnClickListener(v->settings());
        findViewById(R.id.btnHeaderSettings).setOnClickListener(v->settings());
        findViewById(R.id.btnReminders).setOnClickListener(v->showReminders());
        findViewById(R.id.btnMessages).setOnClickListener(v->showMessages());
        findViewById(R.id.tilePatients).setOnClickListener(v->showPatients());
        findViewById(R.id.tileCollections).setOnClickListener(v->choosePatientForPayment());
        findViewById(R.id.tileWhatsApp).setOnClickListener(v->choosePatientForWhatsApp());
        findViewById(R.id.tileReports).setOnClickListener(v->showReports());
        ((TextView)findViewById(R.id.title)).setText("DENTAL JG");
        applyTheme(); refresh();
        QuincenaScheduler.scheduleAll(this);
        showBrandIntro();
        if (!prefs.getBoolean("gestor_registered", false)) new android.os.Handler(getMainLooper()).postDelayed(this::registerGestor,1450);
    }
    private int dp(float value){ return (int)(value*getResources().getDisplayMetrics().density+0.5f); }

    private void showBrandIntro(){
        if(introShown || isFinishing()) return; introShown=true;
        try { ToneGenerator tone=new ToneGenerator(AudioManager.STREAM_NOTIFICATION,45); tone.startTone(ToneGenerator.TONE_PROP_ACK,180); new android.os.Handler(getMainLooper()).postDelayed(tone::release,300); } catch(Exception ignored) {}
        LinearLayout splash=new LinearLayout(this); splash.setOrientation(LinearLayout.VERTICAL); splash.setGravity(android.view.Gravity.CENTER); splash.setPadding(30,36,30,36);
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(250,253,255),Color.rgb(235,249,252),Color.rgb(224,246,245)}); bg.setCornerRadius(28f); splash.setBackground(bg);
        android.widget.ImageView brandLogo=new android.widget.ImageView(this);
        brandLogo.setImageResource(R.drawable.dental_jg_logo);
        brandLogo.setAdjustViewBounds(true);
        brandLogo.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        brandLogo.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams logoParams=new LinearLayout.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels*.62f),android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        logoParams.gravity=android.view.Gravity.CENTER; logoParams.bottomMargin=dp(8); splash.addView(brandLogo,logoParams);
        TextView subtitle=txt("GESTOR APP",12,Color.rgb(20,82,116),true);subtitle.setGravity(android.view.Gravity.CENTER);subtitle.setPadding(0,4,0,0);splash.addView(subtitle);
        AlertDialog intro=new AlertDialog.Builder(this).setView(splash).create();intro.setCancelable(false);if(intro.getWindow()!=null)intro.getWindow().setBackgroundDrawableResource(android.R.color.transparent);intro.show(); if(intro.getWindow()!=null){intro.getWindow().setBackgroundDrawableResource(android.R.color.transparent);intro.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.82),-2);}
        splash.setAlpha(0f);splash.setScaleX(.94f);splash.setScaleY(.94f);splash.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).start();new android.os.Handler(getMainLooper()).postDelayed(intro::dismiss,1350);
    }

    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent); setIntent(intent); handleTransferReminderIntent(intent);
    }
    private void handleTransferReminderIntent(Intent intent){
        if(intent==null || !intent.getBooleanExtra("open_transfer_reminders",false)) return;
        boolean second=intent.getBooleanExtra("second_fortnight",false);
        intent.removeExtra("open_transfer_reminders"); intent.removeExtra("second_fortnight");
        new android.os.Handler(getMainLooper()).postDelayed(()->{if(!isFinishing())showTransferClients(second);},1700);
    }
    @Override protected void onResume(){
        super.onResume();
        handleTransferReminderIntent(getIntent());
        refresh();
        // Al volver a abrir el gestor, trae automáticamente los pacientes del panel.
        if (cloud != null && cloud.connected()) { syncCloudInBackground("", false); refreshUnreadMessageBadge(); }
    }

    private void syncCloudInBackground(String successMessage, boolean notify) {
        if (cloud == null || !cloud.connected() || cloudSyncRunning) return;
        cloudSyncRunning = true;
        new Thread(() -> {
            String error = null;
            try { cloud.sync(db); }
            catch (Exception ex) { error = ex.getMessage() == null ? "No se pudo sincronizar." : ex.getMessage(); }
            finally { cloudSyncRunning = false; }
            final String result = error;
            runOnUiThread(() -> {
                refresh();
                if (notify) {
                    if (result == null) toast(successMessage.isEmpty() ? "Cambios sincronizados." : successMessage);
                    else toast("Guardado en el teléfono; no se pudo sincronizar: " + result);
                }
            });
        }).start();
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
    private String money(double n){return NumberFormat.getCurrencyInstance(new Locale("es","MX")).format(n);}
    private void refresh(){if(collectedValue!=null){collectedValue.setText(money(db.sumQuincenal()));pendingValue.setText(money(db.sumPaid()));patientCount.setText(String.valueOf(db.count()));}}
    private void applyTheme(){
        root.setBackgroundColor(dark?Color.rgb(12,22,36):Color.rgb(245,247,251));
        int title=dark?Color.rgb(241,247,255):ink;
        ((TextView)findViewById(R.id.title)).setTextColor(title);
        ((TextView)findViewById(R.id.subtitle)).setTextColor(dark?Color.rgb(180,197,216):muted);
        int[] ids={R.id.tilePatients,R.id.tileCollections,R.id.tileWhatsApp,R.id.tileReports};
        for(int id:ids)findViewById(id).setBackgroundColor(dark?Color.rgb(26,43,62):Color.WHITE);
        recolorText(root, dark);
        int[] buttonIds={R.id.btnAddPatient,R.id.btnRegisterPatient,R.id.btnPatients,R.id.btnReports,R.id.btnSettings,R.id.btnReminders,R.id.btnMessages,R.id.btnHeaderSettings};
        for(int id:buttonIds){Button b=findViewById(id); if(dark){b.setTextColor(Color.rgb(225,240,249)); if(id!=R.id.btnAddPatient)b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(31,53,74)));} else if(id==R.id.btnHeaderSettings){b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(navy));b.setTextColor(teal);} }
        getWindow().setStatusBarColor(dark?Color.rgb(8,17,29):navy);getWindow().setNavigationBarColor(dark?Color.rgb(8,17,29):Color.rgb(245,247,251));
    }
    private void recolorText(View view, boolean useDark){
        if(view instanceof TextView){TextView t=(TextView)view;int c=t.getCurrentTextColor();if(useDark && (c==ink || c==Color.rgb(27,39,54)))t.setTextColor(Color.rgb(235,243,250));}
        if(view instanceof android.view.ViewGroup){android.view.ViewGroup group=(android.view.ViewGroup)view;for(int i=0;i<group.getChildCount();i++)recolorText(group.getChildAt(i),useDark);}
    }
    private LinearLayout form(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(22,10,22,12);return l;}
    private EditText field(LinearLayout box,String hint,int type){
        EditText e=new EditText(this);e.setHint(hint);e.setInputType(type);e.setSingleLine((type & InputType.TYPE_TEXT_FLAG_MULTI_LINE)==0);
        e.setTextColor(dark?Color.rgb(245,248,252):Color.rgb(27,39,54));
        e.setHintTextColor(dark?Color.rgb(170,187,204):Color.rgb(111,129,149));
        e.setTextSize(15);e.setPadding(15,10,15,10);e.setMinHeight((int)(50*getResources().getDisplayMetrics().density));
        android.graphics.drawable.GradientDrawable inputBg=new android.graphics.drawable.GradientDrawable();
        inputBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);inputBg.setCornerRadius(14f*getResources().getDisplayMetrics().density);
        inputBg.setColor(dark?Color.rgb(27,43,59):Color.rgb(247,250,252));
        inputBg.setStroke((int)getResources().getDisplayMetrics().density,dark?Color.rgb(57,79,100):Color.rgb(220,230,238));e.setBackground(inputBg);
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,-2);ep.bottomMargin=(int)(9*getResources().getDisplayMetrics().density);box.addView(e,ep);return e;
    }
    private TextView formHeading(String text){TextView t=txt(text,12,dark?Color.rgb(91,224,218):Color.rgb(12,139,145),true);t.setLetterSpacing(0.08f);t.setPadding(0,12,0,6);return t;}
    private void registerGestor(){
        LinearLayout f=form();
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);brand.setGravity(android.view.Gravity.CENTER);brand.setPadding(16,18,16,18);
        android.graphics.drawable.GradientDrawable brandBg=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(23,105,194),Color.rgb(11,61,145)});brandBg.setCornerRadius(24f);brand.setBackground(brandBg);
        TextView mark=txt("✦",34,Color.rgb(25,185,176),true);mark.setGravity(android.view.Gravity.CENTER);brand.addView(mark);
        TextView brandName=txt("DENTAL JG",25,Color.WHITE,true);brandName.setGravity(android.view.Gravity.CENTER);brandName.setLetterSpacing(.08f);brand.addView(brandName);
        TextView brandSub=txt("GESTIÓN PROFESIONAL",10,Color.rgb(213,239,255),true);brandSub.setGravity(android.view.Gravity.CENTER);brandSub.setPadding(0,5,0,0);brand.addView(brandSub);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.bottomMargin=14;f.addView(brand,bp);
        TextView intro=txt("Bienvenido. Primero registra al responsable de esta aplicación para personalizar tu espacio de trabajo.",14,dark?Color.WHITE:ink,false);intro.setPadding(2,0,2,10);f.addView(intro);
        f.addView(formHeading("DATOS DEL GESTOR"));
        EditText name=field(f,"Nombre completo del gestor",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText phone=field(f,"Teléfono del gestor (opcional)",InputType.TYPE_CLASS_PHONE);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Configura tu espacio").setView(f).setCancelable(false).setPositiveButton("Guardar y comenzar",null).create();
        dialog.setOnShowListener(v->{dialog.getButton(-1).setOnClickListener(w->{String n=name.getText().toString().trim();if(n.isEmpty()){name.setError("Escribe el nombre del gestor");return;}prefs.edit().putBoolean("gestor_registered",true).putString("profile_name",n).putString("gestor_phone",phone.getText().toString().trim()).apply();dialog.dismiss();toast("Gestor registrado correctamente.");});});
        dialog.show();styleDialog(dialog);
    }
    private void addPatient(){
        LinearLayout f=form();
        // La clínica se elige primero; reutiliza clínicas que ya existen en los pacientes locales.
        f.addView(formHeading("1. SELECCIONA LA CLÍNICA"));
        java.util.LinkedHashSet<String> clinicSet=new java.util.LinkedHashSet<>();
        clinicSet.add("DENTAL JG");
        Cursor existing=db.all();
        while(existing.moveToNext()){String value=existing.getString(10);if(value!=null&&!value.trim().isEmpty())clinicSet.add(value.trim());}
        existing.close();
        java.util.ArrayList<String> clinicNames=new java.util.ArrayList<>(clinicSet);
        Spinner clinic=new Spinner(this);
        ArrayAdapter<String> clinicAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,clinicNames);
        clinicAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);clinic.setAdapter(clinicAdapter);
        f.addView(clinic);
        f.addView(formHeading("2. DATOS DE CONTACTO"));
        EditText name=field(f,"Nombre completo del paciente",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText phone=field(f,"WhatsApp con lada (10 dígitos)",InputType.TYPE_CLASS_PHONE);
        EditText policy=field(f,"Número de póliza (opcional)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        f.addView(formHeading("3. TRATAMIENTO Y PLAN DE PAGO"));
        EditText treatment=field(f,"Tratamiento o concepto",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        EditText total=field(f,"Saldo total / costo del tratamiento ($)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText periods=field(f,"Número de quincenas acordadas",InputType.TYPE_CLASS_NUMBER);
        EditText payment=field(f,"Cantidad del pago quincenal ($)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        TextView paymentMethodLabel=txt("Modalidad de pago",13,muted,true);f.addView(paymentMethodLabel);
        Spinner paymentMethod=new Spinner(this);paymentMethod.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Pago normal por quincena","Pago por transferencia"}));f.addView(paymentMethod);
        periods.setText("1");
        ScrollView formScroll=new ScrollView(this);formScroll.setFillViewport(false);formScroll.addView(f);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Nuevo paciente").setMessage("Primero selecciona la clínica y después completa los datos.").setView(formScroll).setNegativeButton("Cancelar",null).setPositiveButton("Guardar paciente",(d,w)->{
            String n=name.getText().toString().trim(), p=phone.getText().toString().replaceAll("[^0-9]",""), t=treatment.getText().toString().trim(), pol=policy.getText().toString().trim(), cl=String.valueOf(clinic.getSelectedItem()).trim(); double amount=parse(total.getText().toString()), installment=parse(payment.getText().toString()); int q=parseInt(periods.getText().toString());
            if(n.isEmpty()||p.length()<10||amount<=0||q<=0||installment<=0){toast("Completa nombre, teléfono, saldo, quincenas y pago quincenal.");return;} String method=paymentMethod.getSelectedItemPosition()==1?"transferencia":"quincenal"; db.add(n,p,t,amount,q,installment,pol,cl,method);refresh();
            if (cloud.connected()) syncCloudInBackground("Paciente guardado y sincronizado.", true);
            else toast("Paciente guardado en este teléfono. Conecta Supabase para compartirlo con el panel.");
        }).create();dialog.setOnShowListener(v->styleDialog(dialog));dialog.show();
    }
    private double parse(String s){try{return Double.parseDouble(s.replace(",","."));}catch(Exception e){return 0;}}
    private int parseInt(String s){try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;}}
    private void showPatients(){
        Cursor c=db.all(); LinearLayout list=form(); list.setPadding(24,4,24,4); int count=0;
        while(c.moveToNext()){count++; final long id=c.getLong(0); String name=c.getString(1),phone=c.getString(2),treatment=c.getString(3); double total=c.getDouble(4),paid=c.getDouble(5),balance=c.getDouble(6);int quincenas=c.getInt(7);double installment=c.getDouble(8);
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(18,14,18,14);card.setBackgroundColor(dark?Color.rgb(26,43,62):Color.rgb(241,247,250));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=12;list.addView(card,cp);
            card.addView(txt(name,17,dark?Color.WHITE:ink,true));card.addView(txt((treatment==null||treatment.isEmpty()?"Tratamiento":treatment)+"  ·  "+phone,12,dark?Color.LTGRAY:muted,false));
            String policy=c.getString(9), clinic=c.getString(10), paymentMethod=c.getString(11); boolean transfer="transferencia".equalsIgnoreCase(paymentMethod);
            if((policy!=null&&!policy.isEmpty())||(clinic!=null&&!clinic.isEmpty())) card.addView(txt("Póliza: "+(policy==null||policy.isEmpty()?"Sin registrar":policy)+"  ·  Clínica: "+(clinic==null||clinic.isEmpty()?"Sin registrar":clinic),12,dark?Color.rgb(190,211,226):Color.rgb(66,91,113),false));
            card.addView(txt("Modalidad: "+(transfer?"PAGO POR TRANSFERENCIA":"Pago normal por quincena"),12,transfer?Color.rgb(13,132,91):(dark?Color.LTGRAY:muted),true));
            card.addView(txt("Saldo total: "+money(total)+"    Abonado: "+money(paid),13,dark?Color.WHITE:ink,false));card.addView(txt("Pendiente: "+money(balance)+" · "+quincenas+" quincenas · "+money(installment)+" por quincena",13,balance>0?Color.rgb(205,117,69):Color.rgb(22,150,105),true));
            LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setPadding(0,8,0,0);card.addView(actions);
            Button payBtn=miniButton("Abonar"), noteBtn=miniButton("Nota"), waBtn=miniButton("WhatsApp"), historyBtn=miniButton("Historial");
            actions.addView(payBtn,new LinearLayout.LayoutParams(0,-2,1));actions.addView(noteBtn,new LinearLayout.LayoutParams(0,-2,1));actions.addView(waBtn,new LinearLayout.LayoutParams(0,-2,1));actions.addView(historyBtn,new LinearLayout.LayoutParams(0,-2,1));
            payBtn.setOnClickListener(v->{if(balance>0)addPayment(id,name,balance);else toast("Este paciente ya liquidó su saldo.");});
            noteBtn.setOnClickListener(v->addReminder(id,name));waBtn.setOnClickListener(v->confirmWhatsApp(name,phone,balance));historyBtn.setOnClickListener(v->showPatientDetails(id,name,total,paid,balance));
            Button modeBtn=miniButton(transfer?"Cambiar a pago normal":"Cambiar a transferencia");LinearLayout.LayoutParams modeParams=new LinearLayout.LayoutParams(-1,-2);modeParams.topMargin=dp(5);card.addView(modeBtn,modeParams);modeBtn.setOnClickListener(v->changePaymentMethod(id,name,transfer?"quincenal":"transferencia"));
        }c.close(); if(count==0)list.addView(txt("Aún no hay pacientes. Usa ‘Registrar paciente’ para comenzar.",15,muted,false));
        ScrollView scroll=new ScrollView(this);scroll.addView(list);AlertDialog patientsDialog=new AlertDialog.Builder(this).setTitle("Pacientes y saldos").setView(scroll).setPositiveButton("Agregar paciente",(d,w)->addPatient()).setNegativeButton("Cerrar",null).show();styleDialog(patientsDialog);
    }
    private void patientActions(long id,String name,String phone,double total,double paid,double balance){
        String[] actions=balance>0?new String[]{"Registrar abono", "Agregar nota o recordatorio", "Preparar recordatorio por WhatsApp", "Ver historial de pagos", "Eliminar paciente"}:new String[]{"Agregar nota o recordatorio","Preparar mensaje por WhatsApp","Ver historial de pagos","Eliminar paciente"};
        new AlertDialog.Builder(this).setTitle(name).setItems(actions,(d,which)->{String a=actions[which];if(a.equals("Registrar abono"))addPayment(id,name,balance);else if(a.equals("Agregar nota o recordatorio"))addReminder(id,name);else if(a.contains("WhatsApp"))confirmWhatsApp(name,phone,balance);else if(a.equals("Ver historial de pagos"))showPatientDetails(id,name,total,paid,balance);else if(a.equals("Eliminar paciente"))new AlertDialog.Builder(this).setMessage("¿Eliminar a "+name+" y su historial de pagos y recordatorios?").setNegativeButton("Cancelar",null).setPositiveButton("Eliminar",(dd,ww)->{db.delete(id);refresh();showPatients();}).show();}).setNegativeButton("Cerrar",null).show();
    }
    private void addPayment(long id,String name,double balance){
        Cursor patient=db.one(id); double installment=0; if(patient.moveToFirst())installment=patient.getDouble(8); patient.close();
        LinearLayout f=form();EditText amount=field(f,"Cantidad recibida ($)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);if(installment>0)amount.setText(String.valueOf(Math.min(installment,balance)));EditText note=field(f,"Nota: efectivo, transferencia, etc.",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        CheckBox paidThisFortnight=new CheckBox(this);paidThisFortnight.setText("Marcar esta quincena como pagada y quitar al cliente de pendientes");paidThisFortnight.setTextColor(dark?Color.WHITE:ink);paidThisFortnight.setChecked(true);f.addView(paidThisFortnight);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Registrar pago · "+name).setMessage("Saldo pendiente: "+money(balance)+"\nQuincena: "+currentPeriodLabel()).setView(f).setNegativeButton("Cancelar",null).setPositiveButton("Guardar pago",(d,w)->{double n=parse(amount.getText().toString());if(n<=0){toast("Escribe una cantidad válida.");return;}if(n>balance+0.009){toast("El pago supera el saldo pendiente.");return;}String paymentNote=note.getText().toString().trim();if(db.payment(id,n,paymentNote)){
            if(paidThisFortnight.isChecked())db.markFortnightPaid(id,currentPeriod(),n);
            refresh();
            if (cloud.connected()) syncCloudInBackground("Pago guardado y sincronizado.", true);
            else toast(paidThisFortnight.isChecked()?"Pago guardado. Cliente retirado de pendientes de esta quincena.":"Pago guardado en este teléfono. Conecta Supabase para compartirlo.");
        }else toast("No se pudo guardar el pago.");}).create();dialog.setOnShowListener(v->styleDialog(dialog));dialog.show();
    }
    private void showPatientDetails(long id,String name,double total,double paid,double balance){StringBuilder s=new StringBuilder("Saldo total: ").append(money(total)).append("\nAbonado: ").append(money(paid)).append("\nPendiente: ").append(money(balance)).append("\n\nHistorial de pagos:\n");Cursor c=db.payments(id);int found=0;while(c.moveToNext()){found++;s.append(new SimpleDateFormat("d MMM yyyy · HH:mm",new Locale("es","MX")).format(new Date(c.getLong(1)))).append(" — ").append(money(c.getDouble(0)));String note=c.getString(2);if(note!=null&&!note.isEmpty())s.append(" (").append(note).append(")");s.append("\n");}c.close();if(found==0)s.append("Sin abonos registrados.");new AlertDialog.Builder(this).setTitle(name).setMessage(s.toString()).setPositiveButton("Aceptar",null).show();}
    private void confirmWhatsApp(String name,String phone,double balance){String defaultMessage="Hola {nombre}, te recordamos que el pago quincenal correspondiente a esta quincena está pendiente. Si ya realizaste tu pago, por favor ignora este mensaje. Gracias.";String template=prefs.getString("message",defaultMessage);if(template.contains("{saldo}")||template.toLowerCase(new Locale("es","MX")).contains("saldo pendiente"))template=defaultMessage;String msg=template.replace("{nombre}",name).replace("{saldo}","").trim();
        new AlertDialog.Builder(this).setTitle("Confirmar recordatorio").setMessage("Se abrirá WhatsApp con este mensaje. Tú decides si enviarlo:\n\n"+msg).setNegativeButton("Cancelar",null).setPositiveButton("Abrir WhatsApp",(d,w)->{try{String digits=phone.replaceAll("[^0-9]","");if(digits.length()==10)digits="52"+digits;Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+digits+"?text="+Uri.encode(msg)));startActivity(i);}catch(Exception e){toast("No se pudo abrir WhatsApp.");}}).show();}
    private String currentPeriod(){Calendar c=Calendar.getInstance();return String.format(Locale.US,"%04d-%02d-Q%d",c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH)<=15?1:2);}
    private String currentPeriodLabel(){Calendar c=Calendar.getInstance();return new SimpleDateFormat("MMMM yyyy",new Locale("es","MX")).format(c.getTime())+(c.get(Calendar.DAY_OF_MONTH)<=15?" · del 1 al 15":" · del 16 al fin de mes");}
    private void choosePatientForPayment(){String period=currentPeriod();Cursor c=db.pendingFortnight(period);java.util.ArrayList<Long> ids=new java.util.ArrayList<>();java.util.ArrayList<String> names=new java.util.ArrayList<>();java.util.ArrayList<Double> balances=new java.util.ArrayList<>();java.util.ArrayList<String> labels=new java.util.ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));names.add(c.getString(1));balances.add(c.getDouble(4));labels.add(c.getString(1)+" · pago quincenal "+money(c.getDouble(3))+" · pendiente "+money(c.getDouble(4)));}c.close();if(labels.isEmpty()){new AlertDialog.Builder(this).setTitle("Cobranza de esta quincena").setMessage("No hay pacientes pendientes para esta quincena. ¡Todo al corriente!").setPositiveButton("Aceptar",null).show();return;}new AlertDialog.Builder(this).setTitle("Pendientes: "+currentPeriodLabel()).setItems(labels.toArray(new String[0]),(d,w)->addPayment(ids.get(w),names.get(w),balances.get(w))).setNegativeButton("Cerrar",null).show();}
    private void choosePatientForWhatsApp(){choosePatient("¿A qué paciente recordarás el pago?",(id,name,phone,balance)->confirmWhatsApp(name,phone,balance));}
    private interface PatientAction{void run(long id,String name,String phone,double balance);}
    private void choosePatient(String title,PatientAction action){Cursor c=db.all();java.util.ArrayList<Long> ids=new java.util.ArrayList<>();java.util.ArrayList<String> labels=new java.util.ArrayList<>();java.util.ArrayList<String> names=new java.util.ArrayList<>();java.util.ArrayList<String> phones=new java.util.ArrayList<>();java.util.ArrayList<Double> balances=new java.util.ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));names.add(c.getString(1));phones.add(c.getString(2));balances.add(c.getDouble(6));labels.add(c.getString(1)+" · pendiente "+money(c.getDouble(6)));}c.close();if(labels.isEmpty()){toast("Primero registra un paciente.");return;}new AlertDialog.Builder(this).setTitle(title).setItems(labels.toArray(new String[0]),(d,which)->action.run(ids.get(which),names.get(which),phones.get(which),balances.get(which))).setNegativeButton("Cancelar",null).show();}
    private void addReminder(long patientId,String name){LinearLayout f=form();EditText note=field(f,"Nota o motivo del recordatorio",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|InputType.TYPE_TEXT_FLAG_MULTI_LINE);note.setMinLines(2);TextView dateLabel=txt("Fecha del recordatorio: "+new SimpleDateFormat("d MMM yyyy",new Locale("es","MX")).format(new Date()),14,teal,true);f.addView(dateLabel);final Calendar selected=Calendar.getInstance();dateLabel.setOnClickListener(v->new DatePickerDialog(this,(DatePicker view,int y,int m,int day)->{selected.set(y,m,day,9,0,0);dateLabel.setText("Fecha del recordatorio: "+new SimpleDateFormat("d MMM yyyy",new Locale("es","MX")).format(selected.getTime()));},selected.get(Calendar.YEAR),selected.get(Calendar.MONTH),selected.get(Calendar.DAY_OF_MONTH)).show());
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Nota / recordatorio · "+name).setMessage("Toca la fecha para cambiarla. La app guardará la nota en la lista de pendientes.").setView(f).setNegativeButton("Cancelar",null).setPositiveButton("Guardar recordatorio",(d,w)->{String text=note.getText().toString().trim();if(text.isEmpty()){toast("Escribe una nota o recordatorio.");return;}db.addReminder(patientId,text,selected.getTimeInMillis());toast("Recordatorio guardado.");}).create();dialog.setOnShowListener(v->styleDialog(dialog));dialog.show();}
    private void showReminders(){
        String[] options={"Notas y recordatorios existentes","Transferencias para la quincena del 15 · mensaje el día 14","Transferencias para fin de mes · mensaje el día 29","Ayuda: fechas de recordatorio"};
        new AlertDialog.Builder(this).setTitle("Recordatorios de Gestor").setItems(options,(d,w)->{if(w==0)showNoteReminders();else if(w==1)showTransferClients(false);else if(w==2)showTransferClients(true);else new AlertDialog.Builder(this).setTitle("Fechas de mensajes").setMessage("Quincena del 15: preparar los mensajes el día 14.\nQuincena de fin de mes: preparar los mensajes el día 29. En febrero se ajusta al día anterior al 28 o 29.\n\nGestor abrirá WhatsApp con el texto listo; el operador revisa y confirma el envío. No se envían mensajes en segundo plano.").setPositiveButton("Entendido",null).show();}).setNegativeButton("Cerrar",null).show();
    }
    private void showNoteReminders(){Cursor c=db.reminders();java.util.ArrayList<Long> ids=new java.util.ArrayList<>();java.util.ArrayList<String> labels=new java.util.ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));String date=new SimpleDateFormat("d MMM",new Locale("es","MX")).format(new Date(c.getLong(3)));labels.add(date+" · "+c.getString(1)+"\n"+c.getString(2));}c.close();if(labels.isEmpty()){new AlertDialog.Builder(this).setTitle("Notas y recordatorios").setMessage("No hay recordatorios pendientes. Entra a un paciente y selecciona ‘Agregar nota o recordatorio’ para crear uno.").setPositiveButton("Entendido",null).show();return;}new AlertDialog.Builder(this).setTitle("Pendientes · toca para marcar realizado").setItems(labels.toArray(new String[0]),(d,which)->new AlertDialog.Builder(this).setMessage("¿Marcar este recordatorio como realizado?").setNegativeButton("Todavía no",null).setPositiveButton("Sí, realizado",(dd,ww)->{db.completeReminder(ids.get(which));showNoteReminders();}).show()).setNegativeButton("Cerrar",null).show();}
    private void showTransferClients(boolean secondFortnight){
        Cursor c=db.transferPatients(secondFortnight);java.util.ArrayList<Long> ids=new java.util.ArrayList<>();java.util.ArrayList<String> names=new java.util.ArrayList<>(),phones=new java.util.ArrayList<>(),labels=new java.util.ArrayList<>();java.util.ArrayList<Double> balances=new java.util.ArrayList<>();
        while(c.moveToNext()){ids.add(c.getLong(0));names.add(c.getString(1));phones.add(c.getString(2));balances.add(c.getDouble(3));labels.add(c.getString(1)+" · pendiente "+money(c.getDouble(3)));}c.close();
        String title=secondFortnight?"Transferencias · fin de mes":"Transferencias · quincena del 15";
        if(labels.isEmpty()){new AlertDialog.Builder(this).setTitle(title).setMessage("No hay clientes activos marcados para pago por transferencia.").setPositiveButton("Aceptar",null).show();return;}
        new AlertDialog.Builder(this).setTitle(title+" · "+labels.size()+" clientes").setItems(labels.toArray(new String[0]),(d,which)->confirmTransferWhatsApp(names.get(which),phones.get(which),balances.get(which),secondFortnight)).setPositiveButton("Actualizar desde Supabase",(d,w)->{if(cloud.connected())syncCloudInBackground("Clientes actualizados.",true);else toast("Conecta Supabase para actualizar los clientes compartidos.");}).setNegativeButton("Cerrar",null).show();
    }
    private void confirmTransferWhatsApp(String name,String phone,double balance,boolean secondFortnight){
        String period=secondFortnight?"fin de mes":"del día 15";
        String text="Hola "+name+", te recordamos que tu pago por transferencia correspondiente a la quincena "+period+" está próximo. Por favor realiza tu transferencia en la fecha acordada. Si ya pagaste, puedes ignorar este mensaje. Gracias.";
        new AlertDialog.Builder(this).setTitle("Mensaje de transferencia").setMessage("Se abrirá WhatsApp con este texto. Revisa el destinatario y confirma el envío:\n\n"+text).setNegativeButton("Cancelar",null).setPositiveButton("Abrir WhatsApp",(d,w)->{try{String digits=phone==null?"":phone.replaceAll("[^0-9]","");if(digits.length()==10)digits="52"+digits;if(digits.length()<10){toast("Este cliente no tiene un teléfono válido.");return;}Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+digits+"?text="+Uri.encode(text)));startActivity(i);}catch(Exception e){toast("No se pudo abrir WhatsApp.");}}).show();
    }
    private void changePaymentMethod(long localId,String name,String method){
        String label="transferencia".equals(method)?"pago por transferencia":"pago normal por quincena";
        new AlertDialog.Builder(this).setTitle("Cambiar modalidad").setMessage("¿Cambiar a "+label+" para "+name+"? El cambio se compartirá con Registro y Cobranza.").setNegativeButton("Cancelar",null).setPositiveButton("Confirmar",(d,w)->{
            db.setPaymentMethod(localId,method);refresh();toast("Modalidad guardada en este dispositivo.");
            if(!cloud.connected()){toast("Conecta Supabase para compartir el cambio con las demás apps.");showPatients();return;}
            String remoteId=db.remotePatientId(localId);if(remoteId.isEmpty()){syncCloudInBackground("Sincronización solicitada.",true);toast("No se encontró el ID compartido; sincroniza y vuelve a intentarlo.");showPatients();return;}
            new Thread(()->{try{cloud.setPaymentMethod(remoteId,method);runOnUiThread(()->{toast("Modalidad actualizada en todas las apps.");syncCloudInBackground("",false);showPatients();});}catch(Exception ex){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("No se pudo compartir el cambio").setMessage("La modalidad quedó guardada localmente, pero Supabase rechazó la actualización: "+ex.getMessage()+"\n\nEjecuta la migración 10.8.5 y verifica que la cuenta tenga rol gestor.").setPositiveButton("Cerrar",null).show());}}).start();
        }).show();
    }
    private void showReports(){Cursor c=db.all();StringBuilder s=new StringBuilder("Resumen de cobranza\n\nTotal cobrado: ").append(money(db.sumQuincenal())).append("\nPagos registrados: ").append(money(db.sumPaid())).append("\nPacientes registrados: ").append(db.count()).append("\n\nCuentas pendientes:\n");int n=0;while(c.moveToNext()){double balance=c.getDouble(6);if(balance>0){n++;s.append("• ").append(c.getString(1)).append(" — ").append(money(balance)).append("; pago quincenal ").append(money(c.getDouble(8))).append("\n");}}c.close();if(n==0)s.append("No hay saldos pendientes.");new AlertDialog.Builder(this).setTitle("Reporte de cobranza").setMessage(s.toString()).setPositiveButton("Cerrar",null).show();}
    private Button miniButton(String label){Button b=new Button(this);b.setText(label);b.setTextSize(10);b.setAllCaps(false);b.setPadding(2,0,2,0);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(dark?Color.rgb(31,53,74):Color.rgb(224,242,242)));b.setTextColor(dark?Color.WHITE:Color.rgb(17,110,121));return b;}
    private void refreshUnreadMessageBadge(){
        if(cloud==null||!cloud.connected())return;
        new Thread(()->{try{String uid=cloud.currentUserId();JSONArray arr=cloud.messages();JSONArray reads=cloud.messageReads(uid);Set<String> readIds=new HashSet<>();for(int i=0;i<reads.length();i++)readIds.add(reads.getJSONObject(i).optString("message_id"));int unread=0;for(int i=0;i<arr.length();i++){JSONObject m=arr.getJSONObject(i);if(!uid.equals(m.optString("sender_user_id"))&&!readIds.contains(m.optString("id")))unread++;}final int n=unread;runOnUiThread(()->{Button b=findViewById(R.id.btnMessages);if(b!=null)b.setText(n>0?"✉   Mensajes del equipo · "+n+" sin leer":"✉   Mensajes del equipo");});}catch(Exception e){android.util.Log.w("DENTALJG-MSG","No se pudo actualizar el contador de mensajes",e);}}).start();
    }
    private void showMessages(){
        if(!cloud.connected()){new AlertDialog.Builder(this).setTitle("Mensajes DENTAL JG").setMessage("Primero entra a Ajustes y conecta tu cuenta de Supabase.").setPositiveButton("Entendido",null).show();return;}
        LinearLayout box=form();
        TextView intro=txt("Mensajes internos entre Registro, Cobranza, Gestor y Administración. No usa notificaciones: abre esta sección y actualiza la bandeja para consultar mensajes nuevos.",12,muted,false);box.addView(intro);
        EditText subject=field(box,"Asunto (opcional)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        EditText body=field(box,"Escribe tu mensaje",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|InputType.TYPE_TEXT_FLAG_MULTI_LINE);body.setMinLines(3);
        Spinner target=new Spinner(this);target.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Todas las apps","Registro","Cobranza","Gestor","Administración"}));box.addView(target);
        TextView folderLabel=txt("Mostrar bandeja:",12,muted,true);folderLabel.setPadding(0,12,0,2);box.addView(folderLabel);
        Spinner folder=new Spinner(this);folder.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Recibidos","Enviados"}));box.addView(folder);
        TextView inbox=txt("Pulsa Actualizar para consultar los mensajes.",13,dark?Color.WHITE:ink,false);inbox.setPadding(0,12,0,0);box.addView(inbox);
        Button markRead=miniButton("Marcar recibidos como leídos");box.addView(markRead);
        folder.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){markRead.setVisibility(position==0?View.VISIBLE:View.GONE);loadMessageInbox(inbox,position==0); }public void onNothingSelected(android.widget.AdapterView<?> parent){}});
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("✉ Mensajes del equipo").setView(box).setNegativeButton("Cerrar",null).setNeutralButton("Actualizar",null).setPositiveButton("Enviar",null).create();
        dialog.setOnShowListener(v->{dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(w->loadMessageInbox(inbox,folder.getSelectedItemPosition()==0));markRead.setOnClickListener(w->markInboxRead(inbox));dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w->{String text=body.getText().toString().trim();if(text.isEmpty()){toast("Escribe el mensaje antes de enviarlo.");return;}int idx=target.getSelectedItemPosition();String targetRole=new String[]{"all","registro","cobranza","gestor","admin"}[Math.max(0,Math.min(4,idx))];new Thread(()->{try{String uid=cloud.currentUserId();JSONArray rr=cloud.currentRoles();String sender="";for(int ri=0;ri<rr.length();ri++){String r=rr.getJSONObject(ri).optString("role");if("gestor".equals(r)){sender="gestor";break;}if("admin".equals(r))sender="admin";}if(sender.isEmpty())throw new Exception("La cuenta no tiene rol gestor ni admin.");cloud.sendMessage(uid,sender,targetRole,subject.getText().toString(),text);runOnUiThread(()->{toast("Mensaje enviado.");subject.setText("");body.setText("");folder.setSelection(1);loadMessageInbox(inbox,false);refreshUnreadMessageBadge();});}catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("No se pudo enviar").setMessage(e.getMessage()+"\n\nRevisa la migración DENTAL_JG_10_8_4_MENSAJERIA_NORMAL_SIN_NOTIFICACIONES.sql y el rol de tu cuenta.").setPositiveButton("Cerrar",null).show());}}).start();});loadMessageInbox(inbox,folder.getSelectedItemPosition()==0);});dialog.show();
    }
    private void loadMessageInbox(TextView inbox,boolean received){
        new Thread(()->{try{String uid=cloud.currentUserId();JSONArray arr=cloud.messages();JSONArray reads=cloud.messageReads(uid);Set<String> readIds=new HashSet<>();for(int i=0;i<reads.length();i++)readIds.add(reads.getJSONObject(i).optString("message_id"));StringBuilder text=new StringBuilder();int count=0;for(int i=0;i<arr.length();i++){JSONObject m=arr.getJSONObject(i);boolean own=uid.equals(m.optString("sender_user_id"));if(received?own:!own)continue;String id=m.optString("id");text.append(received?(readIds.contains(id)?"✓ LEÍDO · ":"● SIN LEER · "):"ENVIADO · ").append(m.optString("subject","Mensaje sin asunto")).append("\n").append(m.optString("body","")).append("\n").append(m.optString("sender_app","")).append(" → ").append(m.optString("target_app","")).append(" · ").append(m.optString("created_at","")).append("\n\n");count++;}if(count==0)text.append(received?"No hay mensajes recibidos.":"No has enviado mensajes.");String result=text.toString();runOnUiThread(()->inbox.setText(result));}catch(Exception e){runOnUiThread(()->inbox.setText("No se pudieron cargar los mensajes. Ejecuta el SQL de mensajería y verifica los permisos.\n"+e.getMessage()));}}).start();
    }
    private void markInboxRead(TextView inbox){
        new Thread(()->{try{String uid=cloud.currentUserId();JSONArray arr=cloud.messages();JSONArray reads=cloud.messageReads(uid);Set<String> readIds=new HashSet<>();for(int i=0;i<reads.length();i++)readIds.add(reads.getJSONObject(i).optString("message_id"));int marked=0;for(int i=0;i<arr.length();i++){JSONObject m=arr.getJSONObject(i);String id=m.optString("id");if(!uid.equals(m.optString("sender_user_id"))&&!readIds.contains(id)){cloud.markMessageRead(id,uid);marked++;}}final int n=marked;runOnUiThread(()->{toast(n==0?"No hay mensajes pendientes de lectura.":"Mensajes marcados como leídos: "+n);loadMessageInbox(inbox,true);refreshUnreadMessageBadge();});}catch(Exception e){runOnUiThread(()->inbox.setText("No se pudieron marcar como leídos. "+e.getMessage()));}}).start();
    }

    private void settings(){
        LinearLayout f=form();
        f.addView(formHeading("SINCRONIZACIÓN EN LA NUBE"));
        TextView cloudStatus=txt(cloud.connected()?"Cuenta conectada: "+cloud.email():"Sin cuenta conectada",13,dark?Color.WHITE:ink,false);
        cloudStatus.setPadding(0,2,0,8); f.addView(cloudStatus);
        Button loginButton=miniButton(cloud.connected()?"Cambiar cuenta Supabase":"Conectar cuenta Supabase");
        Button syncButton=miniButton("Sincronizar pacientes y pagos");
        Button logoutButton=miniButton("Cerrar sesión de nube");
        f.addView(loginButton); f.addView(syncButton); f.addView(logoutButton);
        loginButton.setOnClickListener(v->showCloudLogin(cloudStatus));
        syncButton.setOnClickListener(v->{if(!cloud.connected()){showCloudLogin(cloudStatus);return;} runCloudSync(cloudStatus);});
        logoutButton.setOnClickListener(v->{cloud.logout();cloudStatus.setText("Sin cuenta conectada");toast("Sesión de nube cerrada en este teléfono.");});
        TextView cloudNote=txt("Usa la misma cuenta de Supabase que en el panel. La primera sincronización puede tardar unos segundos.",12,muted,false);cloudNote.setPadding(0,4,0,12);f.addView(cloudNote);
        TextView themeLabel=txt(dark?"Tema oscuro activado":"Tema claro activado",15,teal,true);f.addView(themeLabel);
        Button toggle=new Button(this);toggle.setText(dark?"Cambiar a tema claro":"Activar tema oscuro");f.addView(toggle);final boolean[] newDark={dark};toggle.setOnClickListener(v->{newDark[0]=!newDark[0];toggle.setText(newDark[0]?"Cambiar a tema claro":"Activar tema oscuro");themeLabel.setText(newDark[0]?"Tema oscuro activado":"Tema claro activado");});
        TextView profileHeading=txt("Perfil de usuario",16,dark?Color.WHITE:ink,true);profileHeading.setPadding(0,18,0,4);f.addView(profileHeading);
        EditText profileName=field(f,"Nombre del usuario o responsable",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);profileName.setText(prefs.getString("profile_name","Administrador"));
        TextView messageHeading=txt("Mensaje de pago quincenal",16,dark?Color.WHITE:ink,true);messageHeading.setPadding(0,18,0,4);f.addView(messageHeading);
        EditText msg=field(f,"Usa {nombre}. No se incluirá el saldo total ni la cantidad adeudada.",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|InputType.TYPE_TEXT_FLAG_MULTI_LINE);msg.setMinLines(4);msg.setText(prefs.getString("message","Hola {nombre}, te recordamos que el pago quincenal correspondiente a esta quincena está pendiente. Si ya realizaste tu pago, por favor ignora este mensaje. Gracias."));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Configuración DENTAL JG").setMessage("Personaliza la apariencia, el perfil y el mensaje de cobranza.").setView(f).setNegativeButton("Cancelar",null).setPositiveButton("Guardar cambios",(d,w)->{dark=newDark[0];String user=profileName.getText().toString().trim();String message=msg.getText().toString().trim();prefs.edit().putBoolean("dark",dark).putString("profile_name",user.isEmpty()?"Administrador":user).putString("message",message.isEmpty()?"Hola {nombre}, te recordamos que el pago quincenal correspondiente a esta quincena está pendiente. Si ya realizaste tu pago, por favor ignora este mensaje. Gracias.":message).apply();((TextView)findViewById(R.id.title)).setText("DENTAL JG");applyTheme();toast("Configuración guardada.");}).show();
        styleDialog(dialog);
    }

    private void showCloudLogin(TextView cloudStatus){
        LinearLayout form=form();
        EditText email=field(form,"Correo de la cuenta Supabase",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText password=field(form,"Contraseña de Supabase",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        String savedEmail=cloud.email(); if(!savedEmail.isEmpty()) email.setText(savedEmail);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Conectar con Supabase")
                .setMessage("Escribe el correo y la contraseña de tu usuario autenticado de Supabase.")
                .setView(form).setNegativeButton("Cancelar",null).setPositiveButton("Conectar y sincronizar",null).create();
        dialog.setOnShowListener(v->{dialog.getButton(-1).setOnClickListener(w->{
            String e=email.getText().toString().trim(), p=password.getText().toString();
            if(e.isEmpty()){email.setError("Escribe tu correo");return;} if(p.isEmpty()){password.setError("Escribe tu contraseña");return;}
            dialog.dismiss(); toast("Conectando y sincronizando…");
            new Thread(()->{String error=null;try{cloud.login(e,p);cloud.sync(db);}catch(Exception ex){error=ex.getMessage()==null?"No se pudo sincronizar.":ex.getMessage();}
                final String result=error;runOnUiThread(()->{refresh();cloudStatus.setText(cloud.connected()?"Cuenta conectada: "+cloud.email():"Sin cuenta conectada");if(result==null)toast("Sincronización completada.");else toast("No se completó: "+result);});
            }).start();
        });});dialog.show();styleDialog(dialog);
    }
    private void runCloudSync(TextView cloudStatus){
        toast("Sincronizando pacientes y pagos…");
        new Thread(()->{String error=null;try{cloud.sync(db);}catch(Exception ex){error=ex.getMessage()==null?"No se pudo sincronizar.":ex.getMessage();}
            final String result=error;runOnUiThread(()->{refresh();cloudStatus.setText(cloud.connected()?"Cuenta conectada: "+cloud.email():"Sin cuenta conectada");if(result==null)toast("Sincronización completada.");else toast("No se completó: "+result);});
        }).start();
    }
    private void styleDialog(AlertDialog dialog){
        if(dialog.getWindow()==null)return;
        dialog.getWindow().setBackgroundDrawableResource(dark?android.R.color.background_dark:android.R.color.white);
        int primaryText=dark?Color.rgb(238,245,252):ink;int secondaryText=dark?Color.rgb(190,205,220):muted;
        TextView title=dialog.findViewById(androidxIdTitle());if(title!=null)title.setTextColor(primaryText);
        TextView message=dialog.findViewById(android.R.id.message);if(message!=null)message.setTextColor(secondaryText);
        if(dialog.getButton(-1)!=null){dialog.getButton(-1).setTextColor(dark?teal:Color.rgb(8,133,136));dialog.getButton(-1).setAllCaps(false);}
        if(dialog.getButton(-2)!=null){dialog.getButton(-2).setTextColor(primaryText);dialog.getButton(-2).setAllCaps(false);}
        if(dialog.getButton(-3)!=null){dialog.getButton(-3).setTextColor(primaryText);dialog.getButton(-3).setAllCaps(false);}
        recolorFormFields(dialog.getWindow().getDecorView());
    }
    private int androidxIdTitle(){return getResources().getIdentifier("alertTitle","id","android");}
    private void recolorFormFields(View view){
        if(view instanceof EditText){EditText e=(EditText)view;e.setTextColor(dark?Color.rgb(245,248,252):ink);e.setHintTextColor(dark?Color.rgb(170,187,204):muted);}
        if(view instanceof android.view.ViewGroup){android.view.ViewGroup group=(android.view.ViewGroup)view;for(int i=0;i<group.getChildCount();i++)recolorFormFields(group.getChildAt(i));}
    }
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
