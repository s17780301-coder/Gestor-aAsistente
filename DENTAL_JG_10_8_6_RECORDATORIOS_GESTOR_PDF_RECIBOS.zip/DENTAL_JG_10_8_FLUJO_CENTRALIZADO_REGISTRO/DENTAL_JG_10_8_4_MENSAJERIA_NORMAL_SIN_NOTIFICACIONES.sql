-- DENTAL JG 10.8.4 — mensajería interna normal, sin notificaciones ni Realtime.
-- Migración aditiva: no elimina ni modifica pacientes, pagos ni recibos.
-- Requiere public.app_user_roles con los roles: registro, cobranza, gestor, admin.
-- Ejecutar una sola vez en Supabase > SQL Editor.

begin;
create table if not exists public.app_messages (
  id uuid primary key default gen_random_uuid(),
  sender_user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  sender_app text not null check (sender_app in ('registro','cobranza','gestor','admin')),
  target_app text not null check (target_app in ('registro','cobranza','gestor','admin','all')),
  recipient_user_id uuid null references auth.users(id) on delete cascade,
  subject text not null default '' check (char_length(subject) <= 180),
  body text not null check (char_length(trim(body)) between 1 and 10000),
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  expires_at timestamptz null,
  constraint app_messages_expiry_valid check (expires_at is null or expires_at > created_at)
);
create index if not exists app_messages_target_created_idx on public.app_messages (target_app, created_at desc);
create index if not exists app_messages_recipient_created_idx on public.app_messages (recipient_user_id, created_at desc);
create index if not exists app_messages_sender_created_idx on public.app_messages (sender_user_id, created_at desc);
alter table public.app_messages enable row level security;
revoke all on public.app_messages from anon;
grant select, insert on public.app_messages to authenticated;
drop policy if exists "app messages visible to intended apps" on public.app_messages;
create policy "app messages visible to intended apps" on public.app_messages for select to authenticated
using (
 sender_user_id = auth.uid()
 or exists (select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin')
 or ((recipient_user_id is null or recipient_user_id=auth.uid()) and exists (
   select 1 from public.app_user_roles r where r.user_id=auth.uid() and (r.role=app_messages.target_app or app_messages.target_app='all')
 ))
);
drop policy if exists "app messages insert with assigned role" on public.app_messages;
create policy "app messages insert with assigned role" on public.app_messages for insert to authenticated
with check (sender_user_id=auth.uid() and exists (
 select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role=app_messages.sender_app
));
create table if not exists public.app_message_reads (
 message_id uuid not null references public.app_messages(id) on delete cascade,
 user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
 read_at timestamptz not null default now(),
 primary key (message_id,user_id)
);
create index if not exists app_message_reads_user_idx on public.app_message_reads (user_id,read_at desc);
alter table public.app_message_reads enable row level security;
revoke all on public.app_message_reads from anon;
grant select, insert on public.app_message_reads to authenticated;
drop policy if exists "users view own message read receipts" on public.app_message_reads;
create policy "users view own message read receipts" on public.app_message_reads for select to authenticated using (user_id=auth.uid());
drop policy if exists "users mark messages they can receive as read" on public.app_message_reads;
create policy "users mark messages they can receive as read" on public.app_message_reads for insert to authenticated
with check (user_id=auth.uid() and exists (
 select 1 from public.app_messages m where m.id=app_message_reads.message_id
 and (m.recipient_user_id is null or m.recipient_user_id=auth.uid())
 and (exists (select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin')
   or exists (select 1 from public.app_user_roles r where r.user_id=auth.uid() and (r.role=m.target_app or m.target_app='all')))
));
-- Si una migración anterior publicó las tablas de mensajes en Realtime, quitarlas de esa publicación.
do $$
begin
  if exists (select 1 from pg_publication where pubname='supabase_realtime') then
    if exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='app_messages') then
      alter publication supabase_realtime drop table public.app_messages;
    end if;
    if exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='app_message_reads') then
      alter publication supabase_realtime drop table public.app_message_reads;
    end if;
  end if;
end $$;
commit;

-- Esta versión no solicita permisos de notificación, no usa FCM ni se suscribe a Supabase Realtime.
-- Los usuarios abren Mensajes y pulsan Actualizar para consultar lo nuevo.
-- No enviar información clínica sensible en el cuerpo de los mensajes.
