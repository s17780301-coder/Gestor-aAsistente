package com.example.dentaljgadmin;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Notification;
import android.content.Context;
import android.os.Build;
import android.widget.Toast;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF102A43);
        getWindow().setNavigationBarColor(0xFF102A43);
        webView = new WebView(this);
        setContentView(webView);
        assetLoader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidMessagesBridge(this), "AndroidMessages");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 702);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE); if(nm!=null) nm.createNotificationChannel(new NotificationChannel("dentaljg_messages","Mensajes DENTAL JG",NotificationManager.IMPORTANCE_HIGH)); }
        webView.setWebViewClient(new WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (host != null && host.equals("appassets.androidplatform.net")) return false;
                return false;
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }
    @Override public void onBackPressed() { if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if(webView!=null) webView.destroy(); super.onDestroy(); }

    private static class AndroidMessagesBridge {
        private final Activity activity;
        AndroidMessagesBridge(Activity activity){this.activity=activity;}
        @JavascriptInterface public void notifyMessage(String title,String body){activity.runOnUiThread(()->{
            try {
                NotificationManager nm=(NotificationManager)activity.getSystemService(Context.NOTIFICATION_SERVICE);
                if(nm==null)return;
                Notification.Builder b=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?new Notification.Builder(activity,"dentaljg_messages"):new Notification.Builder(activity);
                b.setSmallIcon(activity.getApplicationInfo().icon).setContentTitle("DENTAL JG · "+(title==null||title.isEmpty()?"Nuevo mensaje":title)).setContentText(body==null?"Tienes un mensaje nuevo":body).setStyle(new Notification.BigTextStyle().bigText(body==null?"Tienes un mensaje nuevo":body)).setAutoCancel(true);
                nm.notify((int)(System.currentTimeMillis()%100000),b.build());
            } catch(Exception ex){Toast.makeText(activity,"Nuevo mensaje de DENTAL JG",Toast.LENGTH_LONG).show();}
        });}
    }
}
