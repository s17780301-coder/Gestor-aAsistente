package com.example.dentaljgcobranza;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Notification;
import android.content.Context;
import android.os.Build;
import android.widget.Toast;
import android.widget.FrameLayout;
import android.view.ViewGroup;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private WebView printView;
    private WebViewAssetLoader assetLoader;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF102A43);
        getWindow().setNavigationBarColor(0xFF102A43);
        root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        assetLoader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidMessagesBridge(this), "AndroidMessages");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 702);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE); if(nm!=null) nm.createNotificationChannel(new NotificationChannel("dentaljg_messages","Mensajes DENTAL JG",NotificationManager.IMPORTANCE_HIGH)); }
        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse local = assetLoader.shouldInterceptRequest(request.getUrl());
                return local != null ? local : super.shouldInterceptRequest(view, request);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("appassets.androidplatform.net".equals(uri.getHost())) return false;
                if ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                return true;
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }
    private class PrintBridge {
        private final Activity activity;
        PrintBridge(Activity activity) { this.activity = activity; }
        @JavascriptInterface public void printReceipt(String html) {
            activity.runOnUiThread(() -> {
                try {
                    if (printView != null) {
                        try { root.removeView(printView); printView.destroy(); } catch (Exception ignored) { }
                    }
                    printView = new WebView(activity);
                    printView.getSettings().setJavaScriptEnabled(false);
                    printView.getSettings().setDomStorageEnabled(false);
                    WebViewAssetLoader printAssetLoader = new WebViewAssetLoader.Builder()
                            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(activity)).build();
                    // Keep the print WebView attached and measured; unattached WebViews may produce an empty print job.
                    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                    root.addView(printView, lp);
                    printView.setAlpha(0.01f);
                    printView.setTranslationX(root.getWidth() + 20f);
                    String safeHtml = html == null ? "" : html;
                    String document = "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                            + "<link rel='stylesheet' href='styles.css'><style>@page{size:A4;margin:0}html,body{display:block!important;background:#fff!important;margin:0!important;padding:0!important;width:100%!important}"
                            + "#printArea{display:block!important;width:100%!important;height:auto!important}.receipt-print-sheet{display:grid!important;grid-template-columns:minmax(0,1fr)!important;grid-template-rows:repeat(4,minmax(0,1fr))!important;width:204mm!important;height:291mm!important;gap:1mm!important;overflow:hidden!important;align-content:stretch!important}.receipt-paper{display:block!important;break-inside:avoid!important;page-break-inside:avoid!important}.receipt-print-sheet{break-after:page!important;page-break-after:always!important}.receipt-print-sheet:last-child{break-after:auto!important;page-break-after:auto!important}</style></head><body><div id='printArea'>"
                            + safeHtml + "</div></body></html>";
                    printView.setWebViewClient(new WebViewClient() {
                        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                            WebResourceResponse local = printAssetLoader.shouldInterceptRequest(request.getUrl());
                            return local != null ? local : super.shouldInterceptRequest(view, request);
                        }
                        @Override public void onPageFinished(WebView view, String url) {
                            try {
                                PrintManager manager = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                                String jobName = "DENTAL_JG_Recibos";
                                manager.print(jobName, view.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder()
                                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                        .setResolution(new PrintAttributes.Resolution("dentaljg", "DENTAL JG", 300, 300))
                                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                            } catch (Exception ignored) { }
                        }
                    });
                    printView.loadDataWithBaseURL("https://appassets.androidplatform.net/assets/", document, "text/html", "UTF-8", null);
                } catch (Exception ignored) { }
            });
        }
    }
    @Override public void onBackPressed() { if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if(printView!=null) printView.destroy(); if(webView!=null) webView.destroy(); super.onDestroy(); }

    private static class AndroidMessagesBridge {
        private final Activity activity;
        AndroidMessagesBridge(Activity activity){this.activity=activity;}
        @JavascriptInterface public void notifyMessage(String title,String body){activity.runOnUiThread(()->{
            try {
                NotificationManager nm=(NotificationManager)activity.getSystemService(Context.NOTIFICATION_SERVICE);
                if(nm==null)return;
                Notification.Builder b=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?new Notification.Builder(activity,"dentaljg_messages"):new Notification.Builder(activity);
                b.setSmallIcon(activity.getApplicationInfo().icon).setContentTitle("DENTAL JG · "+(title==null||title.isEmpty()?"Nuevo mensaje":title)).setContentText(body==null?"Tienes un mensaje nuevo":body).setStyle(new Notification.BigTextStyle().bigText(body==null?"Tienes un mensaje nuevo":body)).setAutoCancel(true);
                nm.notify((int)(System.currentTimeMillis()%100000),b.build());
            } catch(Exception ex){Toast.makeText(activity,"Nuevo mensaje de DENTAL JG",Toast.LENGTH_LONG).show();}
        });}
    }
}
