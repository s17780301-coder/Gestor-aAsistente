-- DENTAL JG 10.8: liquidación, archivo previo y depuración a los 3 años.
-- Ejecutar en Supabase SQL Editor como administrador.
-- Antes de eliminar una cuenta vencida, guarda paciente, pagos, recibos y registros
-- de cartera disponibles en patient_account_archive. El archivo no tiene FK al paciente.

create table if not exists public.patient_account_archive (
  id uuid primary key default gen_random_uuid(),
  original_patient_id uuid not null,
  patient_name text not null default '',
  clinic text not null default '',
  liquidated_at timestamptz,
  archived_at timestamptz not null default now(),
  archive_data jsonb not null,
  deletion_completed_at timestamptz not null default now(),
  unique(original_patient_id)
);

alter table public.patients
  add column if not exists liquidated_at timestamptz,
  add column if not exists archive_after timestamptz,
  add column if not exists archived_at timestamptz;

alter table public.patient_account_archive enable row level security;
revoke all on public.patient_account_archive from anon, authenticated;
grant select on public.patient_account_archive to authenticated;
drop policy if exists "admins view archived patient accounts" on public.patient_account_archive;
create policy "admins view archived patient accounts"
  on public.patient_account_archive for select to authenticated
  using (exists (
    select 1 from public.app_user_roles r
    where r.user_id = auth.uid() and r.role = 'admin'
  ));

-- Inicia el reloj cuando el saldo llega a cero. Si después se corrige el saldo
-- y deja de estar liquidado, se reinicia el plazo; al volver a liquidarse empieza de nuevo.
create or replace function public.set_dental_jg_liquidation_date()
returns trigger language plpgsql set search_path = public as $$
declare was_liquidated boolean := false;
begin
  if TG_OP = 'UPDATE' then
    was_liquidated := coalesce(OLD.total,0) > 0 and coalesce(OLD.paid,0) >= coalesce(OLD.total,0);
  end if;

  if coalesce(NEW.total,0) > 0 and coalesce(NEW.paid,0) >= coalesce(NEW.total,0) then
    if TG_OP = 'INSERT' or not was_liquidated or OLD.liquidated_at is null then
      NEW.liquidated_at := now();
    else
      NEW.liquidated_at := OLD.liquidated_at;
    end if;
    NEW.archive_after := NEW.liquidated_at + interval '3 years';
  else
    NEW.liquidated_at := null;
    NEW.archive_after := null;
    NEW.archived_at := null;
  end if;
  NEW.updated_at := now();
  return NEW;
end;
$$;

drop trigger if exists trg_dental_jg_liquidation_date on public.patients;
create trigger trg_dental_jg_liquidation_date
before insert or update of total, paid on public.patients
for each row execute function public.set_dental_jg_liquidation_date();

-- No asignamos fecha inventada a las cuentas ya liquidadas antes de esta migración.
-- Para esas cuentas, establece liquidated_at con la fecha real conocida y archive_after
-- se calculará manualmente con: UPDATE patients SET liquidated_at='AAAA-MM-DD' WHERE id='UUID';

create or replace function public.archive_and_purge_dental_jg_liquidated_accounts()
returns integer
language plpgsql security definer set search_path = public
as $$
declare
  p record;
  v_data jsonb;
  v_count integer := 0;
  v_period_entries jsonb;
  v_portfolio_entries jsonb;
begin
  for p in
    select * from public.patients
    where archive_after is not null
      and archive_after <= now()
      and archived_at is null
      and coalesce(total,0) > 0
      and coalesce(paid,0) >= coalesce(total,0)
    for update skip locked
  loop
    select jsonb_build_object(
      'patient', to_jsonb(p),
      'payments', coalesce((select jsonb_agg(to_jsonb(x) order by x.paid_at, x.created_at)
                            from public.payments x where x.patient_id = p.id), '[]'::jsonb),
      'receipts', coalesce((select jsonb_agg(to_jsonb(x) order by x.created_at)
                            from public.collection_receipts x where x.patient_id = p.id), '[]'::jsonb)
    ) into v_data;

    v_period_entries := '[]'::jsonb;
    if to_regclass('public.collection_period_patients') is not null then
      execute 'select coalesce(jsonb_agg(to_jsonb(x)), ''[]''::jsonb) from public.collection_period_patients x where x.patient_id = $1'
        into v_period_entries using p.id;
      v_data := v_data || jsonb_build_object('collection_period_patients', v_period_entries);
    end if;

    v_portfolio_entries := '[]'::jsonb;
    if to_regclass('public.collection_portfolio_patients') is not null then
      execute 'select coalesce(jsonb_agg(to_jsonb(x)), ''[]''::jsonb) from public.collection_portfolio_patients x where x.patient_id = $1'
        into v_portfolio_entries using p.id;
      v_data := v_data || jsonb_build_object('collection_portfolio_patients', v_portfolio_entries);
    end if;

    insert into public.patient_account_archive(
      original_patient_id, patient_name, clinic, liquidated_at, archive_data
    ) values (p.id, p.name, coalesce(p.clinic,''), p.liquidated_at, v_data)
    on conflict (original_patient_id) do nothing;

    -- El archivo ya existe antes de eliminar registros operativos relacionados.
    if to_regclass('public.collection_period_patients') is not null then
      execute 'delete from public.collection_period_patients where patient_id = $1' using p.id;
    end if;
    if to_regclass('public.collection_portfolio_patients') is not null then
      execute 'delete from public.collection_portfolio_patients where patient_id = $1' using p.id;
    end if;
    delete from public.collection_receipts where patient_id = p.id;
    delete from public.payments where patient_id = p.id;
    delete from public.patients where id = p.id;
    v_count := v_count + 1;
  end loop;
  return v_count;
end;
$$;

-- Solo el trabajo programado debe ejecutar la depuración; no se expone a las apps.
revoke all on function public.archive_and_purge_dental_jg_liquidated_accounts() from public, anon, authenticated;

-- Programar una ejecución diaria. pg_cron debe estar habilitado en el proyecto Supabase.
create extension if not exists pg_cron with schema pg_catalog;
do $$
declare existing_job bigint;
begin
  select jobid into existing_job from cron.job where jobname = 'dental-jg-archive-liquidated-accounts';
  if existing_job is not null then
    perform cron.unschedule(existing_job);
  end if;
  perform cron.schedule(
    'dental-jg-archive-liquidated-accounts',
    '15 3 * * *',
    'select public.archive_and_purge_dental_jg_liquidated_accounts();'
  );
end;
$$;

-- Verificación de configuración:
-- SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name='patients' AND column_name IN ('liquidated_at','archive_after','archived_at');
-- SELECT jobname, schedule, command FROM cron.job WHERE jobname='dental-jg-archive-liquidated-accounts';
