(()=>{
  'use strict';
  const cfg = window.DENTAL_CONFIG || {};
  const $ = id => document.getElementById(id);
  let db = null;
  let user = null;
  let checkingUserId = null;
  let roleCheckPromise = null;

  const msg = (id, value) => { const el = $(id); if (el) el.textContent = value; };
  const setSaving = saving => {
    const button = $('save');
    button.disabled = saving;
    button.textContent = saving ? 'Guardando…' : 'Guardar cliente';
  };

  function setup() {
    if (!cfg.supabaseUrl || !cfg.supabaseAnonKey || !window.supabase) {
      msg('loginMsg', 'No se pudo cargar la configuración de Supabase. Revisa config.js y tu conexión a internet.');
      return false;
    }
    db = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
    });
    return true;
  }

  function showApp(isAuthorized) {
    $('loginCard').classList.toggle('hidden', !!isAuthorized);
    $('app').classList.toggle('hidden', !isAuthorized);
    if (isAuthorized) msg('appMsg', 'Sesión iniciada. Puedes registrar un cliente.');
  }

  async function verifyRole(candidateUser) {
    if (!candidateUser || !db) return false;
    if (roleCheckPromise && checkingUserId === candidateUser.id) return roleCheckPromise;
    checkingUserId = candidateUser.id;
    roleCheckPromise = (async () => {
      msg('loginMsg', 'Verificando permisos…');
      const { data, error } = await db.from('app_user_roles')
        .select('role')
        .eq('user_id', candidateUser.id)
        .in('role', ['registro', 'admin']);

      if (user && user.id !== candidateUser.id) return false;
      if (error) {
        console.error('No se pudieron consultar los roles:', error);
        await db.auth.signOut();
        if (!user || user.id === candidateUser.id) user = null;
        showApp(false);
        msg('loginMsg', 'No se pudieron verificar tus permisos: ' + (error.message || 'error de consulta') + '. Confirma que public.app_user_roles permita consultar el rol propio.');
        return false;
      }
      if (!data || data.length === 0) {
        await db.auth.signOut();
        if (!user || user.id === candidateUser.id) user = null;
        showApp(false);
        msg('loginMsg', 'La cuenta inició sesión, pero no tiene permiso de Registro. Solicita al administrador que asigne el rol registro.');
        return false;
      }
      user = candidateUser;
      showApp(true);
      msg('loginMsg', 'Acceso autorizado.');
      return true;
    })();
    try { return await roleCheckPromise; }
    finally {
      if (checkingUserId === candidateUser.id) {
        checkingUserId = null;
        roleCheckPromise = null;
      }
    }
  }

  $('loginForm').addEventListener('submit', async event => {
    event.preventDefault();
    if (!db && !setup()) return;
    const email = $('email').value.trim();
    const password = $('password').value;
    msg('loginMsg', 'Validando acceso…');
    const { data, error } = await db.auth.signInWithPassword({ email, password });
    if (error) {
      console.error('Error de inicio de sesión:', error);
      msg('loginMsg', 'No se pudo iniciar sesión. Verifica el correo y la contraseña; si el problema continúa, confirma que la cuenta esté habilitada en Supabase Auth.');
      return;
    }
    user = data.user;
    await verifyRole(data.user);
  });

  $('logout').addEventListener('click', async () => {
    if (db) await db.auth.signOut();
    user = null;
    showApp(false);
    msg('loginMsg', 'Sesión cerrada.');
  });

  $('clientForm').addEventListener('submit', async event => {
    event.preventDefault();
    if (!user || !db) {
      msg('appMsg', 'Tu sesión no está activa. Inicia sesión de nuevo.');
      showApp(false);
      return;
    }
    const name = $('name').value.trim();
    const clinic = $('clinic').value.trim();
    const total = Number($('total').value);
    const rawInstallments = Number($('installments').value);
    const installment = Number($('installment').value);
    if (!name || !clinic || !Number.isFinite(total) || total < 0 ||
        !Number.isInteger(rawInstallments) || rawInstallments < 0 ||
        !Number.isFinite(installment) || installment < 0) {
      msg('appMsg', 'Revisa los datos: nombre y clínica son obligatorios; el costo, el número de pagos y el importe por quincena deben ser válidos y no negativos.');
      return;
    }
    const payload = {
      p_name: name,
      p_phone: $('phone').value.trim(),
      p_treatment: $('treatment').value.trim(),
      p_total: total,
      p_installments: rawInstallments,
      p_installment_amount: installment,
      p_policy_number: $('policy').value.trim(),
      p_clinic: clinic
    };
    setSaving(true);
    msg('appMsg', 'Guardando el cliente en Supabase…');
    try {
      const { data, error } = await db.rpc('register_dental_jg_patient', payload);
      if (error) {
        console.error('Error al registrar paciente:', error);
        msg('appMsg', 'No se guardó el cliente: ' + error.message);
        return;
      }
      msg('appMsg', 'Cliente registrado correctamente. Identificador: ' + data);
      $('clientForm').reset();
      $('total').value = '0';
      $('installments').value = '24';
      $('installment').value = '0';
    } catch (error) {
      console.error('Error inesperado al registrar paciente:', error);
      msg('appMsg', 'Ocurrió un error de conexión. Revisa internet e inténtalo de nuevo.');
    } finally {
      setSaving(false);
    }
  });

  if (setup()) {
    db.auth.getSession().then(async ({ data, error }) => {
      if (error) {
        msg('loginMsg', 'No se pudo recuperar la sesión. Inicia sesión de nuevo.');
        return;
      }
      if (data.session) {
        user = data.session.user;
        await verifyRole(data.session.user);
      } else {
        showApp(false);
      }
    }).catch(error => {
      console.error('Error recuperando sesión:', error);
      showApp(false);
    });
    db.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_OUT' || !session) {
        user = null;
        showApp(false);
      }
      // SIGNED_IN se verifica en el manejador del formulario para evitar dos comprobaciones simultáneas.
    });
  }
})();
