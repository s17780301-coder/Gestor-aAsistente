Consulta LEEME_PRIMERO.txt para los pasos de compilación de las dos APK y la configuración de Supabase.
