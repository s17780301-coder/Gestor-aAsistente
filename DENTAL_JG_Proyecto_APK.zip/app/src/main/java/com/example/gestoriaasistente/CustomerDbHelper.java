package com.example.gestoriaasistente;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CustomerDbHelper extends SQLiteOpenHelper {
    public CustomerDbHelper(Context context) { super(context, "dentaljg.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE pacientes (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, telefono TEXT NOT NULL, tratamiento TEXT DEFAULT '', total REAL NOT NULL, pagado REAL NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE pagos (id INTEGER PRIMARY KEY AUTOINCREMENT, paciente_id INTEGER NOT NULL, monto REAL NOT NULL, fecha INTEGER NOT NULL, nota TEXT DEFAULT '')");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    public long add(String nombre, String telefono, String tratamiento, double total) {
        ContentValues v = new ContentValues(); v.put("nombre", nombre); v.put("telefono", telefono); v.put("tratamiento", tratamiento); v.put("total", total); v.put("pagado", 0);
        return getWritableDatabase().insert("pacientes", null, v);
    }
    public Cursor all() { return getReadableDatabase().rawQuery("SELECT id,nombre,telefono,tratamiento,total,pagado,(total-pagado) saldo FROM pacientes ORDER BY nombre COLLATE NOCASE", null); }
    public Cursor one(long id) { return getReadableDatabase().rawQuery("SELECT id,nombre,telefono,tratamiento,total,pagado,(total-pagado) saldo FROM pacientes WHERE id=?", new String[]{String.valueOf(id)}); }
    public void delete(long id) { getWritableDatabase().delete("pagos", "paciente_id=?", new String[]{String.valueOf(id)}); getWritableDatabase().delete("pacientes", "id=?", new String[]{String.valueOf(id)}); }
    public boolean payment(long id, double amount, String note) {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { ContentValues p=new ContentValues(); p.put("paciente_id",id); p.put("monto",amount); p.put("fecha",System.currentTimeMillis()); p.put("nota",note); db.insertOrThrow("pagos",null,p);
            db.execSQL("UPDATE pacientes SET pagado=pagado+? WHERE id=?",new Object[]{amount,id}); db.setTransactionSuccessful(); return true;
        } catch(Exception e) { return false; } finally { db.endTransaction(); }
    }
    public double sumPaid() { Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(pagado),0) FROM pacientes",null); double n=0; if(c.moveToFirst()) n=c.getDouble(0); c.close(); return n; }
    public double sumPending() { Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(MAX(total-pagado,0)),0) FROM pacientes",null); double n=0; if(c.moveToFirst()) n=c.getDouble(0); c.close(); return n; }
    public int count() { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM pacientes",null); int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n; }
    public Cursor payments() { return getReadableDatabase().rawQuery("SELECT p.nombre,pa.monto,pa.fecha,pa.nota FROM pagos pa JOIN pacientes p ON p.id=pa.paciente_id ORDER BY pa.fecha DESC LIMIT 100",null); }
}
