DENTAL JG — COMPILAR LAS DOS APK

1. Extrae el ZIP del proyecto. La carpeta de proyecto contiene settings.gradle, build.gradle, gestor-app, panel-apk y panel-web.
2. Ejecuta el workflow .github/workflows/compilar.yml desde GitHub Actions.
3. Descarga los artefactos separados: DENTAL-JG-Gestor-v9.7 y DENTAL-JG-Panel-v2.1.
4. Instala ambas APK en el teléfono. Inicia sesión en Supabase en el gestor y en el panel con la misma cuenta.

Si se usa un repositorio que compila el ZIP automáticamente, conserva el ZIP completo y usa el workflow de ese repositorio. Si GitHub marca error, comparte el mensaje exacto de Actions antes de modificar la base de datos.
