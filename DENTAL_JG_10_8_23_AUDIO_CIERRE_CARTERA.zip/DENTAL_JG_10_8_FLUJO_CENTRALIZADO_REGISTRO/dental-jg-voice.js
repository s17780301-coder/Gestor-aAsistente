/* Identidad sonora DENTAL JG 10.8.23: entrada electrónica breve y presentación de marca.
   La voz depende de las voces instaladas en el navegador/dispositivo. */
(function(){
  let played=false;
  function playIntro(){
    try {
      const Ctx=window.AudioContext||window.webkitAudioContext;
      if(!Ctx)return;
      const ctx=new Ctx();
      if(ctx.state==='suspended')ctx.resume();
      const now=ctx.currentTime;
      // Dos tonos ascendentes, suaves y cortos, como encendido futurista.
      [[220,0,0.24],[440,0.18,0.34],[660,0.38,0.42]].forEach(([freq,delay,duration],i)=>{
        const osc=ctx.createOscillator(), gain=ctx.createGain(), filter=ctx.createBiquadFilter();
        osc.type=i===2?'sine':'triangle'; osc.frequency.setValueAtTime(freq,now+delay);
        filter.type='lowpass';filter.frequency.value=1800;
        gain.gain.setValueAtTime(0.0001,now+delay);
        gain.gain.exponentialRampToValueAtTime(i===2?0.07:0.035,now+delay+0.035);
        gain.gain.exponentialRampToValueAtTime(0.0001,now+delay+duration);
        osc.connect(filter);filter.connect(gain);gain.connect(ctx.destination);
        osc.start(now+delay);osc.stop(now+delay+duration+0.03);
      });
      setTimeout(()=>ctx.close().catch(()=>{}),1600);
    }catch(e){/* Audio opcional: no bloquear la aplicación. */}
  }
  function speakBrand(){
    if(played||!('speechSynthesis' in window))return;
    played=true;
    try{
      speechSynthesis.cancel();
      const voices=speechSynthesis.getVoices();
      const preferred=voices.find(v=>/^es[-_]MX/i.test(v.lang)&&/female|mujer|sabina|helena|paulina|monica|zira/i.test(v.name))
        ||voices.find(v=>/^es[-_]MX/i.test(v.lang)&&/female|mujer|helena|monica|sabina|paulina/i.test(v.name))
        ||voices.find(v=>/^es/i.test(v.lang)&&/female|mujer|helena|monica|sabina|paulina|zira/i.test(v.name))
        ||voices.find(v=>/^es[-_]MX/i.test(v.lang))
        ||voices.find(v=>/^es/i.test(v.lang));
      const u=new SpeechSynthesisUtterance('Dental… JG');
      u.lang='es-MX';u.rate=0.82;u.pitch=0.78;u.volume=1;
      if(preferred)u.voice=preferred;
      playIntro();
      setTimeout(()=>speechSynthesis.speak(u),650);
    }catch(e){played=false;}
  }
  // Se activa tras interacción para respetar las restricciones de reproducción del navegador.
  window.addEventListener('load',()=>{speechSynthesis?.getVoices?.();},{once:true});
  document.addEventListener('pointerdown',speakBrand,{once:true,passive:true});
})();
