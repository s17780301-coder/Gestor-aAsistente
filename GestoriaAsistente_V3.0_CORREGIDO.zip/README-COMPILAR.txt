GESTORÍA ASISTENTE 3.0 — GENERAR APK DESDE EL TELÉFONO

Contenido: proyecto Android completo. No incluye APK compilada.

Novedades de 3.0:
- Cálculo de próximas quincenas: días 15 y 30; si el mes no tiene 30, usa el último día del mes.
- Muestra la próxima quincena y la siguiente.
- Recordatorios 2 días y 1 día antes de las próximas dos quincenas.
- Botón para pausar recordatorios.
- Mensaje de WhatsApp editable y guardado en el teléfono.
- Tema claro/oscuro con preferencia guardada.
- Conserva el paquete com.example.gestoriaasistente.

IMPORTANTE:
1. Sube este ZIP a la raíz del repositorio de GitHub.
2. En .github/workflows/main.yml usa el flujo de compilación incluido en este paquete. Si el repositorio ya tiene main.yml, edítalo y copia el contenido de .github/workflows/main.yml de este ZIP.
3. Ejecuta Acciones > Compilar Gestoria Asistente v3 > Ejecutar flujo de trabajo.
4. Cuando termine en verde, descarga el artefacto GestoriaAsistente-APK-V3.

No borres la carpeta .github del repositorio. El APK solo existe después de que GitHub complete la compilación.
