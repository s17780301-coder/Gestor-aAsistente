GESTORÍA ASISTENTE V4.0

Novedades añadidas sin quitar las funciones anteriores:
- Interfaz renovada y botones para las funciones principales.
- Tema claro/oscuro.
- Elección del tono de notificación.
- Lectura en voz alta del mensaje mediante la voz de Android.
- Base de datos local SQLite para clientes frecuentes (nombre, teléfono y notas).
- Acceso a WhatsApp con el mensaje preparado para cada cliente.
- Recordatorio personal dos días antes de cada quincena.
- Aviso para preparar y enviar mensajes a clientes un día antes (normalmente los días 14 y 29).
- Recordatorios programados para las próximas cuatro fechas de quincena.

COMPILAR EN GITHUB ACTIONS
1. Sube este ZIP al repositorio de GitHub, sustituyendo el ZIP anterior.
2. Abre Actions y ejecuta el flujo de trabajo de compilación.
3. Descarga el artefacto GestoriaAsistente-APK cuando el flujo termine correctamente.

NOTAS
- La base de datos de clientes se guarda localmente en el teléfono; no se sincroniza ni se respalda en la nube.
- La app prepara un mensaje en WhatsApp, pero no lo envía automáticamente. Debes revisar y pulsar Enviar en WhatsApp.
- Android puede limitar alarmas/notificaciones si los permisos están desactivados o el sistema restringe la app.
