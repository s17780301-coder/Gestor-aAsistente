package com.example.gestoriaasistente;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends android.app.Activity {
    private static final int NOTIFICATION_PERMISSION = 100;
    private SharedPreferences prefs;
    private boolean darkMode;
    private TextView status;
    private EditText messageInput;
    private boolean askedExactAlarm = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("gestoria", MODE_PRIVATE);
        darkMode = prefs.getBoolean("dark_mode", false);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        messageInput = findViewById(R.id.messageInput);
        messageInput.setText(prefs.getString("whatsapp_message", defaultMessage()));
        refreshDates();
        applyColors();
        updateStatus();

        findViewById(R.id.btnSchedule).setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
            }
            if (Build.VERSION.SDK_INT >= 31) {
                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (am != null && !am.canScheduleExactAlarms()) {
                    askedExactAlarm = true;
                    try {
                        Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    } catch (Exception e) { scheduleReminders(); }
                    return;
                }
            }
            scheduleReminders();
        });
        findViewById(R.id.btnCancel).setOnClickListener(v -> {
            cancelReminders();
            prefs.edit().putBoolean("enabled", false).apply();
            updateStatus();
            Toast.makeText(this, "Recordatorios pausados.", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btnSaveMessage).setOnClickListener(v -> saveMessage());
        findViewById(R.id.btnWhatsApp).setOnClickListener(v -> {
            saveMessage();
            String msg = prefs.getString("whatsapp_message", defaultMessage());
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=" + Uri.encode(msg)));
            try { startActivity(i); }
            catch (Exception e) { Toast.makeText(this, "No se pudo abrir WhatsApp o el navegador.", Toast.LENGTH_LONG).show(); }
        });
        findViewById(R.id.btnTheme).setOnClickListener(v -> {
            darkMode = !darkMode;
            prefs.edit().putBoolean("dark_mode", darkMode).apply();
            recreate();
        });
    }

    @Override protected void onResume() {
        super.onResume();
        if (askedExactAlarm) {
            askedExactAlarm = false;
            if (Build.VERSION.SDK_INT >= 31) {
                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (am != null && am.canScheduleExactAlarms()) scheduleReminders();
                else Toast.makeText(this, "Para horarios exactos, permite las alarmas en Ajustes.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private String defaultMessage() { return "Hola, te recuerdo amablemente que la fecha de tu pago es mañana, por favor. ¡Gracias!"; }

    private void saveMessage() {
        String msg = messageInput.getText().toString().trim();
        if (msg.isEmpty()) msg = defaultMessage();
        prefs.edit().putString("whatsapp_message", msg).apply();
        messageInput.setText(msg);
        Toast.makeText(this, "Mensaje guardado.", Toast.LENGTH_SHORT).show();
    }

    private void refreshDates() {
        SimpleDateFormat fmt = new SimpleDateFormat("EEEE d 'de' MMMM", new Locale("es", "MX"));
        Calendar now = Calendar.getInstance();
        Calendar next = nextQuincenaAfter(now);
        Calendar after = nextQuincenaAfter(next);
        TextView first = findViewById(R.id.nextPayment);
        TextView second = findViewById(R.id.afterPayment);
        first.setText("PRÓXIMA QUINCENA
" + capitalize(fmt.format(new Date(next.getTimeInMillis()))) + " · 9:00 a. m.");
        second.setText("Después: " + capitalize(fmt.format(new Date(after.getTimeInMillis()))) + " · 9:00 a. m.");
    }

    private String capitalize(String s) { if (s == null || s.isEmpty()) return s; return s.substring(0,1).toUpperCase(new Locale("es", "MX")) + s.substring(1); }

    // Quincenas: día 15 y día 30; en febrero y meses cortos se usa el último día del mes.
    private Calendar nextQuincenaAfter(Calendar from) {
        Calendar candidate = (Calendar) from.clone();
        candidate.set(Calendar.HOUR_OF_DAY, 9); candidate.set(Calendar.MINUTE, 0);
        candidate.set(Calendar.SECOND, 0); candidate.set(Calendar.MILLISECOND, 0);
        for (int offset = 0; offset < 4; offset++) {
            Calendar month = (Calendar) candidate.clone();
            month.set(Calendar.DAY_OF_MONTH, 15);
            if (month.after(from)) return month;
            Calendar end = (Calendar) candidate.clone();
            end.set(Calendar.DAY_OF_MONTH, Math.min(30, end.getActualMaximum(Calendar.DAY_OF_MONTH)));
            if (end.after(from)) return end;
            candidate.add(Calendar.MONTH, 1);
            candidate.set(Calendar.DAY_OF_MONTH, 1);
            candidate.set(Calendar.HOUR_OF_DAY, 9); candidate.set(Calendar.MINUTE, 0);
            candidate.set(Calendar.SECOND, 0); candidate.set(Calendar.MILLISECOND, 0);
        }
        candidate.set(Calendar.DAY_OF_MONTH, 15);
        return candidate;
    }

    private void scheduleReminders() {
        Calendar target = nextQuincenaAfter(Calendar.getInstance());
        for (int cycle = 0; cycle < 2; cycle++) {
            Calendar two = (Calendar) target.clone(); two.add(Calendar.DAY_OF_MONTH, -2);
            Calendar one = (Calendar) target.clone(); one.add(Calendar.DAY_OF_MONTH, -1);
            setAlarm(two, "Tu quincena será en 2 días.", 100 + cycle * 2);
            setAlarm(one, "Recuerda: la fecha de tu pago es mañana, por favor.", 101 + cycle * 2);
            target = nextQuincenaAfter(target);
        }
        prefs.edit().putBoolean("enabled", true).apply();
        updateStatus();
        Toast.makeText(this, "Recordatorios programados para las próximas dos quincenas.", Toast.LENGTH_LONG).show();
    }

    private void setAlarm(Calendar when, String message, int requestCode) {
        if (when.before(Calendar.getInstance())) return;
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent intent = new Intent(this, QuincenaReceiver.class);
        intent.putExtra("message", message);
        PendingIntent pi = PendingIntent.getBroadcast(this, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        } else if (Build.VERSION.SDK_INT >= 23) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        } else am.setExact(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
    }

    private void cancelReminders() {
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int code = 100; code <= 103; code++) {
            Intent i = new Intent(this, QuincenaReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(this, code, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi); pi.cancel();
        }
    }

    private void updateStatus() {
        if (status == null) return;
        status.setText(prefs.getBoolean("enabled", false)
                ? "● Recordatorios ACTIVADOS
Avisos programados 2 días y 1 día antes de las próximas dos quincenas."
                : "○ Recordatorios pausados
Actívalos para programar los avisos automáticos.");
    }

    private void applyColors() {
        int bg = darkMode ? Color.rgb(18,24,34) : Color.rgb(245,247,251);
        int card = darkMode ? Color.rgb(31,41,55) : Color.WHITE;
        int fg = darkMode ? Color.rgb(241,245,249) : Color.rgb(27,39,54);
        int secondary = darkMode ? Color.rgb(190,202,218) : Color.rgb(91,105,122);
        View root = findViewById(R.id.rootLayout); if (root != null) root.setBackgroundColor(bg);
        int[] textIds = {R.id.title, R.id.subtitle, R.id.nextPayment, R.id.afterPayment, R.id.status};
        for (int id : textIds) { TextView t = findViewById(id); if (t != null) t.setTextColor(id == R.id.subtitle || id == R.id.status ? secondary : fg); }
        TextView title = findViewById(R.id.title); if (title != null) title.setTypeface(null, Typeface.BOLD);
        int[] ids = {R.id.nextPayment, R.id.afterPayment};
        for (int id : ids) { TextView t = findViewById(id); if (t != null) { GradientDrawable d = new GradientDrawable(); d.setColor(card); d.setCornerRadius(24); t.setBackground(d); } }
        EditText edit = findViewById(R.id.messageInput);
        if (edit != null) { edit.setTextColor(fg); edit.setHintTextColor(secondary); edit.setBackgroundColor(card); }
        int[] buttons = {R.id.btnSchedule, R.id.btnCancel, R.id.btnSaveMessage, R.id.btnWhatsApp, R.id.btnTheme};
        for (int id : buttons) {
            Button b = findViewById(id); if (b != null) {
                boolean primary = id == R.id.btnSchedule;
                GradientDrawable d = new GradientDrawable(); d.setColor(primary ? (darkMode ? Color.rgb(38,181,205) : Color.rgb(0,139,170)) : card); d.setCornerRadius(20); b.setBackground(d);
                b.setTextColor(primary ? Color.WHITE : fg); b.setAllCaps(false); b.setPadding(14, 14, 14, 14);
            }
        }
    }
}
