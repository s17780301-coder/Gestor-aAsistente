-- DENTAL JG 10.8.1 — Registro completo: edición segura, validación anti duplicados y catálogos.
-- ADITIVO: no elimina pacientes, pagos, recibos ni relaciones existentes. Ejecutar en Supabase SQL Editor como administrador.
begin;
create extension if not exists pgcrypto;
alter table public.patients add column if not exists address text not null default '';
alter table public.patients add column if not exists phone2 text not null default '';
alter table public.patients add column if not exists policy_type text not null default '';
alter table public.patients add column if not exists first_payment_date date;
alter table public.patients add column if not exists manager_id uuid;
alter table public.patients add column if not exists observations text not null default '';
create table if not exists public.clinics(id uuid primary key default gen_random_uuid(),name text not null,active boolean not null default true,created_at timestamptz not null default now());
create unique index if not exists clinics_name_unique_idx on public.clinics(lower(trim(name)));
insert into public.clinics(name) select distinct trim(clinic) from public.patients where coalesce(trim(clinic),'')<>'' on conflict do nothing;
create table if not exists public.collection_managers (
 id uuid primary key default gen_random_uuid(), created_by uuid not null default auth.uid() references auth.users(id) on delete cascade,
 full_name text not null, phone text not null default '', active boolean not null default true,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(created_by,full_name)
);
create table if not exists public.policy_types(id uuid primary key default gen_random_uuid(),name text not null,active boolean not null default true,created_at timestamptz not null default now());
create unique index if not exists policy_types_name_unique_idx on public.policy_types(lower(trim(name)));
alter table public.policy_types enable row level security;
alter table public.clinics enable row level security;
alter table public.collection_managers enable row level security;
grant select,insert,update on public.policy_types to authenticated;
grant select,insert,update,delete on public.collection_managers to authenticated;
drop policy if exists "authorized users manage policy types" on public.policy_types;
create policy "authorized users manage policy types" on public.policy_types for all to authenticated using(exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('registro','admin'))) with check(exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('registro','admin')));
-- Los gestores son el catálogo central que ya utiliza Cobranza/Gestor. Registro solo puede consultarlo.
do $$ begin
 if to_regclass('public.collection_managers') is not null then
   if not exists(select 1 from pg_constraint where conname='patients_manager_id_fkey') then alter table public.patients add constraint patients_manager_id_fkey foreign key(manager_id) references public.collection_managers(id) on delete set null; end if;
   drop policy if exists "users manage own collection managers" on public.collection_managers;
   create policy "users manage own collection managers" on public.collection_managers for all to authenticated using(created_by=auth.uid()) with check(created_by=auth.uid());
   drop policy if exists "registration roles view active managers" on public.collection_managers;
   create policy "registration roles view active managers" on public.collection_managers for select to authenticated using(active=true and exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('registro','admin','gestor','cobranza')));
 end if;
end $$;
-- Los catálogos de clínica ya existen en el esquema del panel; asegurar lectura/alta para Registro.
grant select,insert,update on public.clinics to authenticated;
drop policy if exists "authenticated users manage clinics" on public.clinics;
drop policy if exists "registration roles manage clinics" on public.clinics;
create policy "registration roles manage clinics" on public.clinics for all to authenticated using(exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('registro','admin'))) with check(exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('registro','admin')));
-- Compatibilidad: clientes anteriores reciben tipo genérico si no tenían tipo.
insert into public.policy_types(name) values('General') on conflict do nothing;
-- Función de alta con validación atómica contra duplicados. Comparación sin acentos ni signos.
create or replace function public.dental_jg_normalize(p text) returns text
language sql immutable parallel safe as $$
 select regexp_replace(translate(lower(coalesce(p,'')), 'áéíóúüñ', 'aeiouun'), '[^a-z0-9]', '', 'g');
$$;
create or replace function public.register_dental_jg_patient_v2(
 p_name text,p_phone text,p_treatment text,p_total numeric,p_installments integer,p_installment_amount numeric,p_policy_number text,p_clinic text,
 p_address text,p_phone2 text,p_policy_type text,p_first_payment_date date,p_manager_id uuid,p_observations text
) returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid; v_name text; v_phone text; v_phone2 text; v_policy text;
begin
 if auth.uid() is null or not exists(select 1 from public.app_user_roles where user_id=auth.uid() and role in ('registro','admin')) then raise exception 'No tienes permiso para registrar clientes.'; end if;
 if nullif(trim(coalesce(p_name,'')),'') is null or nullif(trim(coalesce(p_clinic,'')),'') is null or nullif(trim(coalesce(p_address,'')),'') is null or nullif(trim(coalesce(p_phone,'')),'') is null or nullif(trim(coalesce(p_policy_type,'')),'') is null or nullif(trim(coalesce(p_policy_number,'')),'') is null or p_first_payment_date is null or p_manager_id is null or nullif(trim(coalesce(p_observations,'')),'') is null then raise exception 'Todos los campos son obligatorios excepto el segundo teléfono.'; end if;
 if length(regexp_replace(coalesce(p_phone,''),'\D','','g'))<10 or (nullif(trim(coalesce(p_phone2,'')),'') is not null and length(regexp_replace(p_phone2,'\D','','g'))<10) then raise exception 'Los teléfonos deben tener al menos 10 dígitos.'; end if;
 if p_total<=0 or p_installment_amount<=0 or p_installments<1 or p_installments>240 or p_installment_amount*p_installments < p_total then raise exception 'Revisa el total, la cantidad quincenal y el número de quincenas.'; end if;
 if not exists(select 1 from public.clinics where active and lower(trim(name))=lower(trim(p_clinic))) then raise exception 'Selecciona una clínica válida del catálogo.'; end if;
 if not exists(select 1 from public.policy_types where active and lower(trim(name))=lower(trim(p_policy_type))) then raise exception 'Selecciona un tipo de póliza válido.'; end if;
 if not exists(select 1 from public.collection_managers where active and id=p_manager_id) then raise exception 'Selecciona un gestor activo del catálogo compartido.'; end if;
 perform pg_advisory_xact_lock(hashtext('dental_jg_patient_dedupe'));
 v_name:=public.dental_jg_normalize(p_name); v_phone:=regexp_replace(p_phone,'\D','','g');v_phone2:=regexp_replace(coalesce(p_phone2,''),'\D','','g');v_policy:=public.dental_jg_normalize(p_policy_number);
 if exists(select 1 from public.patients x where public.dental_jg_normalize(x.name)=v_name or (v_phone<>'' and (regexp_replace(coalesce(x.phone,''),'\D','','g')=v_phone or regexp_replace(coalesce(x.phone2,''),'\D','','g')=v_phone)) or (v_phone2<>'' and (regexp_replace(coalesce(x.phone,''),'\D','','g')=v_phone2 or regexp_replace(coalesce(x.phone2,''),'\D','','g')=v_phone2)) or (v_policy<>'' and public.dental_jg_normalize(coalesce(x.policy_number,''))=v_policy)) then raise exception 'DUPLICADO: ya existe un cliente con el mismo nombre, teléfono o número de póliza.'; end if;
 insert into public.patients(name,phone,phone2,address,treatment,total,paid,installments,installment_amount,policy_number,policy_type,clinic,first_payment_date,manager_id,observations,source_device,created_at,updated_at)
 values(trim(p_name),trim(p_phone),trim(coalesce(p_phone2,'')),trim(p_address),coalesce(trim(p_treatment),''),p_total,0,p_installments,p_installment_amount,trim(p_policy_number),trim(p_policy_type),trim(p_clinic),p_first_payment_date,p_manager_id,trim(p_observations),'DENTAL JG Registro',now(),now()) returning id into v_id;
 return v_id;
end; $$;
revoke all on function public.register_dental_jg_patient_v2(text,text,text,numeric,integer,numeric,text,text,text,text,text,date,uuid,text) from public,anon;
grant execute on function public.register_dental_jg_patient_v2(text,text,text,numeric,integer,numeric,text,text,text,text,text,date,uuid,text) to authenticated;
-- Actualización de ficha: nunca modifica paid, payments, recibos ni tablas de cartera.
create or replace function public.update_dental_jg_patient_v2(
 p_patient_id uuid,p_name text,p_phone text,p_treatment text,p_total numeric,p_installments integer,p_installment_amount numeric,p_policy_number text,p_clinic text,
 p_address text,p_phone2 text,p_policy_type text,p_first_payment_date date,p_manager_id uuid,p_observations text
) returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid; v_name text;v_phone text;v_phone2 text;v_policy text;
begin
 if auth.uid() is null or not exists(select 1 from public.app_user_roles where user_id=auth.uid() and role in ('registro','admin')) then raise exception 'No tienes permiso para editar clientes.'; end if;
 if not exists(select 1 from public.patients where id=p_patient_id) then raise exception 'No se encontró el cliente que intentas editar.'; end if;
 if nullif(trim(coalesce(p_name,'')),'') is null or nullif(trim(coalesce(p_clinic,'')),'') is null or nullif(trim(coalesce(p_address,'')),'') is null or nullif(trim(coalesce(p_phone,'')),'') is null or nullif(trim(coalesce(p_policy_type,'')),'') is null or nullif(trim(coalesce(p_policy_number,'')),'') is null or p_first_payment_date is null or p_manager_id is null or nullif(trim(coalesce(p_observations,'')),'') is null then raise exception 'Todos los campos son obligatorios excepto el segundo teléfono.'; end if;
 if not exists(select 1 from public.clinics where active and lower(trim(name))=lower(trim(p_clinic))) then raise exception 'Selecciona una clínica válida del catálogo.'; end if;
 if not exists(select 1 from public.policy_types where active and lower(trim(name))=lower(trim(p_policy_type))) then raise exception 'Selecciona un tipo de póliza válido.'; end if;
 if not exists(select 1 from public.collection_managers where active and id=p_manager_id) then raise exception 'Selecciona un gestor activo del catálogo compartido.'; end if;
 if length(regexp_replace(coalesce(p_phone,''),'\D','','g'))<10 or (nullif(trim(coalesce(p_phone2,'')),'') is not null and length(regexp_replace(p_phone2,'\D','','g'))<10) then raise exception 'Los teléfonos deben tener al menos 10 dígitos.'; end if;
 if p_total<=0 or p_installment_amount<=0 or p_installments<1 or p_installments>240 or p_installment_amount*p_installments < p_total then raise exception 'Revisa el total, la cantidad quincenal y el número de quincenas.'; end if;
 perform pg_advisory_xact_lock(hashtext('dental_jg_patient_dedupe'));
 v_name:=public.dental_jg_normalize(p_name);v_phone:=regexp_replace(p_phone,'\D','','g');v_phone2:=regexp_replace(coalesce(p_phone2,''),'\D','','g');v_policy:=public.dental_jg_normalize(p_policy_number);
 if exists(select 1 from public.patients x where x.id<>p_patient_id and (public.dental_jg_normalize(x.name)=v_name or (v_phone<>'' and (regexp_replace(coalesce(x.phone,''),'\D','','g')=v_phone or regexp_replace(coalesce(x.phone2,''),'\D','','g')=v_phone)) or (v_phone2<>'' and (regexp_replace(coalesce(x.phone,''),'\D','','g')=v_phone2 or regexp_replace(coalesce(x.phone2,''),'\D','','g')=v_phone2)) or (v_policy<>'' and public.dental_jg_normalize(coalesce(x.policy_number,''))=v_policy))) then raise exception 'DUPLICADO: otro cliente ya usa ese nombre, teléfono o número de póliza.'; end if;
 update public.patients set name=trim(p_name),phone=trim(p_phone),phone2=trim(coalesce(p_phone2,'')),address=trim(p_address),treatment=coalesce(trim(p_treatment),''),total=p_total,installments=p_installments,installment_amount=p_installment_amount,policy_number=trim(p_policy_number),policy_type=trim(p_policy_type),clinic=trim(p_clinic),first_payment_date=p_first_payment_date,manager_id=p_manager_id,observations=trim(p_observations),updated_at=now() where id=p_patient_id returning id into v_id;
 return v_id;
end; $$;
revoke all on function public.update_dental_jg_patient_v2(uuid,text,text,text,numeric,integer,numeric,text,text,text,text,text,date,uuid,text) from public,anon;
grant execute on function public.update_dental_jg_patient_v2(uuid,text,text,text,numeric,integer,numeric,text,text,text,text,text,date,uuid,text) to authenticated;
commit;
