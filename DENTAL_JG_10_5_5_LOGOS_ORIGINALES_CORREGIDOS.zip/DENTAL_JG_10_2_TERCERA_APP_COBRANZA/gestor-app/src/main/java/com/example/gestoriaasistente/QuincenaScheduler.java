package com.example.gestoriaasistente;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;

/** Agenda avisos de inicio de quincena (13 y 28) y cierre (4 y 19), a las 9:00. */
public final class QuincenaScheduler {
  private QuincenaScheduler() {}
  public static void scheduleAll(Context context) {
    scheduleNext(context, 13, 101, "Inicio de quincena en dos días: prepara la cobranza para el día 15.");
    scheduleNext(context, 28, 102, "Inicio de quincena en dos días: prepara la cobranza para el día 30.");
    scheduleNext(context, 4, 103, "Aviso de cierre: revisa y cierra la cobranza del periodo.");
    scheduleNext(context, 19, 104, "Aviso de cierre: revisa y cierra la cobranza del periodo.");
  }
  private static void scheduleNext(Context c, int day, int id, String message) {
    Calendar now=Calendar.getInstance(), target=Calendar.getInstance(); target.set(Calendar.HOUR_OF_DAY,9);target.set(Calendar.MINUTE,0);target.set(Calendar.SECOND,0);target.set(Calendar.MILLISECOND,0);
    target.set(Calendar.DAY_OF_MONTH,Math.min(day,target.getActualMaximum(Calendar.DAY_OF_MONTH)));
    if(!target.after(now)){target.add(Calendar.MONTH,1);target.set(Calendar.DAY_OF_MONTH,Math.min(day,target.getActualMaximum(Calendar.DAY_OF_MONTH)));}
    Intent i=new Intent(c,QuincenaReceiver.class).putExtra("message",message).putExtra("schedule_id",id);
    PendingIntent pi=PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null){if(android.os.Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,target.getTimeInMillis(),pi);else am.set(AlarmManager.RTC_WAKEUP,target.getTimeInMillis(),pi);}
  }
}
