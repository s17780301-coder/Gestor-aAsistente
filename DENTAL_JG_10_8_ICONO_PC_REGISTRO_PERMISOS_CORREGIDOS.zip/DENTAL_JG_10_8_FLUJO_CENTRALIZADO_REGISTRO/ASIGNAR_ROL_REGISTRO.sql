-- DENTAL JG 10.8 — Asignar permiso de Registro a la cuenta indicada.
-- Ejecutar en Supabase > SQL Editor del proyecto correcto con una cuenta administradora.
-- Este script asigna únicamente el rol 'registro'; no concede permisos de administrador.

DO $$
DECLARE
  correo_objetivo text := 'c0986749@gmail.com';
  usuario_objetivo uuid;
BEGIN
  SELECT id INTO usuario_objetivo
  FROM auth.users
  WHERE lower(email) = lower(correo_objetivo)
  LIMIT 1;

  IF usuario_objetivo IS NULL THEN
    RAISE EXCEPTION 'No existe una cuenta Auth con el correo % en este proyecto. Confirma que elegiste el proyecto correcto de Supabase y que la cuenta ya existe en Authentication > Users.', correo_objetivo;
  END IF;

  INSERT INTO public.app_user_roles(user_id, role)
  VALUES (usuario_objetivo, 'registro')
  ON CONFLICT (user_id, role) DO NOTHING;

  RAISE NOTICE 'El rol registro fue asignado o ya existía para %', correo_objetivo;
END $$;

-- Verificación: el resultado debe mostrar el correo y role = registro.
SELECT u.email, r.role
FROM auth.users AS u
JOIN public.app_user_roles AS r ON r.user_id = u.id
WHERE lower(u.email) = lower('c0986749@gmail.com')
  AND r.role = 'registro';
