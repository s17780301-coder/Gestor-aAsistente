GESTORÍA ASISTENTE 7.0 - CORRECCIÓN DE TONOS

Cambios de esta revisión:
- Se quitó la función de lectura por voz.
- El botón que antes decía "Escuchar voz" ahora sirve para probar el tono de notificación seleccionado.
- El botón "Elegir tono" abre el selector de sonidos de Android.
- Al seleccionar un tono, se guarda, se reconstruye el canal de notificaciones y se intenta reproducir una vista previa.
- Se actualizó la versión a 7.0.

Compilación en GitHub Actions:
1. Sube el contenido del ZIP al repositorio o usa el flujo de compilación existente.
2. Ejecuta Actions.
3. Descarga el APK desde Artifacts si el flujo termina en verde.

Nota: El ZIP fue revisado estructuralmente y sus XML se validaron. Esta revisión no pudo ejecutar una compilación Android completa en este entorno.
