GESTORIA ASISTENTE - PROYECTO CORREGIDO PARA COMPILAR EN GITHUB ACTIONS

Correccion principal: los archivos del proyecto están en la raíz del ZIP. Antes estaban dentro de una carpeta adicional GestoriaAsistente/, por lo que el flujo de GitHub no encontraba app/build.gradle.

Para generar el APK:
1. Sube y descomprime el contenido de este ZIP en la raíz de tu repositorio de GitHub (deben verse settings.gradle y la carpeta app directamente en la página principal del repositorio).
2. Abre la pestaña Actions.
3. Selecciona “Generar APK de Gestoria Asistente”.
4. Pulsa “Run workflow”.
5. Cuando termine correctamente, abre la ejecución y descarga el artefacto “GestoriaAsistente-APK”.

Este ZIP corrige la estructura y el flujo de compilación. La compilación remota debe ejecutarse en GitHub; no se afirma que ya se haya generado o probado un APK en este entorno.
