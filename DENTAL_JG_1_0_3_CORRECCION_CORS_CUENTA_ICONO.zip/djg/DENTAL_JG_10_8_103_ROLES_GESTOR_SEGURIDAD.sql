-- DENTAL JG 10.8.103 — roles de gestor y clave de gestor
-- Ejecutar en Supabase SQL Editor después de respaldar la base. No borra datos.
alter table public.collection_managers add column if not exists manager_key text;
create unique index if not exists collection_managers_manager_key_unique
  on public.collection_managers(manager_key)
  where manager_key is not null and btrim(manager_key) <> '';

-- Solo cuentas con rol Gestor o Administración pueden validar una clave.
create or replace function public.dental_jg_manager_by_key(p_manager_key text)
returns table(id uuid, full_name text)
language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null then raise exception 'Inicia sesión para validar tu clave de gestor.'; end if;
  if not exists (select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('gestor','admin')) then
    raise exception 'Esta cuenta no tiene el rol Gestor autorizado.';
  end if;
  return query select m.id,m.full_name from public.collection_managers m
    where m.active is distinct from false and m.manager_key=trim(coalesce(p_manager_key,''))
    limit 1;
end; $$;
revoke all on function public.dental_jg_manager_by_key(text) from public, anon;
grant execute on function public.dental_jg_manager_by_key(text) to authenticated;
