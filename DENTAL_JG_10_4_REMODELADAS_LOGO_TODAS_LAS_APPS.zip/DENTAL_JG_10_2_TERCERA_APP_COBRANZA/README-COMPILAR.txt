DENTAL JG 10.2 — TERCERA APP DE COBRANZA, RECIBOS Y WINDOWS

1. Extrae el ZIP completo y sube su contenido al repositorio GitHub que utilizas para DENTAL JG.
2. En GitHub abre Actions y ejecuta “Compilar DENTAL JG — 3 APK independientes”.
3. El workflow tiene tres trabajos separados: Gestor, Panel administrativo y Cobranza. Cada uno publica su propio artefacto APK; si uno falla, los otros dos pueden terminar igualmente.
4. Descarga por separado los artefactos “DENTAL-JG-1-Gestor-APK”, “DENTAL-JG-2-Panel-Administrativo-APK” y “DENTAL-JG-3-Cobranza-Recibos-APK”.
5. Inicia sesión con la misma cuenta autorizada de Supabase en las aplicaciones.
6. Antes de usar la app de Cobranza, ejecuta en Supabase SQL Editor el archivo cobranza-web/supabase_cobranza_v1.sql.
7. Para Windows, publica el contenido de cobranza-web por HTTPS (por ejemplo, GitHub Pages) y en Edge/Chrome elige instalar el sitio como aplicación.

Cambios de esta versión:
- Se usa el turquesa del logotipo (#19B9B0) y el azul de DENTAL JG (#1769C2), no un verde distinto.
- El panel administrativo mantiene tema oscuro, ahora en tonos neutros azul-gris y con los colores reales de marca.
- En Administrar clínicas puedes editar el nombre o eliminar una clínica. Al editar se actualiza el nombre en los pacientes asignados. Al eliminar, se quita la asignación de clínica de esos pacientes, pero no se eliminan sus expedientes ni pagos.
- Los nombres de clínica que aparecen únicamente en expedientes antiguos se marcan como heredados; primero registra la clínica en el catálogo para poder administrarla.
- La tarjeta “Pacientes registrados” abre el directorio/formulario de pacientes. “Ver pacientes” en una clínica también lleva a la sección de pacientes filtrada por esa clínica.

Si GitHub Actions falla, comparte el error exacto antes de modificar Supabase. Se comprobó la sintaxis de JavaScript, pero esta entrega aún necesita una compilación completa y prueba real contra Supabase.

Tercera app DENTAL JG Cobranza:
- Android: módulo cobranza-app; GitHub Actions genera la APK en el artefacto DENTAL-JG-3-Cobranza-Recibos-APK, en un trabajo independiente de las otras dos APK.
- Windows: PWA en cobranza-web, instalable desde Edge/Chrome tras publicarla por HTTPS.
- Recibe pacientes y pagos desde Supabase Realtime, configura plantilla/prefijo/número de folio, genera recibos y permite imprimir o guardar PDF.
- El cálculo visible es neto = importe cobrado - saldo anterior - tabulador; nuevo saldo = max(0, saldo anterior - importe). Confirma que esta fórmula corresponde a tu operación antes de emitir recibos oficiales.
- La compilación Gradle completa, el SQL en la instancia real y la impresión física aún deben probarse.

IDENTIDAD VISUAL: el turquesa #19B9B0 es el color principal en gestor, panel y Cobranza; el azul #1769C2 se conserva solo como acento secundario del logotipo.
