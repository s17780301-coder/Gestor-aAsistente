package com.example.gestoriaasistente;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Mensajería del módulo Gestor contra la tabla compartida app_messages. */
public final class AppMessages {
  private static final String BASE=SupabaseSync.BASE, ANON=SupabaseSync.ANON;
  private final Activity activity; private final SupabaseSync cloud; private final Handler main=new Handler(Looper.getMainLooper());
  public AppMessages(Activity a,SupabaseSync c){activity=a;cloud=c;}
  public void show(){if(!cloud.connected()){Toast.makeText(activity,"Inicia sesión en la nube para usar mensajes.",Toast.LENGTH_LONG).show();return;}new AlertDialog.Builder(activity).setTitle("Mensajes entre aplicaciones").setItems(new String[]{"Ver bandeja de mensajes","Enviar mensaje"},(d,which)->{if(which==0)inbox();else compose();}).setNegativeButton("Cerrar",null).show();}
  private void compose(){LinearLayout box=new LinearLayout(activity);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(28,8,28,4);Spinner to=new Spinner(activity);String[] names={"Todas las aplicaciones","Administración","Cobranza","Registro de Clientes"};String[] values={"all","admin","cobranza","registro"};to.setAdapter(new ArrayAdapter<>(activity,android.R.layout.simple_spinner_dropdown_item,names));EditText text=new EditText(activity);text.setHint("Escribe el mensaje");text.setMinLines(3);text.setGravity(48);text.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);box.addView(to);box.addView(text);new AlertDialog.Builder(activity).setTitle("Enviar mensaje").setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Enviar",(d,w)->{String body=text.getText().toString().trim();if(body.isEmpty()){Toast.makeText(activity,"Escribe un mensaje.",Toast.LENGTH_SHORT).show();return;}send(values[to.getSelectedItemPosition()],body);}).show();}
  private void send(String recipient,String body){new Thread(()->{try{JSONObject msg=new JSONObject();msg.put("sender_app","gestor");msg.put("recipient_app",recipient);msg.put("body",body);request("POST","/rest/v1/app_messages",msg,"return=representation");main.post(()->Toast.makeText(activity,"Mensaje enviado.",Toast.LENGTH_LONG).show());}catch(Exception e){main.post(()->new AlertDialog.Builder(activity).setTitle("No se pudo enviar").setMessage(e.getMessage()+"\nVerifica que ejecutaste DENTAL_JG_10_8_MENSAJERIA_APPS.sql en Supabase.").setPositiveButton("Aceptar",null).show());}}).start();}
  private void inbox(){new Thread(()->{try{JSONArray data=new JSONArray(request("GET","/rest/v1/app_messages?select=sender_app,recipient_app,body,created_at&or=(recipient_app.eq.gestor,recipient_app.eq.all)&order=created_at.desc&limit=40",null,null));StringBuilder b=new StringBuilder();for(int i=0;i<data.length();i++){JSONObject m=data.getJSONObject(i);if(i>0)b.append("\n\n────────────\n\n");b.append(label(m.optString("sender_app"))).append(" → ").append(label(m.optString("recipient_app"))).append("\n").append(m.optString("created_at")).append("\n").append(m.optString("body"));}if(b.length()==0)b.append("No hay mensajes para Gestor todavía.");String result=b.toString();main.post(()->{TextView t=new TextView(activity);t.setText(result);t.setTextColor(Color.rgb(27,49,66));t.setTextSize(15);t.setPadding(24,20,24,20);ScrollView sc=new ScrollView(activity);sc.addView(t);new AlertDialog.Builder(activity).setTitle("Bandeja de mensajes").setView(sc).setPositiveButton("Cerrar",null).setNeutralButton("Actualizar",(d,w)->inbox()).show();});}catch(Exception e){main.post(()->new AlertDialog.Builder(activity).setTitle("No se pudo abrir la bandeja").setMessage(e.getMessage()+"\nEjecuta el SQL de mensajería en Supabase.").setPositiveButton("Aceptar",null).show());}}).start();}
  private String label(String s){switch(s){case "all":return "Todas las aplicaciones";case "gestor":return "Gestor";case "admin":return "Administración";case "cobranza":return "Cobranza";case "registro":return "Registro";default:return s;}}
  private String request(String method,String path,JSONObject body,String prefer)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(BASE+path).openConnection();c.setRequestMethod(method);c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("apikey",ANON);c.setRequestProperty("Authorization","Bearer "+cloud.token());c.setRequestProperty("Accept","application/json");if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");if(prefer!=null)c.setRequestProperty("Prefer",prefer);try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();StringBuilder out=new StringBuilder();if(in!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)out.append(line);}c.disconnect();if(code<200||code>=300)throw new Exception("Supabase ("+code+"): "+out);return out.toString();}
}
