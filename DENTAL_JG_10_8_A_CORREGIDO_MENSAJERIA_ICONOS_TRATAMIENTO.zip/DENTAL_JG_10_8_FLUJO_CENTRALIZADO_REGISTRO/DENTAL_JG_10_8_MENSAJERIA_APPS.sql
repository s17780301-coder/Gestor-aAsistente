-- DENTAL JG 10.8 — Mensajería entre aplicaciones
-- Ejecutar una sola vez en Supabase > SQL Editor del proyecto usado por las apps.
create table if not exists public.app_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  sender_app text not null check (sender_app in ('gestor','admin','cobranza','registro')),
  recipient_app text not null check (recipient_app in ('all','gestor','admin','cobranza','registro')),
  body text not null check (length(trim(body)) between 1 and 2000),
  created_at timestamptz not null default now()
);
create index if not exists app_messages_recipient_created_idx on public.app_messages(recipient_app, created_at desc);
create index if not exists app_messages_sender_created_idx on public.app_messages(sender_id, created_at desc);
alter table public.app_messages enable row level security;
grant select, insert on public.app_messages to authenticated;
drop policy if exists "dental jg messages readable by sender or recipient app" on public.app_messages;
create policy "dental jg messages readable by sender or recipient app" on public.app_messages for select to authenticated using (sender_id = auth.uid() or recipient_app = 'all' or exists (select 1 from public.app_user_roles r where r.user_id = auth.uid() and (r.role = 'admin' or (r.role = 'cobranza' and recipient_app = 'cobranza') or (r.role = 'registro' and recipient_app = 'registro') or (r.role = 'gestor' and recipient_app = 'gestor'))));
drop policy if exists "dental jg authenticated users send messages as themselves" on public.app_messages;
create policy "dental jg authenticated users send messages as themselves" on public.app_messages for insert to authenticated with check (sender_id = auth.uid() and exists (select 1 from public.app_user_roles r where r.user_id = auth.uid() and r.role in ('admin','cobranza','registro','gestor')));
do $$ begin alter publication supabase_realtime add table public.app_messages; exception when duplicate_object then null; when undefined_object then raise notice 'Habilita app_messages en Database > Replication.'; end $$;
